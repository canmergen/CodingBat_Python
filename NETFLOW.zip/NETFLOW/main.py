# FORA Projesi - Ana Orkestrasyon Scripti
# ═══════════════════════════════════════════════════════════════════
# 🔧 MANUEL GÜNCELLEME GEREKTİREN TÜM AYARLAR BURADA
#    Src dosyalarına girmeye gerek yok — sadece bu dosyayı düzenle.
# ═══════════════════════════════════════════════════════════════════

import pandas as pd
from datetime import datetime

from src.week_generator import generate_weeks
from src.scrape_pp_getiri import scrape_pp_getiri
from src.scrape_webtufe import scrape_webtufe
from src.fetch_aoff import fetch_aoff
from src.scrape_tlref import scrape_tlref
from src.fetch_bist100 import fetch_bist100
from src.scrape_ppk import scrape_ppk
from src.fetch_tcmb_mevduat import fetch_tcmb_mevduat
from src.fetch_tcmb_ticari import fetch_tcmb_ticari
from src.fetch_sepet_kur import fetch_sepet_kur
from src.update_workdays import update_workdays
from src.add_details_sheet import add_details_sheet
from src.scrape_benchmark import scrape_benchmark, aggregate_benchmark
from src.fetch_yfinance import fetch_yfinance
from src.fetch_evds3_macro import fetch_evds3_macro
from src.fetch_crypto import fetch_crypto
from src.update_calendar_features import update_calendar_features
from src.fetch_google_trends import fetch_google_trends
from src.fetch_cds import fetch_cds
from src.fetch_webtufe_tufe import fetch_webtufe_tufe
from src.fetch_webtufe_gruplar import fetch_webtufe_gruplar
from src.fetch_bkm_sektorel import fetch_bkm_sektorel
from src.fetch_tcmb_politika import fetch_tcmb_politika
from src.build_model_dataset import build_model_dataset

# ═══════════════════════════════════════════════════════════════════
# MERKEZİ KONFİGÜRASYON
# ═══════════════════════════════════════════════════════════════════
CONFIG = {

    # ── Proje başlangıç tarihi ────────────────────────────────────
    "START_DATE": datetime(2025, 1, 3),   # İlk tam hafta: 03.01.2025 – 09.01.2025

    # ── EVDS API Anahtarı ─────────────────────────────────────────
    # Beklenti Anketi ve işsizlik gibi kısıtlı serilere erişim sağlar.
    # Kaynak: https://evds2.tcmb.gov.tr → Üye Ol → API Anahtarı
    "EVDS_API_KEY": "A33UzQ44wO",

    # ── PPK Toplantı Tarihleri ────────────────────────────────────
    # Kaynak: https://www.tcmb.gov.tr/wps/wcm/connect/tr/tcmb+tr/main+menu/duyurular/takvim
    # Her yılın başında TCMB takviminden güncelle.
    "PPK_DATES": [
        # 2025
        "20/01/2025", "03/03/2025", "17/03/2025", "14/04/2025",
        "16/07/2025", "21/07/2025", "08/09/2025", "20/10/2025", "01/12/2025",
        # 2026
        "22/01/2026", "05/03/2026", "19/03/2026", "16/04/2026",
        "28/05/2026", "16/07/2026", "10/09/2026", "22/10/2026", "10/12/2026",
    ],

    # ── Ramazan Tarihleri ─────────────────────────────────────────
    # Kaynak: https://www.diyanet.gov.tr/
    # Yaklaşık (Hicri takvim farka göre ±1 gün kayabilir).
    "RAMAZAN_RANGES": [
        (pd.Timestamp("2025-02-28"), pd.Timestamp("2025-03-30")),   # 2025
        (pd.Timestamp("2026-02-17"), pd.Timestamp("2026-03-19")),   # 2026
    ],

    # ── PPK Kararları: Faiz Oranı (%) ────────────────────────────
    # Kaynak: https://www.tcmb.gov.tr/wps/wcm/connect/tr/tcmb+tr/main+menu/para+politikasi/merkez+bankasi+faiz+oranlari
    # Yeni PPK kararından sonra güncelle.
    "PPK_RATES": {
        # 2025
        "20/01/2025": 45.00,
        "03/03/2025": 42.50,
        "17/03/2025": 42.50,   # değişiklik yoksa bir önceki
        "14/04/2025": 40.00,
        "16/07/2025": 35.00,
        "21/07/2025": 35.00,
        "08/09/2025": 30.00,
        "20/10/2025": 25.00,
        "01/12/2025": 22.50,
        # 2026
        "22/01/2026": 20.00,
        "05/03/2026": 17.50,
        "19/03/2026": 17.50,
        "16/04/2026": None,    # henüz karar yok
        "28/05/2026": None,
        "16/07/2026": None,
        "10/09/2026": None,
        "22/10/2026": None,
        "10/12/2026": None,
    },

}

# ═══════════════════════════════════════════════════════════════════
# ANA FONKSİYON
# ═══════════════════════════════════════════════════════════════════

def main():
    print("FORA Güncelleme Süreci Başlıyor...")

    # Adım 1: Haftalık zaman çizelgesini oluştur/güncelle
    generate_weeks(start_date=CONFIG["START_DATE"])

    # Adım 2: AOFF (EVDS3) — PP Getiri fallback için önce çekilmeli
    fetch_aoff()

    # Adım 3: WebTufe aylık enflasyon
    scrape_webtufe()

    # Adım 4: PP Getiri (TEFAS Playwright → AOFF fallback)
    scrape_pp_getiri()

    # Adım 5: TLREF (Borsa İstanbul)
    scrape_tlref(start_date=CONFIG["START_DATE"])

    # Adım 5.5: BIST 100 (EVDS3)
    fetch_bist100()

    # Adım 5.6: PPK toplantı tarihleri — CONFIG'den geliyor
    scrape_ppk(ppk_dates=CONFIG["PPK_DATES"])

    # Adım 5.7: Benchmark — günlük arşiv
    scrape_benchmark()
    # Adım 5.8: Benchmark — haftalık FORA özeti
    aggregate_benchmark()

    # Adım 6: TCMB Mevduat faizleri (1M, 3M)
    fetch_tcmb_mevduat()

    # Adım 6.5: TCMB Ticari Kredi oranları
    fetch_tcmb_ticari()

    # Adım 7: Sepet Kur (TCMB ForexBuying XML)
    fetch_sepet_kur()

    # Adım 8: Tam iş günü sayısı
    update_workdays()

    # Adım 9: TCMB Politika Faizi (PPK karar oranları — TLREF/Benchmark'tan farklı)
    fetch_tcmb_politika(ppk_rates=CONFIG["PPK_RATES"])

    # Adım 10: Piyasa verileri (yfinance)
    fetch_yfinance()

    # Adım 11: EVDS3 Makro (Tüketici Güven, KKO, Kredi Faizleri, TÜFE, Çekirdek Enflasyon)
    fetch_evds3_macro(api_key=CONFIG["EVDS_API_KEY"])

    # Adım 12: Kripto hacim (USDT/TRY)
    fetch_crypto()

    # Adım 13: Google Trends (mevduat faizi arama hacmi)
    fetch_google_trends()

    # Adım 14: CDS 5Y (worldgovernmentbonds → investing.com fallback)
    fetch_cds()

    # Adım 14.5: ENAG E-TÜFE + TÜİK TÜFE (Supabase API)
    fetch_webtufe_tufe()

    # Adım 14.6: WebTUFE Ana Gruplar (Gıda, Enerji, Ulaştırma, Hizmet aylık %)
    fetch_webtufe_gruplar()

    # Adım 14.7: BKM Sektörel Kart Harcamaları (Giyim, Yemek, Kozmetik)
    fetch_bkm_sektorel()

    # Adım 15: Takvim değişkenleri — Ramazan tarihleri CONFIG'den geliyor
    update_calendar_features(
        ramazan_ranges=CONFIG["RAMAZAN_RANGES"],
        ppk_dates=CONFIG["PPK_DATES"],
    )

    # Adım 17: Detay sayfasını güncelle (en son çalışmalı)
    add_details_sheet()

    # Adım 18: Model dataset üret — FORA.xlsx hazır, FORA_MODEL.xlsx oluştur
    # Çıktı: lag, log, rolling, delta feature'ları ile zenginleştirilmiş dataset
    # Not: NET kolonu banka içi veri — FORA_MODEL'e elle eklediğinizde lag/roll otomatik çalışır
    build_model_dataset()

    print("\nSüreç Tamamlandı.")


if __name__ == "__main__":
    main()

