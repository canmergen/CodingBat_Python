"""
fetch_tcmb_politika.py
----------------------
TCMB politika faizini (1 haftalık repo faizi) FORA.xlsx'e yazar.

Kaynak: main.py CONFIG["PPK_RATES"]
  EVDS3 API bu seriyi desteklemiyor (TP.TF.PPKARARFA HTTP 500).
  Her PPK toplantısında alınan faiz kararı CONFIG["PPK_RATES"] 'a manuel girilir
  ve haftalar arası forward-fill ile doldurulur.

Güncelleme: Yeni PPK kararından sonra main.py CONFIG["PPK_RATES"]'a
  "GG/AA/YYYY": oran  şeklinde ekle.
"""

import pandas as pd
from src.utils import read_fora, save_fora

COL_NAME = "TCMB_Politika"


def fetch_tcmb_politika(ppk_rates: dict | None = None):
    print("\n--- TCMB Politika Faizi Yükleniyor ---")

    df = read_fora()
    if df is None or df.empty:
        print("FORA.xlsx bulunamadı veya boş.")
        return

    if not ppk_rates:
        print("  ⚠ PPK_RATES boş — main.py CONFIG['PPK_RATES'] güncellenmeli.")
        return

    if COL_NAME not in df.columns:
        df[COL_NAME] = None

    df["Min Tarih"] = pd.to_datetime(df["Min Tarih"], dayfirst=True, errors="coerce")
    df["Max Tarih"] = pd.to_datetime(df["Max Tarih"], dayfirst=True, errors="coerce")

    # PPK_RATES → tarih indeksli Series (forward-fill için)
    rate_series = {}
    for date_str, rate in ppk_rates.items():
        if rate is None:
            continue
        try:
            dt = pd.to_datetime(date_str, dayfirst=True)
            rate_series[dt] = float(rate)
        except Exception:
            continue

    if not rate_series:
        print("  ⚠ Geçerli PPK_RATES yok.")
        _restore_dates(df)
        return

    s = pd.Series(rate_series).sort_index()
    print(f"  {len(s)} PPK kararı yüklendi. Son: {s.index[-1].date()} → %{s.iloc[-1]}")

    # Her hafta için geçerli politika faizi = hafta Min Tarihi'nden önceki son PPK kararı
    updated = 0
    for idx, row in df.iterrows():
        r_min = row["Min Tarih"]
        if pd.isna(r_min):
            continue
        # r_min tarihine kadar olan son kararı al
        past = s[s.index <= r_min]
        if past.empty:
            continue
        val = round(float(past.iloc[-1]), 4)
        if df.at[idx, COL_NAME] != val:
            df.at[idx, COL_NAME] = val
            updated += 1

    filled = df[COL_NAME].notna().sum()
    print(f"  TCMB_Politika: {filled} satır dolu, {updated} satır güncellendi.")

    _restore_dates(df)
    save_fora(df)
    print("FORA.xlsx kaydedildi (TCMB Politika Faizi).\n")


def _restore_dates(df):
    for col in ["Min Tarih", "Max Tarih"]:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = df[col].dt.strftime("%d.%m.%Y")


if __name__ == "__main__":
    fetch_tcmb_politika()
