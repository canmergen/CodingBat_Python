"""
fetch_webtufe_tufe.py
---------------------
apiwebtufe.com/api/v1/tufe endpoint'inden WebTÜFE ve TÜİK TÜFE verilerini çeker.

Eklenen kolonlar:
  - WebTufe_TUFE_Aylik  : WebTÜFE aylık enflasyon (%)
  - WebTufe_TUFE_Yillik : WebTÜFE yıllık enflasyon (%)
  - TUIK_TUFE_Aylik     : TÜİK aylık enflasyon (%)
  - TUIK_TUFE_Yillik    : TÜİK yıllık enflasyon (%)
"""

import requests
import pandas as pd
from src.utils import read_fora, save_fora

API_URL = "https://www.apiwebtufe.com/api/v1/tufe"

SERIES_MAP = {
    "WebTufe_TUFE_Aylik":  "monthly_series",
    "WebTufe_TUFE_Yillik": "yearly_series",
    "TUIK_TUFE_Aylik":     "tuik_monthly_series",
    "TUIK_TUFE_Yillik":    "tuik_yearly_series",
}

# Eski ENAG kolonları (artık kullanılmıyor — silinecek)
OLD_COLUMNS = [
    "ENAG_TUFE_Aylik",
    "ENAG_TUFE_Yillik",
    "TUIK_TUFE_Aylik",
    "TUIK_TUFE_Yillik",
]


def fetch_webtufe_tufe():
    print("\n--- WebTÜFE & TÜİK TÜFE Verileri Çekiliyor ---")

    df = read_fora()
    if df is None or df.empty:
        print("  FORA.xlsx bulunamadı.")
        return

    # Eski ENAG kolonlarını kaldır
    dropped = [c for c in OLD_COLUMNS if c in df.columns]
    if dropped:
        df.drop(columns=dropped, inplace=True)
        print(f"  Kaldırıldı: {dropped}")

    # API'den veri çek
    try:
        r = requests.get(API_URL, timeout=15)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        print(f"  ⚠ API hatası: {e}")
        save_fora(df)
        return

    df["Min Tarih"] = pd.to_datetime(df["Min Tarih"], dayfirst=True, errors="coerce")
    df["Max Tarih"] = pd.to_datetime(df["Max Tarih"], dayfirst=True, errors="coerce")

    for col_name, series_key in SERIES_MAP.items():
        raw = data.get(series_key, [])
        if not raw:
            print(f"  ⚠ {col_name}: API'de boş seri ({series_key})")
            continue

        # { date → value } dict oluştur, tarih = ay sonu
        monthly_map = {}
        for item in raw:
            try:
                dt = pd.Timestamp(item["date"])
                monthly_map[(dt.year, dt.month)] = round(float(item["value"]), 4)
            except Exception:
                pass

        if col_name not in df.columns:
            df[col_name] = None

        updated = 0
        for idx, row in df.iterrows():
            r_end = row["Max Tarih"]
            if pd.isna(r_end):
                continue
            key = (r_end.year, r_end.month)
            val = monthly_map.get(key)
            if val is not None:
                df.at[idx, col_name] = val
                updated += 1

        filled = df[col_name].notna().sum()
        print(f"  {col_name}: {updated} satır güncellendi ({filled}/{len(df)} dolu)")

    # Tarih formatını geri yükle
    for col in ["Min Tarih", "Max Tarih"]:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = df[col].dt.strftime("%d.%m.%Y")

    save_fora(df)
    print("FORA.xlsx kaydedildi (WebTÜFE & TÜİK TÜFE eklendi).\n")
