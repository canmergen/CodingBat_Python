"""
scrape_webtufe.py
-----------------
WebTUFE aylık enflasyon verisini API'den çeker.
Kaynak: https://www.apiwebtufe.com/api/v1/download/tufe/monthly/csv

Aylık veriyi haftalık FORA satırlarına eşleştirir:
  hangi haftanın "Max Tarih"i o ayın son gününe denk geliyorsa o değeri atar.
"""

import io
import pandas as pd
import requests
from src.utils import read_fora, save_fora

API_URL = "https://www.apiwebtufe.com/api/v1/download/tufe/monthly/csv"


def scrape_webtufe():
    target_column = "WebTufe"
    print("\n--- WebTufe Verisi Çekiliyor ---")

    df = read_fora()
    if df is None or df.empty:
        print("Hata: FORA.xlsx bulunamadı.")
        return

    # 1. API'den CSV indir
    try:
        resp = requests.get(API_URL, timeout=15)
        resp.raise_for_status()
    except Exception as e:
        print(f"  ⚠ API hatası: {e}")
        return

    csv_df = pd.read_csv(io.StringIO(resp.text))
    csv_df["date"] = pd.to_datetime(csv_df["date"])
    csv_df = csv_df.rename(columns={"Web TÜFE Aylık (%)": "webtufe"})
    csv_df = csv_df[["date", "webtufe"]].dropna(subset=["webtufe"])
    print(f"  {len(csv_df)} aylık kayıt alındı ({csv_df['date'].min():%Y-%m} → {csv_df['date'].max():%Y-%m})")

    # Ay sonu tarihine göre dict oluştur
    monthly_map = {}
    for _, row in csv_df.iterrows():
        key = (row["date"].year, row["date"].month)
        monthly_map[key] = round(row["webtufe"], 4)

    # 2. FORA'ya eşleştir
    if target_column not in df.columns:
        df[target_column] = None

    df["Min Tarih"] = pd.to_datetime(df["Min Tarih"], dayfirst=True, errors="coerce")
    df["Max Tarih"] = pd.to_datetime(df["Max Tarih"], dayfirst=True, errors="coerce")

    updated = 0
    for idx, row in df.iterrows():
        if pd.isna(row["Min Tarih"]) or pd.isna(row["Max Tarih"]):
            continue

        mid = row["Min Tarih"] + (row["Max Tarih"] - row["Min Tarih"]) / 2
        key = (mid.year, mid.month)
        val = monthly_map.get(key)
        df.at[idx, target_column] = val
        if val is not None:
            updated += 1

    # Tarih formatını geri yükle
    for col in ["Min Tarih", "Max Tarih"]:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = df[col].dt.strftime("%d.%m.%Y")

    save_fora(df)
    print(f"  WebTufe: {updated} satır güncellendi.")


if __name__ == "__main__":
    scrape_webtufe()
