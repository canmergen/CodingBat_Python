"""
fetch_cds.py
------------
Türkiye 5 Yıllık CDS Primi verisini çeker ve FORA.xlsx'e yazar.

Çekilen veri:
  - CDS_5Y : Türkiye 5Y CDS Primi (baz puan)

Kaynak Önceliği:
  1. Hafızada tutulu tarihsel taban (2025-01-01 → 2026-03-20)
  2. investing.com — en son 20 günlük live veriyle taban güncellenir
"""

import os
import re
import time
import pandas as pd
from src.utils import read_fora, save_fora

COLUMN_NAME = "CDS_5Y"

# ── Kaynak URL'ler ─────────────────────────────────────────────────
WGB_URL = "https://www.worldgovernmentbonds.com/cds/turkey/"
INV_URL = "https://tr.investing.com/rates-bonds/turkey-cds-5-year-usd-historical-data"

UA = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)

# ══════════════════════════════════════════════════════════════════
# Tarihsel Taban (2025-01-01 → 2026-03-20) — Browser ile çekildi
# Haftalık ortalama hesabı için günlük kapanış değerleri (baz puan)
# ══════════════════════════════════════════════════════════════════
_HARDCODED_CDS_DATA = {
    "2026-03-20": 307.08, "2026-03-19": 283.03, "2026-03-18": 275.99,
    "2026-03-17": 274.48, "2026-03-16": 276.16, "2026-03-13": 269.08,
    "2026-03-12": 260.80, "2026-03-11": 250.16, "2026-03-10": 252.72,
    "2026-03-09": 263.65, "2026-03-06": 251.84, "2026-03-05": 238.74,
    "2026-03-04": 236.81, "2026-03-03": 246.53, "2026-03-02": 237.89,
    "2026-02-27": 232.89, "2026-02-26": 226.77, "2026-02-25": 224.77,
    "2026-02-24": 225.79, "2026-02-23": 221.61, "2026-02-20": 222.63,
    "2026-02-19": 223.13, "2026-02-18": 218.65, "2026-02-17": 213.82,
    "2026-02-16": 214.48, "2026-02-13": 215.32, "2026-02-12": 215.29,
    "2026-02-11": 213.72, "2026-02-10": 212.48, "2026-02-09": 213.69,
    "2026-02-06": 217.92, "2026-02-05": 220.27, "2026-02-04": 216.62,
    "2026-02-03": 215.42, "2026-02-02": 216.34, "2026-01-30": 219.26,
    "2026-01-29": 217.95, "2026-01-28": 214.78, "2026-01-27": 212.48,
    "2026-01-26": 214.58, "2026-01-23": 212.65, "2026-01-22": 210.79,
    "2026-01-21": 215.61, "2026-01-20": 218.24, "2026-01-19": 218.25,
    "2026-01-16": 215.91, "2026-01-15": 217.54, "2026-01-14": 220.42,
    "2026-01-13": 217.08, "2026-01-12": 216.59, "2026-01-09": 215.76,
    "2026-01-08": 214.44, "2026-01-07": 210.47, "2026-01-06": 208.49,
    "2026-01-05": 205.00, "2026-01-02": 204.33, "2026-01-01": 203.98,
    "2025-12-31": 204.83, "2025-12-30": 205.16, "2025-12-29": 206.17,
    "2025-12-26": 205.82, "2025-12-25": 205.82, "2025-12-24": 205.82,
    "2025-12-23": 205.81, "2025-12-22": 205.65, "2025-12-19": 206.17,
    "2025-12-18": 208.61, "2025-12-17": 211.63, "2025-12-16": 214.42,
    "2025-12-15": 215.57, "2025-12-12": 219.38, "2025-12-11": 225.18,
    "2025-12-10": 226.00, "2025-12-09": 226.18, "2025-12-08": 225.51,
    "2025-12-05": 226.83, "2025-12-04": 226.53, "2025-12-03": 228.63,
    "2025-12-02": 231.78, "2025-12-01": 235.25, "2025-11-28": 237.09,
    "2025-11-27": 238.24, "2025-11-26": 240.23, "2025-11-25": 242.03,
    "2025-11-24": 242.34, "2025-11-21": 243.86, "2025-11-20": 241.12,
    "2025-11-19": 243.82, "2025-11-18": 246.30, "2025-11-17": 243.83,
    "2025-11-14": 240.99, "2025-11-13": 242.92, "2025-11-12": 244.23,
    "2025-11-11": 244.33, "2025-11-10": 243.01, "2025-11-07": 246.32,
    "2025-11-06": 243.82, "2025-11-05": 244.62, "2025-11-04": 243.77,
    "2025-11-03": 242.64, "2025-10-31": 244.65, "2025-10-30": 244.14,
    "2025-10-29": 246.65, "2025-10-28": 249.13, "2025-10-27": 247.67,
    "2025-10-24": 265.80, "2025-10-23": 265.87, "2025-10-22": 265.31,
    "2025-10-21": 261.83, "2025-10-20": 268.61, "2025-10-17": 272.80,
    "2025-10-16": 266.01, "2025-10-15": 264.48, "2025-10-14": 266.09,
    "2025-10-13": 263.61, "2025-10-10": 264.01, "2025-10-09": 258.53,
    "2025-10-08": 256.54, "2025-10-07": 257.68, "2025-10-06": 257.24,
    "2025-10-03": 255.85, "2025-10-02": 254.72, "2025-10-01": 254.14,
    "2025-09-30": 254.36, "2025-09-29": 256.01, "2025-09-26": 258.58,
    "2025-09-25": 259.08, "2025-09-24": 259.21, "2025-09-23": 259.79,
    "2025-09-22": 258.54, "2025-09-19": 240.49, "2025-09-18": 236.86,
    "2025-09-17": 239.67, "2025-09-16": 246.77, "2025-09-15": 251.06,
    "2025-09-12": 262.35, "2025-09-11": 260.84, "2025-09-10": 267.79,
    "2025-09-09": 270.67, "2025-09-08": 272.39, "2025-09-05": 263.21,
    "2025-09-04": 267.57, "2025-09-03": 270.12, "2025-09-02": 272.65,
    "2025-09-01": 263.32, "2025-08-29": 263.31, "2025-08-28": 259.96,
    "2025-08-27": 261.77, "2025-08-26": 262.18, "2025-08-25": 261.50,
    "2025-08-22": 261.03, "2025-08-21": 268.92, "2025-08-20": 267.23,
    "2025-08-19": 263.23, "2025-08-18": 264.87, "2025-08-15": 264.91,
    "2025-08-14": 264.98, "2025-08-13": 262.64, "2025-08-12": 267.61,
    "2025-08-11": 273.09, "2025-08-08": 271.83, "2025-08-07": 275.29,
    "2025-08-06": 276.60, "2025-08-05": 276.75, "2025-08-04": 276.61,
    "2025-08-01": 280.61, "2025-07-31": 277.69, "2025-07-30": 274.49,
    "2025-07-29": 271.54, "2025-07-28": 273.75, "2025-07-25": 271.71,
    "2025-07-24": 271.89, "2025-07-23": 279.78, "2025-07-22": 284.30,
    "2025-07-21": 284.32, "2025-07-18": 284.29, "2025-07-17": 285.55,
    "2025-07-16": 289.55, "2025-07-15": 286.65, "2025-07-14": 284.48,
    "2025-07-11": 283.19, "2025-07-10": 278.65, "2025-07-09": 278.39,
    "2025-07-08": 285.57, "2025-07-07": 285.52, "2025-07-04": 273.66,
    "2025-07-03": 273.99, "2025-07-02": 280.61, "2025-07-01": 281.64,
    "2025-06-30": 284.36, "2025-06-27": 301.30, "2025-06-26": 301.82,
    "2025-06-25": 302.06, "2025-06-24": 292.06, "2025-06-23": 303.61,
    "2025-06-20": 305.85, "2025-06-19": 309.88, "2025-06-18": 301.98,
    "2025-06-17": 291.17, "2025-06-16": 292.29, "2025-06-13": 302.24,
    "2025-06-12": 291.13, "2025-06-11": 286.56, "2025-06-10": 291.26,
    "2025-06-09": 293.93, "2025-06-06": 296.54, "2025-06-05": 300.24,
    "2025-06-04": 295.72, "2025-06-03": 303.54, "2025-06-02": 311.74,
    "2025-05-30": 319.18, "2025-05-29": 317.16, "2025-05-28": 308.88,
    "2025-05-27": 303.21, "2025-05-26": 301.93, "2025-05-23": 301.69,
    "2025-05-22": 292.99, "2025-05-21": 292.41, "2025-05-20": 290.21,
    "2025-05-19": 292.99, "2025-05-16": 291.19, "2025-05-15": 297.09,
    "2025-05-14": 296.29, "2025-05-13": 304.96, "2025-05-12": 309.92,
    "2025-05-09": 327.75, "2025-05-08": 328.42, "2025-05-07": 335.82,
    "2025-05-06": 338.76, "2025-04-25": 338.94, "2025-04-24": 325.39,
    "2025-04-23": 324.60, "2025-04-22": 325.95, "2025-04-21": 322.97,
    "2025-04-18": 323.19, "2025-04-17": 323.39, "2025-04-16": 332.70,
    "2025-04-15": 332.73, "2025-04-14": 346.69, "2025-04-11": 370.62,
    "2025-04-10": 354.92, "2025-04-09": 337.56, "2025-04-08": 351.62,
    "2025-04-03": 319.78, "2025-04-02": 306.50, "2025-04-01": 311.91,
    "2025-03-31": 313.59, "2025-03-28": 314.55, "2025-03-27": 312.79,
    "2025-03-26": 306.06, "2025-03-25": 294.06, "2025-03-24": 310.31,
    "2025-03-21": 324.19, "2025-03-20": 300.20, "2025-03-19": 271.06,
    "2025-03-18": 252.18, "2025-03-17": 253.24, "2025-03-14": 256.37,
    "2025-03-13": 259.87, "2025-03-12": 259.70, "2025-03-11": 261.66,
    "2025-03-10": 261.01, "2025-03-07": 257.21, "2025-03-06": 257.90,
    "2025-03-05": 253.91, "2025-03-04": 256.13, "2025-03-03": 252.18,
    "2025-02-28": 252.00, "2025-02-27": 248.80, "2025-02-26": 252.78,
    "2025-02-25": 251.58, "2025-02-24": 256.11, "2025-02-21": 243.73,
    "2025-02-20": 244.22, "2025-02-19": 242.28, "2025-02-18": 242.38,
    "2025-02-17": 242.31, "2025-02-14": 245.21, "2025-02-13": 248.09,
    "2025-02-12": 251.13, "2025-02-11": 250.11, "2025-02-10": 252.07,
    "2025-02-07": 250.17, "2025-02-06": 250.62, "2025-02-05": 251.09,
    "2025-02-04": 255.02, "2025-02-03": 249.60, "2025-01-31": 253.54,
    "2025-01-30": 257.33, "2025-01-29": 256.83, "2025-01-28": 259.90,
    "2025-01-27": 254.85, "2025-01-24": 260.17, "2025-01-23": 262.67,
    "2025-01-22": 265.66, "2025-01-21": 266.29, "2025-01-20": 269.40,
    "2025-01-17": 268.88, "2025-01-16": 265.56, "2025-01-15": 271.29,
    "2025-01-14": 272.67, "2025-01-13": 269.05, "2025-01-10": 264.56,
    "2025-01-09": 264.99, "2025-01-08": 263.55, "2025-01-07": 254.36,
    "2025-01-06": 255.90, "2025-01-03": 257.77, "2025-01-02": 259.77,
    "2025-01-01": 259.76,
}


def _load_hardcoded() -> pd.Series:
    """Hafızadaki tarihsel taban verisini pd.Series olarak döndürür."""
    s = pd.Series(
        _HARDCODED_CDS_DATA,
        dtype=float,
    )
    s.index = pd.to_datetime(s.index)
    return s.sort_index()


# ── Yardımcı: Sayı parse et ───────────────────────────────────────
def _to_float(s: str) -> float | None:
    try:
        return float(str(s).strip().replace(",", ".").replace(" ", ""))
    except (ValueError, AttributeError):
        return None


# ══════════════════════════════════════════════════════════════════
# Kaynak 1: Manuel CSV
# ══════════════════════════════════════════════════════════════════

def _load_from_csv() -> pd.Series | None:
    candidates = [
        "cds_turkey_5y.csv",
        "Turkey CDS USD 5Y Historical Data.csv",
        "turkey_cds.csv",
    ]
    for path in candidates:
        if not os.path.exists(path):
            continue
        try:
            df = pd.read_csv(path)
            for date_col in ["Date", "Tarih", "date"]:
                if date_col in df.columns:
                    df["_date"] = pd.to_datetime(df[date_col], dayfirst=True, errors="coerce")
                    break
            for val_col in ["Close", "Price", "close", "Kapanış", "Şimdi", "Value"]:
                if val_col in df.columns:
                    df["_val"] = pd.to_numeric(
                        df[val_col].astype(str).str.replace(",", ""), errors="coerce"
                    )
                    break
            series = df.set_index("_date")["_val"].dropna().sort_index()
            if not series.empty:
                print(f"  CSV okundu: {path} ({len(series)} kayıt)")
                return series
        except Exception as e:
            print(f"  CSV hatası ({path}): {e}")
    return None


# ══════════════════════════════════════════════════════════════════
# Kaynak 2: worldgovernmentbonds.com (birincil otomatik kaynak)
# ══════════════════════════════════════════════════════════════════

def _scrape_worldgovernmentbonds() -> pd.Series | None:
    """
    worldgovernmentbonds.com'dan Türkiye CDS geçmişini çeker.
    Sayfada 'Turkey 5-Year CDS Historical Data' tablosu var.
    """
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("  ⚠ Playwright yüklü değil.")
        return None

    print("  worldgovernmentbonds.com açılıyor...")
    all_data = []

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx     = browser.new_context(user_agent=UA, locale="en-US")
        page    = ctx.new_page()

        try:
            page.goto(WGB_URL, wait_until="domcontentloaded", timeout=30_000)
            page.wait_for_timeout(4_000)

            # JavaScript ile tüm tablo satırlarını çek
            rows = page.evaluate("""
                () => {
                    const out = [];
                    // Sayfadaki tüm tabloları tara
                    const tables = document.querySelectorAll('table');
                    for (const tbl of tables) {
                        const rows = tbl.querySelectorAll('tr');
                        for (const tr of rows) {
                            const tds = tr.querySelectorAll('td');
                            if (tds.length >= 2) {
                                out.push({
                                    date:  tds[0]?.innerText?.trim() || '',
                                    value: tds[1]?.innerText?.trim() || '',
                                });
                            }
                        }
                        if (out.length > 10) break;  // İlk dolu tablo yeterli
                    }
                    return out;
                }
            """)

            for row in rows:
                # Tarih formatı: "Mar 18, 2026" ya da "18/03/2026"
                dt = None
                for fmt in ["%b %d, %Y", "%d/%m/%Y", "%Y-%m-%d", "%m/%d/%Y"]:
                    try:
                        dt = pd.Timestamp(time.strftime(
                            "%Y-%m-%d",
                            time.strptime(row["date"].strip(), fmt)
                        ))
                        break
                    except Exception:
                        pass
                if dt is None:
                    continue

                val = _to_float(row["value"])
                # CDS 5Y Türkiye: 100–1000 baz puan arası makul
                if val is not None and 50 < val < 2000:
                    all_data.append({"Date": dt, "value": val})

        except Exception as e:
            print(f"  ⚠ worldgovernmentbonds hatası: {e}")
        finally:
            browser.close()

    if not all_data:
        return None

    df = pd.DataFrame(all_data)
    series = df.set_index("Date")["value"].sort_index()
    series = series[~series.index.duplicated(keep="first")]
    print(f"  worldgovernmentbonds: {len(series)} kayıt")
    return series


# ══════════════════════════════════════════════════════════════════
# Kaynak 3: investing.com (fallback)
# ══════════════════════════════════════════════════════════════════

TR_MONTHS = {
    "Oca": 1, "Şub": 2, "Mar": 3, "Nis": 4, "May": 5, "Haz": 6,
    "Tem": 7, "Ağu": 8, "Eyl": 9, "Eki": 10, "Kas": 11, "Ara": 12,
}

def _parse_tr_date(s: str) -> pd.Timestamp | None:
    parts = s.strip().split()
    if len(parts) != 3:
        return None
    try:
        day   = int(parts[0])
        month = TR_MONTHS.get(parts[1])
        year  = int(parts[2])
        if month is None:
            return None
        return pd.Timestamp(year=year, month=month, day=day)
    except Exception:
        return None


def _scrape_investing() -> pd.Series | None:
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return None

    today_str = pd.Timestamp.today().strftime("%Y-%m-%d")
    print("  investing.com (Playwright + tarih aralığı) açılıyor...")
    all_data: list[dict] = []

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx  = browser.new_context(user_agent=UA, locale="tr-TR",
                                    viewport={"width": 1280, "height": 900})
        page = ctx.new_page()

        # ── Tarayıcının kendi API çağrısını yakala ────────────────────
        captured_rows: list[dict] = []

        def _on_response(response):
            if "financialdata/historical" in response.url and response.status == 200:
                try:
                    body = response.json()
                    if isinstance(body, dict) and "data" in body:
                        captured_rows.extend(body["data"])
                        print(f"  API yanıtı yakalandı: {len(body['data'])} kayıt")
                except Exception:
                    pass

        page.on("response", _on_response)

        try:
            page.goto(INV_URL, wait_until="domcontentloaded", timeout=30_000)
            page.wait_for_timeout(4_000)

            # Cookie popup kapat
            for sel in ["#onetrust-accept-btn-handler",
                        "button:has-text('Kabul et')",
                        "button:has-text('Accept')"]:
                try:
                    loc = page.locator(sel)
                    if loc.count() > 0:
                        loc.first.click()
                        page.wait_for_timeout(1_000)
                        break
                except Exception:
                    pass

            # Date picker aç
            for sel in ["[data-test='datepicker-button']",
                        "div[class*='dateRangePicker']",
                        "button:has-text('2026')",
                        "button:has-text('2025')"]:
                try:
                    if page.locator(sel).count() > 0:
                        page.locator(sel).first.click()
                        page.wait_for_timeout(1_500)
                        break
                except Exception:
                    pass

            # Hidden input[type=date] elementlerine tarihleri JS ile yaz
            page.evaluate(f"""() => {{
                const inputs = document.querySelectorAll('input[type="date"]');
                if (inputs.length >= 2) {{
                    inputs[0].value = '2025-01-01';
                    inputs[0].dispatchEvent(new Event('change', {{bubbles: true}}));
                    inputs[1].value = '{today_str}';
                    inputs[1].dispatchEvent(new Event('change', {{bubbles: true}}));
                }}
            }}""")
            page.wait_for_timeout(800)

            # Uygula butonuna bas → bu iç API çağrısını tetikler
            for sel in ["span:has-text('Uygula')",
                        "button:has-text('Uygula')",
                        "div.bg-v2-blue span",
                        "[data-test='apply-btn']"]:
                try:
                    loc = page.locator(sel)
                    if loc.count() > 0:
                        loc.first.click()
                        print("  'Uygula' tıklandı, API yanıtı bekleniyor...")
                        break
                except Exception:
                    pass

            # API yanıtı bekleniyor
            page.wait_for_timeout(7_000)

            # ── Yakalanan API verisini parse et ───────────────────────
            if captured_rows:
                for item in captured_rows:
                    # rowDateTimestamp = "2026-03-20T00:00:00Z" (ISO) — en güvenilir
                    # rowDateRaw = Unix timestamp (saniye) — KULLANMA
                    dt_raw  = (item.get("rowDateTimestamp") or item.get("rowDate") or "")
                    # last_closeRaw = "307.079..." (noktalı float) — güvenilir
                    # last_close = "307,08" (Türkçe virgüllü) — sorunlu
                    val_raw = (item.get("last_closeRaw") or item.get("last_close") or "")
                    try:
                        dt  = pd.Timestamp(str(dt_raw).strip()[:10])
                        val = _to_float(str(val_raw))
                        if val and 50 < val < 2000:
                            all_data.append({"Date": dt, "value": val})
                    except Exception:
                        pass

            # ── Fallback: DOM tablosunu oku ───────────────────────────
            if not all_data:
                rows = page.evaluate("""() => {
                    const out = [];
                    const trs = document.querySelectorAll(
                        'table tbody tr, [data-test="historical-data-table"] tr'
                    );
                    for (const tr of trs) {
                        const tds = tr.querySelectorAll('td');
                        if (tds.length >= 2)
                            out.push({
                                date:  tds[0]?.innerText?.trim() || '',
                                close: tds[1]?.innerText?.trim() || '',
                            });
                    }
                    return out;
                }""")
                for row in rows:
                    dt  = _parse_tr_date(row["date"])
                    val = _to_float(row["close"])
                    if dt and val and 50 < val < 2000:
                        all_data.append({"Date": dt, "value": val})
                if all_data:
                    print(f"  DOM fallback: {len(all_data)} satır")

        except Exception as e:
            print(f"  ⚠ investing.com hatası: {e}")
        finally:
            browser.close()

    if not all_data:
        return None

    df = pd.DataFrame(all_data)
    series = df.set_index("Date")["value"].sort_index()
    series = series[~series.index.duplicated(keep="first")]
    print(f"  investing.com: {len(series)} kayıt")
    return series


# ══════════════════════════════════════════════════════════════════
# Ana fonksiyon
# ══════════════════════════════════════════════════════════════════

def fetch_cds(csv_path: str = None):
    print("\n--- CDS 5Y Verisi Çekiliyor ---")

    df_excel = read_fora()
    if df_excel is None or df_excel.empty:
        print("FORA.xlsx bulunamadı veya boş.")
        return

    df_excel["Min Tarih"] = pd.to_datetime(df_excel["Min Tarih"], dayfirst=True, errors="coerce")
    df_excel["Max Tarih"] = pd.to_datetime(df_excel["Max Tarih"], dayfirst=True, errors="coerce")

    if COLUMN_NAME not in df_excel.columns:
        df_excel[COLUMN_NAME] = None

    # ── 1. Tarihsel taban: hafızadaki hardcoded veri ──────────────
    series = _load_hardcoded()
    print(f"  Hardcoded taban: {len(series)} kayıt ({series.index[0].date()} → {series.index[-1].date()})")

    # ── 2. Live overlay: investing.com'dan son ~20 günlük veri ───
    live = _scrape_investing()
    if live is not None and not live.empty:
        # Hardcoded + live birleştir, live verisi öncelikli
        series = pd.concat([series, live])
        series = series[~series.index.duplicated(keep="last")]
        series = series.sort_index()
        print(f"  Live overlay eklendi: toplam {len(series)} kayıt")

    # ── 3. FORA satırlarına haftalık ortalama yaz ─────────────────
    updated = 0
    for idx, row in df_excel.iterrows():
        r_start = row["Min Tarih"]
        r_end   = row["Max Tarih"]
        if pd.isna(r_start) or pd.isna(r_end):
            continue
        mask   = (series.index >= r_start) & (series.index <= r_end)
        subset = series.loc[mask].dropna()
        if not subset.empty:
            df_excel.at[idx, COLUMN_NAME] = round(subset.mean(), 2)
            updated += 1

    print(f"  CDS 5Y: {updated} satır güncellendi.")

    for col in ["Min Tarih", "Max Tarih"]:
        if pd.api.types.is_datetime64_any_dtype(df_excel[col]):
            df_excel[col] = df_excel[col].dt.strftime("%d.%m.%Y")

    save_fora(df_excel)
    print("FORA.xlsx kaydedildi (CDS 5Y).\n")


if __name__ == "__main__":
    fetch_cds()
