"""
fetch_tcmb_mevduat.py
---------------------
EVDS3'ten TCMB Mevduat faiz oranlarını çeker ve FORA.xlsx'e yazar.

Kaynak  : EVDS3 /igmevdsms-dis/fe endpoint (Playwright oturumu ile)
Seriler : TP.TRY.MT01 → TCMB 1M
          TP.TRY.MT02 → TCMB 3M
Frekans : Haftalık (frequency=3)
"""

import pandas as pd
from src.utils import read_fora, save_fora
from src.evds3_client import fetch_evds3_series, items_to_series

# Seri konfigürasyonu
SERIES_CONFIG = {
    "TP.TRY.MT01": "TCMB 1M",
    "TP.TRY.MT02": "TCMB 3M",
}


def fetch_tcmb_mevduat():
    print("\n--- TCMB Mevduat Faiz Oranı Çekiliyor (1M & 3M) ---")

    df_excel = read_fora()
    if df_excel is None or df_excel.empty:
        print("Hata: FORA.xlsx bulunamadı veya boş.")
        return

    for col in SERIES_CONFIG.values():
        if col not in df_excel.columns:
            df_excel[col] = None

    df_excel["Min Tarih"] = pd.to_datetime(df_excel["Min Tarih"], dayfirst=True, errors="coerce")
    df_excel["Max Tarih"] = pd.to_datetime(df_excel["Max Tarih"], dayfirst=True, errors="coerce")

    # Tarih aralığı
    min_date = df_excel["Min Tarih"].min()
    max_date = df_excel["Max Tarih"].max()
    start_str = min_date.strftime("%d-%m-%Y")
    end_str   = max_date.strftime("%d-%m-%Y")
    print(f"Tarih Aralığı: {start_str} - {end_str}")

    # EVDS3'ten tek istekle her iki seriyi çek
    items = fetch_evds3_series(
        list(SERIES_CONFIG.keys()),
        start_date=start_str,
        end_date=end_str,
    )
    if not items:
        print("Veri alınamadı.")
        return

    # Her seri için pandas Series oluştur
    series_map = {
        col_name: items_to_series(items, series_code)
        for series_code, col_name in SERIES_CONFIG.items()
    }

    # Haftalık ortalamayı Excel satırlarına yaz
    updated_count = 0
    for idx, row in df_excel.iterrows():
        r_start = row["Min Tarih"]
        r_end   = row["Max Tarih"]
        if pd.isna(r_start) or pd.isna(r_end):
            continue

        row_updated = False
        for col_name, series_vals in series_map.items():
            mask   = (series_vals.index >= r_start) & (series_vals.index <= r_end)
            subset = series_vals.loc[mask].dropna()
            if not subset.empty:
                df_excel.at[idx, col_name] = subset.mean()
                row_updated = True

        if row_updated:
            updated_count += 1

    print(f"TCMB Mevduat: {updated_count} satır güncellendi.")

    # Tarih formatını geri yükle
    for col in ["Min Tarih", "Max Tarih"]:
        if pd.api.types.is_datetime64_any_dtype(df_excel[col]):
            df_excel[col] = df_excel[col].dt.strftime("%d.%m.%Y")

    # TCMB 1M ve TCMB 3M kolon sırasını koru
    cols = list(df_excel.columns)
    if "TCMB 1M" in cols and "TCMB 3M" in cols:
        new_cols = []
        for c in cols:
            if c == "TCMB 1M":
                new_cols.append("TCMB 1M")
                if "TCMB 3M" in cols:
                    new_cols.append("TCMB 3M")
            elif c == "TCMB 3M":
                continue
            else:
                new_cols.append(c)
        # 3M kaçırıldıysa sona ekle
        if "TCMB 3M" in cols and "TCMB 3M" not in new_cols:
            new_cols.append("TCMB 3M")
        df_excel = df_excel[new_cols]

    save_fora(df_excel)
    print("FORA.xlsx kaydedildi.")


if __name__ == "__main__":
    fetch_tcmb_mevduat()
