import pandas as pd
import os
from openpyxl import load_workbook
from src.utils import save_fora

def add_details_sheet():
    file_path = "FORA.xlsx"
    
    # ... (Keep data def) ...
    # (re-defining data variable for context, but I will target the imports and fallback)
    
    if not os.path.exists(file_path):
        print(f"Error: {file_path} does not exist.")
        return

    # Define the details content
    data = [
        {
            "Feature": "AOFF (Ağırlıklı Ortalama Fonlama Maliyeti)",
            "Source": "TCMB EVDS3 (TP.APIFON4, Playwright)",
            "Logic": "Her satırın tarih aralığındaki (Min Tarih - Max Tarih) günlük değerlerin aritmetik ortalaması alınır."
        },
        {
            "Feature": "TLREF (Türk Lirası Gecelik Referans Faiz Oranı)",
            "Source": "Borsa İstanbul Web Sitesi",
            "Logic": "Her satırın tarih aralığındaki günlük kapanış değerlerinin aritmetik ortalaması alınır."
        },
        {
            "Feature": "PP Getiri (Para Piyasası Fonları Getirisi)",
            "Source": "TEFAS (Para Piyasası Şemsiye Fonu)",
            "Logic": "İlgili tarih aralığı için TEFAS'tan çekilen tüm Para Piyasası fonlarının getirilerinin ortalaması alınır."
        },
        {
            "Feature": "Web Tüfe",
            "Source": "webtufe.com",
            "Logic": "Aylık veri olarak çekilir. Ayın son gününü kapsayan haftaya ilgili ayın Web Tüfe değeri atanır."
        },
        {
            "Feature": "TCMB 1M (1 Aya Kadar Vadeli Mevduat)",
            "Source": "TCMB EVDS3 (TP.TRY.MT01, Playwright)",
            "Logic": "TCMB'den haftalık çekilen '1 Aya Kadar Vadeli Mevduat' faiz oranının, ilgili satırdaki hafta aralığına denk gelen ortalaması."
        },
        {
            "Feature": "TCMB 3M (1-3 Aya Kadar Vadeli Mevduat)",
            "Source": "TCMB EVDS3 (TP.TRY.MT02, Playwright)",
            "Logic": "TCMB'den haftalık çekilen '1-3 Aya Kadar Vadeli Mevduat' faiz oranının, ilgili satırdaki hafta aralığına denk gelen ortalaması."
        }
    ]
    
    df_details = pd.DataFrame(data)

    print("Adding 'Details' sheet...")
    
    try:
        # Optimistic: Append mode (preserves Sheet1 formatting)
        with pd.ExcelWriter(file_path, engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
            df_details.to_excel(writer, sheet_name='Details', index=False)
            
        print("'Details' sayfası başarıyla eklendi.")
        
    except Exception as e:
        print(f"Excel güncelleme hatası: {e}")

if __name__ == "__main__":
    add_details_sheet()
