"""
fetch_bist100.py
----------------
EVDS3'ten BIST 100 Endeksi verisini çeker ve FORA.xlsx'e yazar.

Kaynak  : EVDS3 /igmevdsms-dis/fe endpoint (Playwright oturumu ile)
Seri    : TP.MK.F.BILESIK
Frekans : Haftalık (frequency=3)
"""

import pandas as pd
from src.utils import read_fora, save_fora
from src.evds3_client import fetch_evds3_series, items_to_series

SERIES_CODE = "TP.MK.F.BILESIK"
COLUMN_NAME = "BIST100"


def fetch_bist100():
    print("\n--- BIST 100 Verisi Çekiliyor (EVDS3) ---")

    df_excel = read_fora()
    if df_excel is None or df_excel.empty:
        print("FORA.xlsx bulunamadı veya boş.")
        return

    if COLUMN_NAME not in df_excel.columns:
        df_excel[COLUMN_NAME] = None

    df_excel["Min Tarih"] = pd.to_datetime(df_excel["Min Tarih"], dayfirst=True, errors="coerce")
    df_excel["Max Tarih"] = pd.to_datetime(df_excel["Max Tarih"], dayfirst=True, errors="coerce")

    # Tarih aralığı
    min_date = df_excel["Min Tarih"].min()
    max_date = df_excel["Max Tarih"].max()
    start_str = min_date.strftime("%d-%m-%Y")
    end_str   = max_date.strftime("%d-%m-%Y")
    print(f"Tarih Aralığı: {start_str} - {end_str}")

    # EVDS3'ten veri çek
    items = fetch_evds3_series([SERIES_CODE], start_date=start_str, end_date=end_str)
    if not items:
        print("Veri alınamadı.")
        return

    series_vals = items_to_series(items, SERIES_CODE)
    print(f"  Geçerli BIST100 değeri sayısı: {len(series_vals.dropna())}")

    # Haftalık ortalamayı Excel satırlarına yaz
    updated_count = 0
    for idx, row in df_excel.iterrows():
        r_start = row["Min Tarih"]
        r_end   = row["Max Tarih"]
        if pd.isna(r_start) or pd.isna(r_end):
            continue
        mask   = (series_vals.index >= r_start) & (series_vals.index <= r_end)
        subset = series_vals.loc[mask].dropna()
        if not subset.empty:
            df_excel.at[idx, COLUMN_NAME] = subset.mean()
            updated_count += 1

    print(f"BIST 100: {updated_count} satır güncellendi.")

    # Tarih formatını geri yükle
    for col in ["Min Tarih", "Max Tarih"]:
        if pd.api.types.is_datetime64_any_dtype(df_excel[col]):
            df_excel[col] = df_excel[col].dt.strftime("%d.%m.%Y")

    save_fora(df_excel)
    print("FORA.xlsx kaydedildi.")


if __name__ == "__main__":
    fetch_bist100()
