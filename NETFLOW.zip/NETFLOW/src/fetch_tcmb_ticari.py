"""
fetch_tcmb_ticari.py
--------------------
TCMB EVDS3'ten Ticari Kredi (Spot) Faiz Oranı verisi çeker ve FORA.xlsx'e yazar.

Kaynak  : https://evds3.tcmb.gov.tr/charts/portlet/Njk4YjFjMzljNjAxMWY0MDU2MDdjYzll/tr
Seri    : TP_KTF17  →  "Ticari Krediler (TL, Akım, %)"
Frekans : Haftalık (frequency=3)

Yöntem  : Playwright headless browser ile portlet sayfası açılır,
          network intercept ile /igmevdsms-dis/fe POST response'u yakalanır,
          çekilen JSON verisi parse edilerek FORA.xlsx'e yazılır.
"""

import json
import time
import pandas as pd
from playwright.sync_api import sync_playwright

from src.utils import read_fora, save_fora

# ---------------------------------------------------------------------------
PORTLET_URL = (
    "https://evds3.tcmb.gov.tr"
    "/charts/portlet/Njk4YjFjMzljNjAxMWY0MDU2MDdjYzll/tr"
)
DATA_ENDPOINT   = "/igmevdsms-dis/fe"
TARGET_API_KEY  = "TP_KTF17"   # response JSON sütun adı
COLUMN_NAME         = "Spot Kredi"

UA = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)
# ---------------------------------------------------------------------------


def _fetch_all_series_via_browser() -> list[dict]:
    """
    Playwright headless browser ile portlet sayfasını açar ve
    /igmevdsms-dis/fe endpoint'inin response'unu yakalar.
    Tüm haftalık kayıtları (items listesi) döndürür.
    """
    captured = []

    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True)
        context = browser.new_context(user_agent=UA)
        page = context.new_page()

        # POST /igmevdsms-dis/fe response'unu yakala
        def handle_response(response):
            if DATA_ENDPOINT in response.url:
                try:
                    body = response.json()
                    items = body.get("items", [])
                    if items:
                        captured.extend(items)
                        print(f"  Intercepted {len(items)} items from {response.url}")
                except Exception as e:
                    print(f"  Response parse error: {e}")

        page.on("response", handle_response)

        print("  Opening portlet page (headless)...")
        page.goto(PORTLET_URL, wait_until="networkidle", timeout=60_000)

        # Sayfanın tüm chart isteklerini tamamlamasını bekle
        time.sleep(3)

        browser.close()

    return captured


def fetch_tcmb_ticari():
    print("\n--- Starting TCMB Ticari Kredi Fetch (Spot, Yıllık Basit%) ---")

    df_excel = read_fora()
    if df_excel is None or df_excel.empty:
        print("Error: FORA.xlsx not found or empty.")
        return

    # Kolon yoksa oluştur
    if COLUMN_NAME not in df_excel.columns:
        df_excel[COLUMN_NAME] = None

    # Tarih parse
    df_excel["Min Tarih"] = pd.to_datetime(
        df_excel["Min Tarih"], dayfirst=True, errors="coerce"
    )
    df_excel["Max Tarih"] = pd.to_datetime(
        df_excel["Max Tarih"], dayfirst=True, errors="coerce"
    )

    # Veriyi browser ile çek
    items = _fetch_all_series_via_browser()

    if not items:
        print("Error: No data captured from browser. Check network or portlet URL.")
        return

    print(f"Fetched {len(items)} total weekly records.")

    # items → DataFrame
    df_api = pd.DataFrame(items)
    df_api["Date"] = pd.to_datetime(df_api["Tarih"], dayfirst=True)
    df_api.set_index("Date", inplace=True)

    if TARGET_API_KEY not in df_api.columns:
        print(f"Error: '{TARGET_API_KEY}' column not found. Available: {list(df_api.columns)}")
        return

    # Virgüllü ondalık → float  (EVDS3 "62,19" gibi döndürür)
    df_api[TARGET_API_KEY] = (
        df_api[TARGET_API_KEY]
        .astype(str)
        .str.replace(",", ".", regex=False)
        .pipe(pd.to_numeric, errors="coerce")
    )
    series_vals = df_api[TARGET_API_KEY].dropna()
    print(f"  Valid '{TARGET_API_KEY}' values: {len(series_vals)}")
    print(f"  Sample (latest 3): {series_vals.tail(3).to_dict()}")

    # Excel satırlarına haftalık ortalamaları yaz
    updated_count = 0
    for idx, row in df_excel.iterrows():
        r_start = row["Min Tarih"]
        r_end   = row["Max Tarih"]

        if pd.isna(r_start) or pd.isna(r_end):
            continue

        mask   = (df_api.index >= r_start) & (df_api.index <= r_end)
        subset = df_api.loc[mask, TARGET_API_KEY].dropna()

        if not subset.empty:
            df_excel.at[idx, COLUMN_NAME] = round(subset.mean(), 4)
            updated_count += 1

    print(f"Updated {updated_count} rows with '{COLUMN_NAME}'.")

    # Tarih formatını geri yükle
    for col in ["Min Tarih", "Max Tarih"]:
        if pd.api.types.is_datetime64_any_dtype(df_excel[col]):
            df_excel[col] = df_excel[col].dt.strftime("%d.%m.%Y")

    save_fora(df_excel)
    print("Saved FORA.xlsx.")


if __name__ == "__main__":
    fetch_tcmb_ticari()
