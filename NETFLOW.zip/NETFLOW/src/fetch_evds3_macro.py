"""
fetch_evds3_macro.py
--------------------
EVDS3'ten makroekonomik göstergeleri çeker ve FORA.xlsx'e yazar.

Çekilen veriler:
  - Tüketici Kredi Faizi   : TP.TRY.KT01  (Haftalık)
  - Kapasite Kullanım Oranı : TP.KKO2.IS   (Aylık → forward-fill)
  - Tüketici Güven Endeksi  : TP.TG2.Y01   (Aylık → forward-fill)
  - DİBS Gösterge Faiz 2Y   : TP.GS.G02   (Günlük → haftalık ort.)
  - DİBS Gösterge Faiz 10Y  : TP.GS.G10   (Günlük → haftalık ort.)
  - Net Rezerv              : TP.AB.N01    (Haftalık)
  - Zorunlu Karşılıklar     : TP.ZKO.YN01 (Aylık → forward-fill)
  - Sanayi Üretim Endeksi   : TP.SAUam2.Y1 (Aylık → forward-fill)

Not: Seri kodları doğru çalışmazsa EVDS3 arayüzünden kontrol edilmelidir.
     EVDS3 yanıtında nokta (.) alt çizgiye (_) dönüşür.
"""

import pandas as pd
from src.utils import read_fora, save_fora
from src.evds3_client import fetch_evds3_series, items_to_series


# ── Seri tanımları ─────────────────────────────────────────────────
# Duplikat kontrolü:
#   - TCMB 1M/3M zaten FORA'da var → Mevduat_Faizi_1M/3M eklenmedi
#   - İhtiyaç Kredi (TP.KTF10) zaten var → Tüketici_Kredi (TP.TRY.KT01) eklenmedi
#   - TUIK_TUFE ve WebTufe_TUFE → fetch_webtufe_tufe.py (apiwebtufe.com) → burada çekilmedi
# EVDS3 portlet API'de çalışmayan seriler kaldırıldı:
#   - DİBS 2Y/10Y (TP.GDDS.2Y/10Y) → HTTP 500 (yfinance'a taşındı)
#   - M2 Para Arzı (TP.PR.M2A) → HTTP 500
#   - Swap Faizi (TP.PY.P01) → HTTP 500
SERIES = [
    {
        "code": "TP.KKO2.IS.TOP",
        "col_name": "KKO",
        "freq": "5",   # aylık
        "agg": "avg",
        "desc": "Kapasite Kullanım Oranı (İmalat Sanayi Toplam)",
    },
    {
        "code": "TP.TG2.Y01",
        "col_name": "Tuketici_Guven",
        "freq": "5",   # aylık
        "agg": "avg",
        "desc": "Tüketici Güven Endeksi",
    },
    {
        "code": "TP.AB.N01",
        "col_name": "Net_Rezerv",
        "freq": "3",   # haftalık
        "agg": "last",
        "desc": "TCMB Net Rezerv (Milyon USD)",
    },
    {
        "code": "TP.TSANAYMT2021.Y1",
        "col_name": "Sanayi_Uretim",
        "freq": "5",   # aylık
        "agg": "avg",
        "desc": "Sanayi Üretim Endeksi (2021=100, Mevsim+Takvim Etkisinden Arındırılmış)",
    },
    {
        "code": "TP.KTF10",
        "col_name": "Ihtiyac_Kredi_Faizi",
        "freq": "3",   # haftalık
        "agg": "avg",
        "desc": "İhtiyaç Kredisi Faiz Oranı (TL, Akım)",
    },
    {
        "code": "TP.FHGE.S01",
        "col_name": "Fin_Guven",
        "freq": "5",   # aylık
        "agg": "avg",
        "desc": "Finansal Hizmetler Güven Endeksi",
    },
    # ── Enflasyon Serileri ──────────────────────────────────────────
    # Not: TP.FG.J0 (TUFE indeks seviyesi ~3500) kaldırıldı; yıllık %
    # değişim için TUIK_TUFE_Yillik (ENAG API, %30.7) kullanılıyor.
    {
        "code": "TP.FE.OKTG02",
        "col_name": "Cekirdek_Enflasyon",
        "freq": "5",   # aylık
        "agg": "avg",
        "desc": "Çekirdek Enflasyon B Endeksi — Aylık % Değişim (hesaplanmış)",
        "compute_pct_change": True,  # EVDS3 ham endeks (~3756) verir; % değişimi biz hesaplıyoruz
    },
    # ── TCMB Beklenti Anketi (API key gerektirir) ───────────────────────
    {
        "code": "TP.PKAUO.S01.E.U",
        "col_name": "Enflasyon_Beklenti_12ay",
        "freq": "5",   # aylık
        "agg": "avg",
        "desc": "TCMB Beklenti Anketi: 12 Ay Sonrası Enflasyon Beklentisi (%)",
        "api_key_required": True,
    },
    {
        "code": "TP.PKAUO.S07.A.U",
        "col_name": "GSYH_Buyume_Beklenti",
        "freq": "5",   # aylık
        "agg": "avg",
        "desc": "TCMB Beklenti Anketi: GSYH Büyime Beklentisi (Cari Yıl, %)",
        "api_key_required": True,
    },
    # ── İstihdam (API key gerektirir) ───────────────────────────────
    {
        "code": "TP.YISGUCU2.G8",
        "col_name": "Issizlik",
        "freq": "5",   # üç aylık (quarterly)
        "agg": "avg",
        "desc": "TÜİK İşsizlik Oranı (%)",
        "api_key_required": True,
    },
]


def fetch_evds3_macro(api_key: str | None = None):
    print("\n--- EVDS3 Makro Göstergeler Çekiliyor ---")

    df_excel = read_fora()
    if df_excel is None or df_excel.empty:
        print("FORA.xlsx bulunamadı veya boş.")
        return

    df_excel["Min Tarih"] = pd.to_datetime(df_excel["Min Tarih"], dayfirst=True, errors="coerce")
    df_excel["Max Tarih"] = pd.to_datetime(df_excel["Max Tarih"], dayfirst=True, errors="coerce")

    min_date = df_excel["Min Tarih"].min()
    max_date = df_excel["Max Tarih"].max()
    start_str = min_date.strftime("%d-%m-%Y")
    end_str = max_date.strftime("%d-%m-%Y")

    for s in SERIES:
        print(f"\n  → {s['desc']} ({s['code']})")

        col_name = s["col_name"]
        if col_name not in df_excel.columns:
            df_excel[col_name] = None

        try:
            items = fetch_evds3_series(
                [s["code"]],
                start_date=start_str,
                end_date=end_str,
                frequency=s["freq"],
                aggregation=s["agg"],
                api_key=api_key if s.get("api_key_required") else None,
            )
        except Exception as e:
            print(f"    ⚠ Hata: {e}")
            continue

        if not items:
            print(f"    ⚠ Veri alınamadı. Seri kodu doğru mu? → {s['code']}")
            continue

        series_vals = items_to_series(items, s["code"])
        valid_count = len(series_vals.dropna())
        print(f"    Geçerli değer sayısı: {valid_count}")

        if valid_count == 0:
            continue

        # Endeksten % defisim hesapla (EVDS3 formula=1/2 calismiyor)
        if s.get("compute_pct_change"):
            series_vals = series_vals.pct_change().mul(100).round(4)
            print(f"    Endeks → aylık % degisim hesaplandı.")

        # Aylık veriler icin forward fill uygula (step function)
        # ÖNEMLI: resample("D").ffill() son değeri yalnızca mevcut indeks
        # aralığıyla sınırlar. Son aylık değerin FORA bitiş tarihine kadar
        # yayılması için reindex + ffill ile extend ediyoruz.
        if s["freq"] == "5":
            series_vals = series_vals.resample("D").ffill()
            if not series_vals.empty and series_vals.index[-1] < max_date:
                ext_idx = pd.date_range(series_vals.index[0], max_date, freq="D")
                series_vals = series_vals.reindex(ext_idx).ffill()

        # Haftalık ortalamaları FORA satırlarına yaz
        updated = 0
        for idx, row in df_excel.iterrows():
            r_start = row["Min Tarih"]
            r_end = row["Max Tarih"]
            if pd.isna(r_start) or pd.isna(r_end):
                continue
            mask = (series_vals.index >= r_start) & (series_vals.index <= r_end)
            subset = series_vals.loc[mask].dropna()
            if not subset.empty:
                df_excel.at[idx, col_name] = round(subset.mean(), 4)
                updated += 1

        print(f"    {updated} satır güncellendi.")

    # ── Tarih formatını geri yükle ve kaydet ──────────────────────
    for col in ["Min Tarih", "Max Tarih"]:
        if pd.api.types.is_datetime64_any_dtype(df_excel[col]):
            df_excel[col] = df_excel[col].dt.strftime("%d.%m.%Y")

    save_fora(df_excel)
    print("\nFORA.xlsx kaydedildi (EVDS3 makro göstergeler eklendi).\n")


if __name__ == "__main__":
    fetch_evds3_macro()
