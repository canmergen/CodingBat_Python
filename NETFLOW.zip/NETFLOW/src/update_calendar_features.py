"""
update_calendar_features.py
---------------------------
Python mantığıyla takvim ve mevsimsellik dummy değişkenlerini oluşturur.
Harici veri gerektirmez — tamamen otomatik.

Oluşturulan değişkenler:
  Temel:
  - Payday          : Hafta içinde ayın 1'i veya 15'i var mı (maaş etkisi)
  - Tax_Season      : Vergi ödeme ayları (Şubat, Mayıs, Ağustos, Kasım)
  - Holiday_Cash    : Resmi tatil / bayram arefesi haftası
  - Season          : Mevsim (1=Kış, 2=İlkbahar, 3=Yaz, 4=Sonbahar)
  - Month           : Ay numarası (mevsimsellik için)
  - YearEnd         : Aralık son 2 haftası (bilanço kapama etkisi)
  - School_Vacation : Eylül (okul açılışı) veya Haziran (tatil) harcama etkisi (0/1)
  - Quarter_End     : Çeyrek sonu haftası (Mart, Haziran, Eylül, Aralık son haftası)
  - Ramazan         : Ramazan ayı harcama/tasarruf etkisi

  Yeni — otomatik:
  - Bayram_Haftasi    : Kurban/Ramazan Bayramı haftası (holidays lib'den otomatik)
  - Asgari_Ucret_Zam  : Ocak+Temmuz 1. haftası (asgari ücret zam etkisi)
  - Black_Friday      : Kasım 4. Perşembe haftası (Efsane Cuma harcama artışı)
  - Turizm_Sezonu     : Haziran–Ağustos (döviz geliri → TL likidite artışı)
  - Temetu_Donemi     : Mayıs–Haziran 15 (temettü ödemeleri → mevduat akışı)
  - PPK_Haftasi       : PPK toplantı haftası (belirsizlik artışı — CONFIG'den otomatik)
  - Kis_Indirim       : Ocak 2. haftası (kış indirim sezonu, harcama artışı)
"""

import pandas as pd
from src.utils import read_fora, save_fora

# Vergi ödeme ayları
TAX_MONTHS = {2, 5, 8, 11}

# Ramazan Bayramı ve Kurban Bayramı'nı tanımlayan anahtar kelimeler (holidays lib)
BAYRAM_KEYWORDS = {"kurban", "ramazan bayram", "şeker bayram", "eid"}


def _auto_ramazan(years=None):
    """hijridate kütüphanesi ile Ramazan başlangıç/bitiş hesaplar."""
    try:
        from hijridate import Hijri, Gregorian
    except ImportError:
        return None
    if years is None:
        current_year = pd.Timestamp.now().year
        years = [current_year, current_year + 1]
    ranges = []
    for year in years:
        try:
            hijri_year = round(year * 1.03036 - 581.1)
            start = Hijri(hijri_year, 9, 1).to_gregorian()
            end   = Hijri(hijri_year, 9, 29).to_gregorian()
            ranges.append((pd.Timestamp(start.isoformat()), pd.Timestamp(end.isoformat())))
        except Exception as e:
            print(f"  Ramazan hesaplama hatası ({year}): {e}")
    return ranges if ranges else None


def _get_season(month: int) -> int:
    if month in (12, 1, 2):  return 1  # Kış
    if month in (3, 4, 5):   return 2  # İlkbahar
    if month in (6, 7, 8):   return 3  # Yaz
    return 4                            # Sonbahar


def _build_black_friday_dates(years) -> set:
    """Her yıl için Kasım'ın 4. Perşembesini (Kara Cuma) döndürür."""
    dates = set()
    for yr in years:
        thursdays = [d for d in pd.date_range(f"{yr}-11-01", f"{yr}-11-30")
                     if d.dayofweek == 3]  # 3 = Perşembe
        if len(thursdays) >= 4:
            dates.add(thursdays[3].date())  # 4. Perşembe
    return dates


def _build_bayram_dates(tr_holidays: dict) -> set:
    """Holidays dict'ten Kurban / Ramazan Bayramı tarihleri çıkarır."""
    bayram = set()
    for d, name in tr_holidays.items():
        name_lower = name.lower()
        if any(kw in name_lower for kw in BAYRAM_KEYWORDS):
            bayram.add(d)
    return bayram


def update_calendar_features(
    ramazan_ranges=None,
    ppk_dates=None,          # CONFIG'deki PPK_DATES listesi (string "dd/mm/yyyy")
):
    print("\n--- Takvim & Mevsimsellik Değişkenleri Güncelleniyor ---")

    # ── Ramazan tarihleri ─────────────────────────────────────────
    auto = _auto_ramazan()
    if auto:
        effective_ramazan = auto
        print(f"  Ramazan tarihleri otomatik (hijridate): "
              f"{[str(s.date()) for s, _ in auto]}")
    elif ramazan_ranges:
        effective_ramazan = ramazan_ranges
        print(f"  Ramazan tarihleri CONFIG'den alındı: {len(ramazan_ranges)} aralık")
    else:
        effective_ramazan = []
        print("  ⚠ Ramazan tarihi bulunamadı.")

    # ── FORA yükle ────────────────────────────────────────────────
    df = read_fora()
    if df is None or df.empty:
        print("FORA.xlsx bulunamadı.")
        return

    df["Min Tarih"] = pd.to_datetime(df["Min Tarih"], dayfirst=True, errors="coerce")
    df["Max Tarih"] = pd.to_datetime(df["Max Tarih"], dayfirst=True, errors="coerce")

    all_years = set(df["Min Tarih"].dropna().dt.year.tolist() +
                    df["Max Tarih"].dropna().dt.year.tolist())

    # ── Tatil kütüphanesi ─────────────────────────────────────────
    try:
        from src.holidays import get_tr_holidays
        tr_holidays = get_tr_holidays()
    except ImportError:
        try:
            import holidays as hol_lib
            tr_holidays = hol_lib.Turkey(years=list(all_years))
        except ImportError:
            print("  ⚠ holidays modülü bulunamadı.")
            tr_holidays = {}

    # ── Önceden hesaplanan setler ─────────────────────────────────
    black_friday_dates = _build_black_friday_dates(all_years)
    bayram_dates       = _build_bayram_dates(tr_holidays)

    # PPK tarihlerini date set'e dönüştür
    ppk_date_set = set()
    if ppk_dates:
        for s in ppk_dates:
            try:
                ppk_date_set.add(pd.to_datetime(s, dayfirst=True).date())
            except Exception:
                pass

    # ── Tüm kolonları hazırla ─────────────────────────────────────
    all_cols = [
        "Payday", "Tax_Season", "Holiday_Cash", "Season", "Month",
        "YearEnd", "School_Vacation", "Quarter_End", "Ramazan",
        # Yeni
        "Bayram_Haftasi", "Asgari_Ucret_Zam", "Black_Friday",
        "Turizm_Sezonu", "Temetu_Donemi", "PPK_Haftasi", "Kis_Indirim",
    ]
    for col in all_cols:
        if col not in df.columns:
            df[col] = 0

    # ── Satır satır doldur ────────────────────────────────────────
    updated = 0
    for idx, row in df.iterrows():
        r_start = row["Min Tarih"]
        r_end   = row["Max Tarih"]
        if pd.isna(r_start) or pd.isna(r_end):
            continue

        days_in_week  = pd.date_range(r_start, r_end, freq="D")
        mid_date      = r_start + (r_end - r_start) / 2
        month         = mid_date.month
        week_of_month = (mid_date.day - 1) // 7 + 1   # 1. - 5. hafta

        # ── Payday ───────────────────────────────────────────────
        df.at[idx, "Payday"] = int(any(d.day in (1, 15) for d in days_in_week))

        # ── Tax_Season ───────────────────────────────────────────
        df.at[idx, "Tax_Season"] = int(month in TAX_MONTHS)

        # ── Holiday_Cash ─────────────────────────────────────────
        df.at[idx, "Holiday_Cash"] = int(any(d.date() in tr_holidays for d in days_in_week))

        # ── Season & Month ───────────────────────────────────────
        df.at[idx, "Season"] = _get_season(month)
        df.at[idx, "Month"]  = month

        # ── YearEnd ──────────────────────────────────────────────
        df.at[idx, "YearEnd"] = int(month == 12 and mid_date.day >= 15)

        # ── School_Vacation ──────────────────────────────────────
        df.at[idx, "School_Vacation"] = int(month in (6, 9))

        # ── Quarter_End ──────────────────────────────────────────
        df.at[idx, "Quarter_End"] = int(month in (3, 6, 9, 12) and mid_date.day >= 22)

        # ── Ramazan ──────────────────────────────────────────────
        ramazan = 0
        for rm_start, rm_end in effective_ramazan:
            if r_start <= rm_end and r_end >= rm_start:
                ramazan = 1
                break
        df.at[idx, "Ramazan"] = ramazan

        # ════════════════════════════════════════════════════════
        #  YENİ ÖZELLIKLER — tamamen otomatik
        # ════════════════════════════════════════════════════════

        # ── Bayram_Haftasi ───────────────────────────────────────
        # Kurban Bayramı (4.5 gün) veya Ramazan Bayramı (3 gün) haftası
        # Bayramdan 1 hafta önce / sonrası da nakit harcaması ve mevduat hareketi yoğun
        df.at[idx, "Bayram_Haftasi"] = int(
            any(d.date() in bayram_dates for d in days_in_week)
        )

        # ── Asgari_Ucret_Zam ─────────────────────────────────────
        # Türkiye: Ocak 1. haftası + Temmuz 1. haftası
        # Yeni nakit gelir → mevduat artışı beklenir
        df.at[idx, "Asgari_Ucret_Zam"] = int(
            (month == 1  and week_of_month == 1) or
            (month == 7  and week_of_month == 1)
        )

        # ── Black_Friday (Efsane Cuma) ───────────────────────────
        # Kasım 4. Perşembe — harcama artışı → mevduattan çıkış baskısı
        df.at[idx, "Black_Friday"] = int(
            any(d.date() in black_friday_dates for d in days_in_week)
        )

        # ── Turizm_Sezonu ────────────────────────────────────────
        # Haziran–Ağustos: döviz geliri → TL'ye çevrim → banka mevduat likiditesi artar
        df.at[idx, "Turizm_Sezonu"] = int(month in (6, 7, 8))

        # ── Temetu_Donemi ────────────────────────────────────────
        # Mayıs – 15 Haziran: BİST şirket temettü ödemeleri
        # Anlık yüksek nakit → kısa vadeli mevduata yönelim
        temetu = 0
        if month == 5:
            temetu = 1
        elif month == 6 and mid_date.day <= 15:
            temetu = 1
        df.at[idx, "Temetu_Donemi"] = temetu

        # ── PPK_Haftasi ──────────────────────────────────────────
        # PPK toplantısının bu hafta içinde olup olmadığı
        # Karar belirsizliği → ihtiyatlı mevduat tutma eğilimi
        ppk_this_week = 0
        if ppk_date_set:
            ppk_this_week = int(any(d.date() in ppk_date_set for d in days_in_week))
        df.at[idx, "PPK_Haftasi"] = ppk_this_week

        # ── Kis_Indirim ──────────────────────────────────────────
        # Ocak 2. haftası: yılbaşı sonrası büyük perakende indirimleri
        # Giyim & beyaz eşya → harcama artışı → mevduattan çıkış baskısı
        df.at[idx, "Kis_Indirim"] = int(month == 1 and week_of_month == 2)

        updated += 1

    print(f"  {updated} satır güncellendi ({', '.join(all_cols)})")

    # ── Kaydet ───────────────────────────────────────────────────
    for col in ["Min Tarih", "Max Tarih"]:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = df[col].dt.strftime("%d.%m.%Y")

    save_fora(df)
    print("FORA.xlsx kaydedildi (takvim değişkenleri eklendi).\n")


if __name__ == "__main__":
    update_calendar_features()
