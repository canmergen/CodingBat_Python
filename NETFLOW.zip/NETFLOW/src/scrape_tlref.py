import pandas as pd
import os
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import datetime
from src.utils import read_fora, save_fora

def scrape_tlref(start_date: "datetime.datetime" = None):
    tlref_output_path = "TLREF.xlsx"
    target_column = "TLREF"
    
    print("\n--- TLREF Verisi Çekiliyor (Borsa İstanbul) ---")
    
    # 1. Durdurma tarihini belirle (artımsal mantık)
    if start_date is None:
        start_date = datetime.datetime(2025, 1, 1)
    stop_date = start_date

    existing_tlref = pd.DataFrame()

    # Önce FORA.xlsx'teki mevcut TLREF verisine bak
    df_firast_check = read_fora()
    if df_firast_check is not None and not df_firast_check.empty:
        if target_column in df_firast_check.columns:
            # TLREF değeri dolu olan satırlardaki Max Tarih'lerin en büyüğü
            filled_mask = df_firast_check[target_column].notna()
            if filled_mask.any():
                filled_max_dates = pd.to_datetime(
                    df_firast_check.loc[filled_mask, "Max Tarih"],
                    dayfirst=True, errors="coerce"
                )
                stop_date = filled_max_dates.max() - pd.Timedelta(days=14)
                print(f"FORA'da mevcut TLREF verisi {filled_max_dates.max().strftime('%d.%m.%Y')} tarihine kadar dolu. Son 2 hafta yeniden çekilecek.")
            else:
                print("FORA'da hiç TLREF verisi yok. Tümü çekilecek.")
        else:
            print("FORA'da TLREF kolonu yok. Tümü çekilecek.")
    else:
        print("FORA.xlsx bulunamadı. Tümü çekilecek.")

    print(f"Scraping şu tarihte/öncesinde duracak: {stop_date.strftime('%d.%m.%Y')}")


    # 2. Scrape Data
    new_data = [] 
    
    # Tarayıcı ayarla
    options = webdriver.ChromeOptions()
    options.add_argument('--headless')
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')
    options.add_argument("user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
    
    # Selenium Manager kullan (yerleşik)
    driver = webdriver.Chrome(options=options)
    
    try:
        url = "https://www.borsaistanbul.com/endeksler/tlref"
        print(f"{url} adresine gidiliyor...")
        driver.get(url)
        time.sleep(3)
        
        page_num = 1
        keep_scraping = True
        
        while keep_scraping:
            print(f"Sayfa {page_num} scrape ediliyor...")
            
            try:
                table = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.TAG_NAME, "table"))
                )
                rows = table.find_elements(By.TAG_NAME, "tr")
            except:
                print("Bu sayfada tablo bulunamadı.")
                break
                
            page_rows_collected = 0
            
            for row in rows:
                cols = row.find_elements(By.TAG_NAME, "td")
                if len(cols) >= 2:
                    date_text = cols[0].text.strip()
                    rate_text = cols[1].text.strip()
                    
                    try:
                        dt = datetime.datetime.strptime(date_text, "%d.%m.%Y")
                    except:
                        continue 
                        
                    try:
                        rate = float(rate_text.replace(",", "."))
                    except:
                        continue 
                    
                    # Optimizasyon: durdurma tarihine ulaşıldıysa dur
                    if dt <= stop_date:
                        print(f"{dt.strftime('%d.%m.%Y')} tarihi durdurma tarihine eşit/önce — durduruluyor.")
                        keep_scraping = False
                        # Bulduysak ekle, sonra tekrar kayıtlar drop edilir
                        new_data.append({'Date': dt, 'TLREF': rate}) 
                        break
                    
                    new_data.append({'Date': dt, 'TLREF': rate})
                    page_rows_collected += 1
            
            if not keep_scraping:
                break
                
            if page_rows_collected == 0:
                 print("Bu sayfada geçerli satır bulunamadı.")
                 break

            # Sonraki sayfaya geç
            try:
                next_page_link = driver.find_element(By.LINK_TEXT, str(page_num + 1))
                driver.execute_script("arguments[0].click();", next_page_link)
                page_num += 1
                time.sleep(2) 
            except:
                print("Sonraki sayfa bulunamadı veya veri sona erdi.")
                keep_scraping = False
                
    except Exception as e:
        print(f"Scraping hatası: {e}")
    finally:
        driver.quit()
        
    # 3. Kaydet ve FORA'ya Entegre Et
    if new_data:
        final_df = pd.DataFrame(new_data)
        final_df.drop_duplicates(subset=['Date'], keep='last', inplace=True)
        final_df.sort_values(by='Date', inplace=True)

        # Geçici TLREF.xlsx'e kaydet
        final_df.to_excel(tlref_output_path, index=False)
        print(f"Saved {len(final_df)} total records to {tlref_output_path} ({len(new_data)} new).")

        # 4. FORA'ya entegre et (sadece boş TLREF satırlarını doldur)
        df_firast = read_fora()
        if df_firast is not None:
            updated_count = 0

            if target_column not in df_firast.columns:
                df_firast[target_column] = None

            last_2_indices = set(df_firast.index[-2:])
            for index, row in df_firast.iterrows():
                # Dolu satırları atla — artımsal mantık
                # AMA son 2 satır (mevcut + önceki hafta) her zaman güncellenir
                if pd.notna(row.get(target_column)) and index not in last_2_indices:
                    continue

                r_start = pd.to_datetime(row['Min Tarih'], dayfirst=True, errors='coerce')
                r_end   = pd.to_datetime(row['Max Tarih'], dayfirst=True, errors='coerce')

                if pd.isna(r_start) or pd.isna(r_end):
                    continue

                mask   = (final_df['Date'] >= r_start) & (final_df['Date'] <= r_end)
                subset = final_df.loc[mask]

                if not subset.empty:
                    val = subset['TLREF'].mean()
                    df_firast.at[index, target_column] = val
                    updated_count += 1

            save_fora(df_firast)
            print(f"TLREF: {updated_count} satır güncellendi.")

            # Geçici TLREF.xlsx'i temizle
            if os.path.exists(tlref_output_path):
                os.remove(tlref_output_path)
    else:
        print("Yeni TLREF verisi yok — tüm satırlar zaten dolu.")


if __name__ == "__main__":
    scrape_tlref()
