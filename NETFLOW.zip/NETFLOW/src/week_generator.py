import pandas as pd
from datetime import datetime, timedelta
from src.utils import read_fora, save_fora

def generate_weeks(start_date: "datetime" = None):
    
    # --- 1. Kanonik Zaman Çizelgesi Oluştur ---
    canonical_rows = []
    
    if start_date is None:
        from datetime import datetime as _dt
        start_date = _dt(2025, 1, 1)
    
    curr_min = start_date
    target_date = datetime.now()
    
    # Başlangıç değerleri
    week_num = 1
    curr_year = start_date.year
    curr_max = start_date + timedelta(days=6)  # İlk hafta da 7 gün
    
    full_columns = ['Yıl', 'Hafta', 'Min Tarih', 'Max Tarih', 'TLREF', 'AOFF', 'PP Getiri', 'TCMB 1M', 'TCMB 3M', 'Benchmark', 'BIST100', 'PPK', 'Spot Kredi', 'WebTufe', 'Sepet Kur', 'Full Workday']
    
    while curr_min <= target_date:
        row_data = {col: None for col in full_columns}
        row_data.update({
            "Yıl": curr_year,
            "Hafta": f"Hafta {week_num}",
            "Min Tarih": curr_min.strftime("%d/%m/%Y"),
            "Max Tarih": curr_max.strftime("%d/%m/%Y")
        })
        canonical_rows.append(row_data)
        
        week_num += 1
        if week_num > 52:
            week_num = 1
            curr_year += 1
        
        curr_min = curr_max + timedelta(days=1)
        curr_max = curr_min + timedelta(days=6)
        
    df_canonical = pd.DataFrame(canonical_rows)
    print(f"Haftalık zaman çizelgesi oluşturuldu: {len(df_canonical)} hafta.")

    # --- 2. Mevcut Dosyayı Oku ---
    df_existing = read_fora()
    if df_existing is None:
        print("Mevcut FORA.xlsx bulunamadı. Sıfırdan başlanıyor.")
        df_existing = pd.DataFrame()
    else:
        print(f"Mevcut FORA.xlsx okundu: {len(df_existing)} satır.")

    # Tanımlı tüm kolonların varlığını garantile
    for col in full_columns:
        if col not in df_existing.columns:
            df_existing[col] = None

    # --- 3. Yerinde Onarım ve Güncelleme ---
    # df_canonical sırası esas alınır (Satır 0 = Hafta 1, vb.)
    # Bu yapı df_existing üzerine empoze edilir.
    
    updated_count = 0
    
    # Kanonik zaman çizelgesini dolaş
    for i, expected_row in df_canonical.iterrows():
        # Bu satır indeksinin dosyada var olup olmadığını kontrol et
        if i < len(df_existing):
            # Satır mevcut. A-D kolonlarının kanonik ile eşleştiğinden emin ol..
            
            # Fark varsa logla
            needs_update = False
            for col in ["Yıl", "Hafta", "Min Tarih", "Max Tarih"]:
                current_val = df_existing.at[i, col]
                expected_val = expected_row[col]
                
                # NaN veya uyumsuzluk kontrolü
                if pd.isna(current_val) or str(current_val) != str(expected_val):
                    needs_update = True
            
            if needs_update:
                # Tanımlayıcı kolonları zorunlu güncelle
                df_existing.at[i, "Yıl"] = expected_row["Yıl"]
                df_existing.at[i, "Hafta"] = expected_row["Hafta"]
                df_existing.at[i, "Min Tarih"] = expected_row["Min Tarih"]
                df_existing.at[i, "Max Tarih"] = expected_row["Max Tarih"]
                updated_count += 1
        else:
            # Satır yok — sonuna ekle
            
            remaining_canonical = df_canonical.iloc[i:]
            df_existing = pd.concat([df_existing, remaining_canonical], ignore_index=True)
            print(f"{len(remaining_canonical)} yeni hafta eklendi.")
            break  # Kalan satırlar concat ile işlendi
            
    # --- 4. Doğrula ve Kaydet ---
    
    # Tekrar eden satırları kaldır
    if not df_existing.empty and 'Min Tarih' in df_existing.columns:
        df_existing.drop_duplicates(subset=['Min Tarih'], keep='first', inplace=True)

    # Kolon sıralamasını uygula
    current_cols = df_existing.columns.tolist()
    ordered_cols = [c for c in full_columns if c in current_cols] + [c for c in current_cols if c not in full_columns]
    df_existing = df_existing[ordered_cols]

    save_fora(df_existing)
    print("Hafta oluşturma tamamlandı.")

if __name__ == "__main__":
    generate_weeks()
