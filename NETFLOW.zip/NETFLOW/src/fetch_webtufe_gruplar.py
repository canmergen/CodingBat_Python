"""
fetch_webtufe_gruplar.py
------------------------
WebTUFE günlük endeks ve açlık sınırı verilerini çekerek FORA.xlsx'e yazar.

Eklenen kolonlar:
  WebTufe_Gida_Endeks      : Gıda endeksi haftalık ort.
  WebTufe_Enerji_Endeks    : Konut/Su/Elektrik/Gaz endeksi haftalık ort.
  WebTufe_Ulastirma_Endeks : Ulaştırma endeksi haftalık ort.
  WebTufe_Hizmet_Endeks    : Lokantalar ve konaklama endeksi haftalık ort.
  WebTufe_Giyim_Endeks     : Giyim ve ayakkabı endeksi haftalık ort.
  WebTufe_Aclik_Siniri     : Günlük açlık sınırı (TL) haftalık ort.
"""

import io
import requests
import pandas as pd
from datetime import date
from src.utils import read_fora, save_fora

URL = "https://www.apiwebtufe.com/api/v1/download/gruplar/index/csv"
ACLIK_URL = "https://www.apiwebtufe.com/api/v1/aclik-siniri"

COL_MAP = {
    "Gıda ve alkolsüz içecekler":                              "WebTufe_Gida_Endeks",
    "Konut,Su,Elektrik,Gaz ve Diğer Yakıtlar":                 "WebTufe_Enerji_Endeks",
    "Ulaştırma":                                                "WebTufe_Ulastirma_Endeks",
    "Lokantalar ve konaklama hizmetleri":                       "WebTufe_Hizmet_Endeks",
    "Giyim ve ayakkabı":                                        "WebTufe_Giyim_Endeks",
    "Web TÜFE":                                                 "WebTufe_Endeks",
    "Kişisel bakım,sosyal koruma ve çeşitli mal ve hizmetler":  "WebTufe_KisiselBakim_Endeks",
}


def fetch_webtufe_gruplar():
    print("\n--- WebTUFE Ana Grup Endeks + Açlık Sınırı Çekiliyor ---")

    df_fora = read_fora()
    if df_fora is None or df_fora.empty:
        print("  FORA.xlsx bulunamadı.")
        return

    df_fora["Min Tarih"] = pd.to_datetime(df_fora["Min Tarih"], dayfirst=True, errors="coerce")
    df_fora["Max Tarih"] = pd.to_datetime(df_fora["Max Tarih"], dayfirst=True, errors="coerce")

    # ── Ana grup endeks CSV ────────────────────────────────────────
    try:
        r = requests.get(URL, timeout=15)
        r.raise_for_status()
    except Exception as e:
        print(f"  ⚠ Ana grup API hatası: {e}")
    else:
        df_src = pd.read_csv(io.StringIO(r.text))
        df_src["date"] = pd.to_datetime(df_src["date"], errors="coerce")
        df_src = df_src.dropna(subset=["date"]).sort_values("date").reset_index(drop=True)
        print(f"  {len(df_src)} günlük kayıt "
              f"({df_src['date'].min().strftime('%Y-%m-%d')} → {df_src['date'].max().strftime('%Y-%m-%d')})")

        for fora_col in COL_MAP.values():
            if fora_col not in df_fora.columns:
                df_fora[fora_col] = None

        for src_col, fora_col in COL_MAP.items():
            if src_col not in df_src.columns:
                print(f"  ⚠ '{src_col}' bulunamadı.")
                continue
            daily = df_src.set_index("date")[src_col].dropna()
            updated = 0
            for idx, row in df_fora.iterrows():
                r_start, r_end = row["Min Tarih"], row["Max Tarih"]
                if pd.isna(r_start) or pd.isna(r_end):
                    continue
                subset = daily.loc[(daily.index >= r_start) & (daily.index <= r_end)].dropna()
                if not subset.empty:
                    df_fora.at[idx, fora_col] = round(subset.mean(), 4)
                    updated += 1
            print(f"  {fora_col}: {updated} satır güncellendi.")

    # ── Açlık Sınırı ──────────────────────────────────────────────
    print("\n  → Açlık Sınırı (TL, günlük)...")
    col = "WebTufe_Aclik_Siniri"
    if col not in df_fora.columns:
        df_fora[col] = None

    try:
        ra = requests.get(ACLIK_URL, timeout=15)
        ra.raise_for_status()
        data = ra.json()
    except Exception as e:
        print(f"    ⚠ Açlık sınırı API hatası: {e}")
        data = []

    if data and isinstance(data, list):
        values = [float(item.get("Açlık Sınırı", "nan")) for item in data]
        n = len(values)
        # API tarih döndürmüyor — son kayıt bugüne karşılık gelir
        end_date = pd.Timestamp(date.today())
        dates = pd.date_range(end=end_date, periods=n, freq="D")
        daily_aclik = pd.Series(values, index=dates)
        print(f"    {n} kayıt ({daily_aclik.index[0].strftime('%Y-%m-%d')} → "
              f"{daily_aclik.index[-1].strftime('%Y-%m-%d')}, "
              f"son: {values[-1]:,.0f} TL)")

        updated = 0
        for idx, row in df_fora.iterrows():
            r_start, r_end = row["Min Tarih"], row["Max Tarih"]
            if pd.isna(r_start) or pd.isna(r_end):
                continue
            subset = daily_aclik.loc[
                (daily_aclik.index >= r_start) & (daily_aclik.index <= r_end)
            ].dropna()
            if not subset.empty:
                df_fora.at[idx, col] = round(subset.mean(), 2)
                updated += 1
        print(f"    {col}: {updated} satır güncellendi.")

    # Tarih sütunlarını geri yükle
    for c in ["Min Tarih", "Max Tarih"]:
        if pd.api.types.is_datetime64_any_dtype(df_fora[c]):
            df_fora[c] = df_fora[c].dt.strftime("%d.%m.%Y")

    save_fora(df_fora)
    print("FORA.xlsx kaydedildi (WebTUFE ana gruplar + açlık sınırı eklendi).")


if __name__ == "__main__":
    fetch_webtufe_gruplar()
