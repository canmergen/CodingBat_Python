import pandas as pd
import time
import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from src.utils import read_fora, save_fora

def scrape_ppk(ppk_dates: list = None):
    print("\n--- PPK Toplantı Takvimi Yükleniyor ---")
    # ppk_dates: main.py CONFIG'den gelen tarih listesi ("%d/%m/%Y" formatı)
    # Selenium scraper birincil kaynak; ppk_dates fallback/takviye olarak kullanılır

    # 1. CONFIG'den gelen tarihler (fallback/takviye)
    manual_dates = ppk_dates or []
    meeting_dates = set()
    for d_str in manual_dates:
        try:
             dt = datetime.datetime.strptime(d_str, "%d/%m/%Y")
             meeting_dates.add(dt)
        except:
             print(f"Tarih ayrıştırma hatası: {d_str}")
    print(f"{len(meeting_dates)} adet PPK tarihi CONFIG'den yüklendi.")



    # 2. 2026+ tarihlerini TCMB takviminden scrape et
    url = "https://www.tcmb.gov.tr/wps/wcm/connect/tr/tcmb+tr/main+menu/duyurular/takvim"
    
    chrome_options = Options()
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument("--window-size=1920,1080")
    
    driver = webdriver.Chrome(options=chrome_options)
    
    try:
        driver.get(url)
        time.sleep(5)
        
        # Tablo satırlarını tara, 2026+ yıllı PPK tarihleri için
        rows = driver.find_elements(By.CSS_SELECTOR, "table tr")
        print(f"Tabloda {len(rows)} satır bulundu.")
        
        count_future = 0
        current_year = datetime.datetime.now().year
        for row in rows:
            cells = row.find_elements(By.TAG_NAME, "td")
            if cells:
                date_txt = cells[0].text.strip()
                # Bu yıl veya sonraki yıllara ait tarihleri al
                if any(str(y) in date_txt for y in range(current_year, current_year + 3)):
                    try:
                        clean_txt = date_txt.split(' ')[0].strip()
                        dt = datetime.datetime.strptime(clean_txt, "%d.%m.%Y")
                        # Zaten 2025'te olan tarihleri ekleme (manual_dates'te var)
                        if dt.year >= current_year:
                            meeting_dates.add(dt)
                            count_future += 1
                            print(f"  Scrape edilen tarih: {clean_txt}")
                    except:
                        pass
                        
        print(f"{count_future} adet gelecek dönem PPK tarihi scrape edildi.")
        
    except Exception as e:
        print(f"Scrape hatası: {e}")
    finally:
        driver.quit()
        
    # 3. Update Excel
    df = read_fora()
    if df is not None:
        updated = 0
        if 'PPK' not in df.columns:
            df['PPK'] = 0
        
        # Ensure default 0
        # df['PPK'] = df['PPK'].fillna(0) # Careful not to overwrite if we want to preserve manual edits? 
        # User said "automaticaly be 1... others 0". So we reset.
        
        # Tarih parse
        df['Min Tarih'] = pd.to_datetime(df['Min Tarih'], dayfirst=True, errors='coerce')
        df['Max Tarih'] = pd.to_datetime(df['Max Tarih'], dayfirst=True, errors='coerce')
        
        for index, row in df.iterrows():
            r_start = row['Min Tarih']
            r_end = row['Max Tarih']
            if pd.isna(r_start) or pd.isna(r_end):
                continue
            
            # Bu haftada PPK toplantısı var mı kontrol et
            has_meeting = 0
            for m_date in meeting_dates:
                if r_start <= m_date <= r_end:
                    has_meeting = 1
                    break
            
            # Sadece değiştiyse güncelle
            if df.at[index, 'PPK'] != has_meeting:
                df.at[index, 'PPK'] = has_meeting
                updated += 1
            elif pd.isna(df.at[index, 'PPK']): # Handle NaN
                 df.at[index, 'PPK'] = has_meeting
                 updated += 1
            
        # Tarih formatını geri yüklc
        if pd.api.types.is_datetime64_any_dtype(df['Min Tarih']):
             df['Min Tarih'] = df['Min Tarih'].dt.strftime('%d.%m.%Y')
        if pd.api.types.is_datetime64_any_dtype(df['Max Tarih']):
             df['Max Tarih'] = df['Max Tarih'].dt.strftime('%d.%m.%Y')
             
        save_fora(df)
        print(f"FORA.xlsx güncellendi. {updated} satır değiştirildi.")

if __name__ == "__main__":
    scrape_ppk()
