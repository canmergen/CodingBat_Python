"""
build_model_dataset.py
-----------------------
FORA.xlsx'i okur, zaman serisi tahmini için mühendislenmiş feature'lar ekler
ve FORA_MODEL.xlsx olarak kaydeder. FORA.xlsx'e dokunmaz.

Üretilen feature'lar:
  Log Transforms   : log1p(X) — sağa çarpık dağılımları normalize eder
  Lag Features     : X_lag1, X_lag2, X_lag4 — haftalık gecikmeli değerler
  Rolling Mean     : X_roll4_mean — 4 haftadaki ortalama
  Rolling Std      : X_roll4_std  — 4 haftalık gerçekleşmiş volatilite
  Delta (değişim)  : X_delta1     — haftadan haftaya fark
  NET lag/roll     : NET_lag1/2/4, NET_roll3 — eğer NET kolonu varsa (banka verisi)

Çıktı: FORA_MODEL.xlsx  (aynı dizinde)
"""

import os
import numpy as np
import pandas as pd
from src.utils import read_fora
from src.derive_advanced_features import derive_advanced_features

MODEL_PATH = "FORA_MODEL.xlsx"

# ── Log transform uygulanacak kolonlar ────────────────────────────
LOG_COLS = [
    "TLREF", "AOFF", "Benchmark", "TCMB 1M", "TCMB 3M",
    "BIST100", "Gram_Altin_TRY", "CDS_5Y", "VIX", "TCMB_Politika",
]

# ── Lag + Rolling uygulanacak kolonlar ────────────────────────────
LAG_COLS = [
    # Banka içi
    "w/TLREF", "OSABook",
    # Harici (türetilmiş dahil — derive_advanced_features sonrası erişilebilir)
    "TLREF", "Benchmark", "TCMB 1M", "AOFF",
    "Enflasyon_x_Faiz", "Market_Stress_Composite",
    "Altin_Getiri", "BIST100_Getiri", "Kur_Degisim",
    "Reel_Faiz", "Faiz_Spread",
    "CDS_5Y", "VIX", "TCMB_Politika",
    "Enflasyon_Beklenti_12ay", "GSYH_Buyume_Beklenti",
]

# ── Delta (değişim) uygulanacak kolonlar ──────────────────────────
DELTA_COLS = [
    "TLREF", "Benchmark", "TCMB 1M", "WebTufe",
    "ENAG_TUFE_Aylik", "CDS_5Y", "TCMB_Politika",
]

# ── Rolling uygulanacak kolonlar ──────────────────────────────────
ROLLING_COLS = [
    "TLREF", "Benchmark", "BIST100_Getiri", "Altin_Getiri",
    "Kur_Vol", "Kur_Degisim", "CDS_5Y", "Enflasyon_x_Faiz",
]


def _safe_log(series: pd.Series) -> pd.Series:
    """log1p(|x|) * sign(x) — negatif değerleri de handle eder."""
    s = pd.to_numeric(series, errors="coerce")
    return np.sign(s) * np.log1p(np.abs(s))


def build_model_dataset():
    print("\n--- FORA_MODEL.xlsx Oluşturuluyor ---")

    df = read_fora()
    if df is None or df.empty:
        print("FORA.xlsx bulunamadı veya boş.")
        return

    # ── Tarih sütunlarını datetime'a çevir ────────────────────────
    df["Min Tarih"] = pd.to_datetime(df["Min Tarih"], dayfirst=True, errors="coerce")
    df["Max Tarih"] = pd.to_datetime(df["Max Tarih"], dayfirst=True, errors="coerce")

    # ── İleri Seviye Türetilmiş Feature'lar (FORA.xlsx'e yazmaz) ──
    df = derive_advanced_features(df)

    # ── Log Transforms ────────────────────────────────────────────
    log_count = 0
    for col in LOG_COLS:
        if col in df.columns:
            df[f"log_{col.replace(' ', '_')}"] = _safe_log(df[col])
            log_count += 1
    print(f"  Log transform: {log_count} kolon oluşturuldu.")

    # ── Lag Features ──────────────────────────────────────────────
    lag_count = 0
    for col in LAG_COLS:
        if col in df.columns:
            s = pd.to_numeric(df[col], errors="coerce")
            safe = col.replace(" ", "_")
            df[f"{safe}_lag1"] = s.shift(1)
            df[f"{safe}_lag2"] = s.shift(2)
            df[f"{safe}_lag4"] = s.shift(4)
            lag_count += 1
    print(f"  Lag (1,2,4 hafta): {lag_count} kolon grubu oluşturuldu.")

    # ── Rolling Mean & Std (4 hafta) ──────────────────────────────
    roll_count = 0
    for col in ROLLING_COLS:
        if col in df.columns:
            s = pd.to_numeric(df[col], errors="coerce")
            safe = col.replace(" ", "_")
            df[f"{safe}_roll4_mean"] = s.rolling(4, min_periods=2).mean().round(4)
            df[f"{safe}_roll4_std"]  = s.rolling(4, min_periods=2).std().round(4)
            roll_count += 1
    print(f"  Rolling mean+std (4 hafta): {roll_count} kolon grubu oluşturuldu.")

    # ── Delta (Haftadan Haftaya Fark) ─────────────────────────────
    delta_count = 0
    for col in DELTA_COLS:
        if col in df.columns:
            s = pd.to_numeric(df[col], errors="coerce")
            safe = col.replace(" ", "_")
            df[f"{safe}_delta1"] = s.diff(1).round(4)
            delta_count += 1
    print(f"  Delta (1 haftalık fark): {delta_count} kolon oluşturuldu.")

    # ── NET Lag/Roll (banka verisi varsa) ─────────────────────────
    if "NET" in df.columns:
        net = pd.to_numeric(df["NET"], errors="coerce")
        df["NET_lag1"]  = net.shift(1)
        df["NET_lag2"]  = net.shift(2)
        df["NET_lag4"]  = net.shift(4)
        df["NET_roll3"] = net.rolling(3, min_periods=2).mean().round(4)
        df["NET_roll8"] = net.rolling(8, min_periods=4).mean().round(4)
        print("  NET lag1/2/4 + roll3/8: oluşturuldu (banka verisi mevcut).")
    else:
        print("  ℹ NET kolonu yok — banka verisi eklenince NET_lag/roll otomatik oluşur.")

    # ── Tarih sütunlarını geri yükle ──────────────────────────────
    for col in ["Min Tarih", "Max Tarih"]:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = df[col].dt.strftime("%d.%m.%Y")

    # ── FORA_MODEL.xlsx'e kaydet ───────────────────────────────────
    df.to_excel(MODEL_PATH, index=False)
    print(f"\nFORA_MODEL.xlsx kaydedildi → {MODEL_PATH}")
    print(f"  Toplam: {len(df)} satır × {len(df.columns)} kolon\n")


if __name__ == "__main__":
    build_model_dataset()
