"""
fetch_google_trends.py
----------------------
Google Trends'ten mevduat faizi arama hacmini çeker ve FORA.xlsx'e yazar.

Çekilen veriler:
  - GT_Mevduat_Faizi : "mevduat faizi" arama hacmi (0-100 arası index, haftalık)
  - GT_En_Yuksek     : "en yüksek faiz" arama hacmi (0-100 arası index, haftalık)

Not: pytrends Google rate-limit'e takıldığında (HTTP 429) otomatik yeniden
     dener (max 4 deneme, üstel bekleme). Tüm denemeler başarısız olursa
     FORA yine de kaydedilir (mevcut değerler korunur).
"""

import time
import pandas as pd
from src.utils import read_fora, save_fora

# ── urllib3 v2.0+ uyumluluk düzeltmesi (import sırasında çalışır) ────────────────
# pytrends Retry(method_whitelist=...) kullanıyor, urllib3 v2.0'da allowed_methods oldu
def _patch_urllib3_retry():
    def _fix(mod):
        try:
            Retry = mod.util.retry.Retry
            if hasattr(Retry, "_mw_patched"):
                return
            _orig = Retry.__init__
            def _new_init(self, *a, **kw):
                if "method_whitelist" in kw:
                    kw["allowed_methods"] = kw.pop("method_whitelist")
                _orig(self, *a, **kw)
            Retry.__init__ = _new_init
            Retry._mw_patched = True
        except Exception:
            pass
    try:
        import urllib3; _fix(urllib3)
    except Exception:
        pass
    try:
        import requests.packages.urllib3 as _r; _fix(_r)
    except Exception:
        pass

_patch_urllib3_retry()

KEYWORDS = {
    "mevduat faizi":  "GT_Mevduat_Faizi",
    "en yüksek faiz": "GT_En_Yuksek",
}

MAX_RETRIES   = 4
BASE_SLEEP    = 15   # saniye — ilk bekleme; her denemede 2× artar
KEYWORD_SLEEP = 10   # iki keyword arasında bekleme


def _build_pytrends():
    try:
        from pytrends.request import TrendReq
    except ImportError:
        raise ImportError("pytrends yüklü değil: pip install pytrends")
    return TrendReq(hl="tr", tz=180, timeout=(10, 30), retries=2, backoff_factor=0.5)



def _fetch_trend_with_retry(pytrends, keyword: str, timeframe: str) -> pd.Series | None:
    """
    Tek bir keyword için Google Trends verisi çeker.
    HTTP 429 (rate limit) gelirse üstel backoff ile yeniden dener.
    """
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            pytrends.build_payload([keyword], timeframe=timeframe, geo="TR")
            time.sleep(3)
            df = pytrends.interest_over_time()
            if df.empty:
                print(f"    ⚠ Boş yanıt (deneme {attempt}/{MAX_RETRIES})")
                return None
            return df[keyword]
        except Exception as e:
            err_str = str(e)
            if "429" in err_str or "Too Many Requests" in err_str:
                wait = BASE_SLEEP * (2 ** (attempt - 1))
                print(f"    ⚠ Rate limit (429) — {wait}s bekleniyor (deneme {attempt}/{MAX_RETRIES})")
                time.sleep(wait)
            else:
                print(f"    ⚠ Google Trends hatası (deneme {attempt}/{MAX_RETRIES}): {e}")
                if attempt < MAX_RETRIES:
                    time.sleep(10)
    print(f"    ✗ '{keyword}' için tüm denemeler başarısız.")
    return None


def fetch_google_trends():
    print("\n--- Google Trends Verileri Çekiliyor ---")

    try:
        pytrends = _build_pytrends()
    except ImportError as e:
        print(f"  ⚠ {e}")
        return

    df_excel = read_fora()
    if df_excel is None or df_excel.empty:
        print("FORA.xlsx bulunamadı veya boş.")
        return

    df_excel["Min Tarih"] = pd.to_datetime(df_excel["Min Tarih"], dayfirst=True, errors="coerce")
    df_excel["Max Tarih"] = pd.to_datetime(df_excel["Max Tarih"], dayfirst=True, errors="coerce")

    min_date = df_excel["Min Tarih"].min()
    max_date = df_excel["Max Tarih"].max()
    timeframe = f"{min_date.strftime('%Y-%m-%d')} {max_date.strftime('%Y-%m-%d')}"
    print(f"  Timeframe: {timeframe}")

    for keyword, col_name in KEYWORDS.items():
        print(f"\n  → '{keyword}' çekiliyor...")

        if col_name not in df_excel.columns:
            df_excel[col_name] = None

        trend_series = _fetch_trend_with_retry(pytrends, keyword, timeframe)
        if trend_series is None:
            print(f"    Mevcut değerler korunuyor.")
            time.sleep(KEYWORD_SLEEP)
            continue

        print(f"    {len(trend_series)} haftalık değer alındı.")

        updated = 0
        for idx, row in df_excel.iterrows():
            r_start = row["Min Tarih"]
            r_end   = row["Max Tarih"]
            if pd.isna(r_start) or pd.isna(r_end):
                continue
            # Trend haftası FORA haftasıyla 3 günlük toleransla eşleştir
            mask = (
                (trend_series.index >= r_start - pd.Timedelta(days=3)) &
                (trend_series.index <= r_end   + pd.Timedelta(days=3))
            )
            subset = trend_series.loc[mask]
            if not subset.empty:
                df_excel.at[idx, col_name] = int(subset.iloc[0])
                updated += 1

        print(f"    {updated} satır güncellendi.")
        time.sleep(KEYWORD_SLEEP)

    # Tarih formatını geri yükle ve kaydet
    for col in ["Min Tarih", "Max Tarih"]:
        if pd.api.types.is_datetime64_any_dtype(df_excel[col]):
            df_excel[col] = df_excel[col].dt.strftime("%d.%m.%Y")

    save_fora(df_excel)
    print("\nFORA.xlsx kaydedildi (Google Trends verileri eklendi).\n")


if __name__ == "__main__":
    fetch_google_trends()
