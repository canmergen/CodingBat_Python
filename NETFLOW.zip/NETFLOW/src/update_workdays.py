import pandas as pd
from datetime import timedelta
from src.utils import read_fora, save_fora
from src.holidays import is_holiday

def update_workdays():
    print("\n--- Updating 'Full Workday' Status ---")
    df = read_fora()
    if df is None or df.empty:
        print("FORA.xlsx not found.")
        return

    updated_count = 0
    column_name = "Full Workday"
    
    if column_name not in df.columns:
        df[column_name] = None
        
    for index, row in df.iterrows():
        min_t = pd.to_datetime(row['Min Tarih'], dayfirst=True, errors='coerce')
        max_t = pd.to_datetime(row['Max Tarih'], dayfirst=True, errors='coerce')
        
        if pd.isna(min_t) or pd.isna(max_t):
            continue
            
        # Iterate dates in range
        curr = min_t
        is_full = 1
        
        while curr <= max_t:
            # Check if Weekday (0=Mon, 4=Fri) is a holiday
            if curr.weekday() < 5: # Mon-Fri
                if is_holiday(curr):
                    is_full = 0
                    break
            curr += timedelta(days=1)
            
        # Optimization: Don't rewrite if same (to avoid dirtying file)
        # But we want to ensure it is set.
        current_val = df.at[index, column_name]
        if current_val != is_full:
            df.at[index, column_name] = is_full
            updated_count += 1
            
    save_fora(df)
    print(f"Updated {updated_count} rows for '{column_name}'.")

if __name__ == "__main__":
    update_workdays()
