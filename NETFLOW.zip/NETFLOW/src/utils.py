
import pandas as pd
import os
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font, Alignment

FORA_PATH = "FORA.xlsx"

def read_fora():
    """
    Reads the FORA excel file intelligently.
    Tries to detect if headers are on Row 3 (Index 2) or Row 1 (Index 0).
    """
    if not os.path.exists(FORA_PATH):
        return None

    # Try reading with header on row 1 (Excel Row 2) - This seems to be the current format
    try:
        df = pd.read_excel(FORA_PATH, header=1)
        # Verify specific columns to confirm correctness
        if 'Min Tarih' in df.columns and 'Max Tarih' in df.columns:
            return df
    except Exception as e:
        print(f"DEBUG: read_fora header=1 failed: {e}")
        pass

    # Try reading with header on row 2 (Excel Row 3) - Old format?
    try:
        df = pd.read_excel(FORA_PATH, header=2)
        if 'Min Tarih' in df.columns and 'Max Tarih' in df.columns:
            print(f"DEBUG: read_fora success header=2. Shape: {df.shape}")
            return df
    except Exception:
        pass

    # Fallback to standard reading (header=0)
    try:
        df = pd.read_excel(FORA_PATH, header=0)
        if 'Min Tarih' in df.columns:
            print("DEBUG: read_fora success with header=0")
            return df
        else:
            print(f"DEBUG: read_fora header=0 missing expected columns. Cols: {df.columns.tolist()}")
    except Exception as e:
        print(f"DEBUG: read_fora header=0 failed: {e}")
        pass

    print("DEBUG: read_fora returning empty DataFrame (Data Loss risk)")
    return pd.DataFrame()  # Return empty if fails

def save_fora(df):
    """
    Saves the DataFrame to FORA.xlsx preserving the custom layout.
    Structure:
    Row 1: Empty
    Row 2: "FORA" Title (Merged, Orange BG, White Text)
    Row 3: Headers
    Row 4+: Data
    """

    # We need to preserve 'Details' sheet if it exists
    existing_sheets = {}
    if os.path.exists(FORA_PATH):
        try:
            xls = pd.ExcelFile(FORA_PATH)
            if 'Details' in xls.sheet_names:
                existing_sheets['Details'] = xls.parse('Details')
        except:
            pass

    with pd.ExcelWriter(FORA_PATH, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, startrow=2, sheet_name='Sheet1')

        # Restore Details sheet
        if 'Details' in existing_sheets:
            existing_sheets['Details'].to_excel(writer, index=False, sheet_name='Details')

    # 2. Apply Formatting with OpenPyXL
    wb = load_workbook(FORA_PATH)
    ws = wb['Sheet1']

    max_col = len(df.columns)

    # Merge A2 to {MaxCol}2
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=max_col)

    # Set Value
    title_cell = ws.cell(row=2, column=1)
    title_cell.value = "FORA"

    # Style — Background: (255, 98, 0) -> Hex: FF6200
    orange_fill = PatternFill(start_color="FF6200", end_color="FF6200", fill_type="solid")
    white_font = Font(color="FFFFFF", bold=True, size=14)
    center_align = Alignment(horizontal="center", vertical="center")

    title_cell.fill = orange_fill
    title_cell.font = white_font
    title_cell.alignment = center_align

    # 3. Apply Column Formatting
    # Find 'PP Getiri' column
    header_row = ws[3]
    pp_col_idx = None
    for cell in header_row:
        if cell.value == "PP Getiri":
            pp_col_idx = cell.column
            break

    if pp_col_idx:
        for row in range(4, ws.max_row + 1):
            cell = ws.cell(row=row, column=pp_col_idx)
            cell.number_format = '0.000000'   # Ondalık format (örn. 0.008500)

    wb.save(FORA_PATH)
    print("Saved FORA.xlsx with formatted layout.")
