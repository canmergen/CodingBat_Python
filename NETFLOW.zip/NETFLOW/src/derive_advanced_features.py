"""
derive_advanced_features.py
----------------------------
Mevcut FORA kolonlarından ileri seviye türetilmiş değişkenler oluşturur.
Harici veri gerektirmez — tamamı hesaplamayla üretilir.

Oluşturulan değişkenler:
  - Enflasyon_x_Faiz   : zscore(WebTufe) × zscore(TLREF) — eşiksiz interaction term
  - Market_Stress      : bileşik volatilite end. (BIST_Vol + Kur_Vol + VIX z-score ort.)
  - TLREF_lag1/2/4     : gecikmeli TLREF değerleri
  - TCMB1M_lag1        : gecikmeli TCMB 1M değeri
  - TLREF_EMA3         : TLREF üstel hareketli ortalama (span=3)
  - TLREF_x_KurVol     : Interaction term: TLREF × Kur_Vol
  - Faiz_Spread        : TCMB 1M - TLREF (piyasa-politika farkı)
  - TLREF_Bilesik      : TLREF bileşik karşılığı % → (1 + TLREF/36500)^365 - 1
"""

import pandas as pd
import numpy as np
from src.utils import read_fora, save_fora


# (ZK_CHANGES ve STOPAJ_CHANGES kaldırıldı — main.py CONFIG'den yönetiliyordu,
#  artık bu feature'lar modelde yer almıyor.)


def derive_advanced_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    FORA base DataFrame'ini alır, türetilmiş feature'ları ekler ve geri döndürür.
    FORA.xlsx'e dokunmaz — sadece FORA_MODEL.xlsx oluşturulurken çağrılır.
    """
    print("\n--- İleri Seviye Türetilmiş Değişkenler Oluşturuluyor ---")

    # ── 1. Enflasyon × Faiz Interaction Term ───────────────────────────────────
    # zscore(WebTufe) x zscore(TLREF)
    # Pozitif (yüksek): yüksek enflasyon + yüksek faiz = stres/kriz dönemi
    # Negatif : ikisi zıt yönde = geçiş dönemi
    # Eşik yok — veri sürekli, model kendi bölüsüm noktalarını öğrenir
    if "WebTufe" in df.columns and "TLREF" in df.columns:
        wt = pd.to_numeric(df["WebTufe"], errors="coerce")
        tl = pd.to_numeric(df["TLREF"],   errors="coerce")
        wt_z = (wt - wt.mean()) / wt.std() if wt.std() > 0 else wt * 0
        tl_z = (tl - tl.mean()) / tl.std() if tl.std() > 0 else tl * 0
        df["Enflasyon_x_Faiz"] = (wt_z * tl_z).round(4)
        print(f"  Enflasyon_x_Faiz: oluşturuldu (zscore(WebTufe) × zscore(TLREF))")
    else:
        print("  ⚠ Enflasyon_x_Faiz: WebTufe veya TLREF eksik, atlandı")

    # ── 4. Market Stress (Bileşik Volatilite) ────────────────────
    stress_cols = []
    for col in ["BIST_Vol", "Kur_Vol", "VIX"]:
        if col in df.columns:
            # Z-score normalize et
            s = pd.to_numeric(df[col], errors="coerce")
            mean_val = s.mean()
            std_val = s.std()
            if std_val and std_val > 0:
                df[f"_z_{col}"] = (s - mean_val) / std_val
                stress_cols.append(f"_z_{col}")

    if stress_cols:
        df["Market_Stress"] = df[stress_cols].mean(axis=1).round(4)
        # Temizlik
        df.drop(columns=stress_cols, inplace=True)
        filled = df["Market_Stress"].notna().sum()
        print(f"  Market_Stress: {filled} satır (z-score avg of {[c.replace('_z_','') for c in stress_cols]})")
    else:
        print("  ⚠ Market_Stress: Volatilite kolonları yok")

    # ── 5. Lagged Interest Rates ─────────────────────────────────
    if "TLREF" in df.columns:
        tlref = pd.to_numeric(df["TLREF"], errors="coerce")
        df["TLREF_lag1"] = tlref.shift(1)
        df["TLREF_lag2"] = tlref.shift(2)
        df["TLREF_lag4"] = tlref.shift(4)
        print(f"  TLREF_lag1/2/4: oluşturuldu")

    if "TCMB 1M" in df.columns:
        tcmb = pd.to_numeric(df["TCMB 1M"], errors="coerce")
        df["TCMB1M_lag1"] = tcmb.shift(1)
        print(f"  TCMB1M_lag1: oluşturuldu")

    # ── 6. EMA (Üstel Hareketli Ortalama) ────────────────────────
    if "TLREF" in df.columns:
        tlref = pd.to_numeric(df["TLREF"], errors="coerce")
        df["TLREF_EMA3"] = tlref.ewm(span=3, adjust=False).mean().round(4)
        print(f"  TLREF_EMA3: oluşturuldu")

    # ── 7. Interaction Terms ─────────────────────────────────────
    if "TLREF" in df.columns and "Kur_Vol" in df.columns:
        tlref = pd.to_numeric(df["TLREF"], errors="coerce")
        kur_vol = pd.to_numeric(df["Kur_Vol"], errors="coerce")
        df["TLREF_x_KurVol"] = (tlref * kur_vol).round(4)
        print(f"  TLREF_x_KurVol: oluşturuldu")

    # ── 8. Faiz Spread (TCMB 1M - TLREF) ────────────────────────
    if "TCMB 1M" in df.columns and "TLREF" in df.columns:
        tcmb = pd.to_numeric(df["TCMB 1M"], errors="coerce")
        tlref = pd.to_numeric(df["TLREF"], errors="coerce")
        df["Faiz_Spread"] = (tcmb - tlref).round(4)
        print(f"  Faiz_Spread: oluşturuldu (TCMB 1M - TLREF)")

    # ── 9. TLREF Bileşik ─────────────────────────────────────────
    # Türk bankacılık standardı: basit yıllık oran → bileşik yıllık oran
    # Formül: (1 + r/36500)^365 - 1  →  % olarak ifade edilir
    if "TLREF" in df.columns:
        tlref = pd.to_numeric(df["TLREF"], errors="coerce")
        df["TLREF_Bilesik"] = ((1 + tlref / 36500) ** 365 - 1).mul(100).round(4)
        print(f"  TLREF_Bilesik: oluşturuldu")

    # ── 10. TCMB 1M Bileşik ──────────────────────────────────────
    if "TCMB 1M" in df.columns:
        tcmb1m = pd.to_numeric(df["TCMB 1M"], errors="coerce")
        df["TCMB1M_Bilesik"] = ((1 + tcmb1m / 36500) ** 365 - 1).mul(100).round(4)
        print(f"  TCMB1M_Bilesik: oluşturuldu")

    # ── 11. Benchmark Bileşik ─────────────────────────────────────
    if "Benchmark" in df.columns:
        bench = pd.to_numeric(df["Benchmark"], errors="coerce")
        df["Benchmark_Bilesik"] = ((1 + bench / 36500) ** 365 - 1).mul(100).round(4)
        print(f"  Benchmark_Bilesik: oluşturuldu")

    # ── 12. Reel Faiz (TLREF - WebTufe) ──────────────────────────
    # Pozitif → TL'de kal mantıklı; negatif → para başka varlığa kaçar
    if "TLREF" in df.columns and "WebTufe" in df.columns:
        tlref  = pd.to_numeric(df["TLREF"],   errors="coerce")
        wtufe  = pd.to_numeric(df["WebTufe"], errors="coerce")
        # WebTufe aylık %; TLREF yıllık % → TLREF/12 ile kıyaslanabilir
        df["Reel_Faiz"] = (tlref / 12 - wtufe).round(4)
        print(f"  Reel_Faiz: oluşturuldu (TLREF/12 - WebTufe_aylik)")


    # ── 15. BIST100 Haftalık Getiri (%) ──────────────────────────
    if "BIST100" in df.columns:
        bist = pd.to_numeric(df["BIST100"], errors="coerce")
        df["BIST100_Getiri"] = bist.pct_change().mul(100).round(4)
        print(f"  BIST100_Getiri: oluşturuldu (haftalık %)")

    # ── 16. Altın Haftalık Getiri (%) ────────────────────────────
    if "Gram_Altin_TRY" in df.columns:
        altin = pd.to_numeric(df["Gram_Altin_TRY"], errors="coerce")
        df["Altin_Getiri"] = altin.pct_change().mul(100).round(4)
        print(f"  Altin_Getiri: oluşturuldu (haftalık %)")

    # ── 17. Kur Değişim (USD/TRY haftalık %) ─────────────────────
    if "USD_TRY" in df.columns:
        usd = pd.to_numeric(df["USD_TRY"], errors="coerce")
        df["Kur_Degisim"] = usd.pct_change().mul(100).round(4)
        print(f"  Kur_Degisim: oluşturuldu (USD/TRY haftalık %)")

    # ── 18. Sepet Kur Değişim (haftalık %) ───────────────────────
    if "Sepet Kur" in df.columns:
        sepet = pd.to_numeric(df["Sepet Kur"], errors="coerce")
        df["Sepet_Kur_Degisim"] = sepet.pct_change().mul(100).round(4)
        print(f"  Sepet_Kur_Degisim: oluşturuldu (haftalık %)")


    # ══════════════════════════════════════════════════════════════
    # ── Sinyal Kombinasyonları (Composite Features) ───────────────
    # Z-score: tüm FORA verisi üzerinden hesaplanır (expanding değil).
    # Gerçek zamanlı tahminlerde train-set mean/std kullanılmalı.
    # ══════════════════════════════════════════════════════════════

    def _zscore(series: "pd.Series") -> "pd.Series":
        """Sıfır std durumunda NaN döndürür."""
        s = pd.to_numeric(series, errors="coerce")
        mu, sigma = s.mean(), s.std()
        if sigma == 0 or pd.isna(sigma):
            return pd.Series(np.nan, index=s.index)
        return (s - mu) / sigma

    # ── 20. Market Stress Composite ───────────────────────────────
    # zscore(CDS_Δ%) + zscore(Kur_Vol) - zscore(Tuketici_Guven_Δ%)
    # Yükselirse → piyasa stresi artıyor → mevduattan kaçış riski
    msc_parts = []
    if "CDS_5Y" in df.columns:
        cds_chg = pd.to_numeric(df["CDS_5Y"], errors="coerce").pct_change().mul(100)
        msc_parts.append(("CDS", +1, _zscore(cds_chg)))
    if "Kur_Vol" in df.columns:
        msc_parts.append(("KurVol", +1, _zscore(pd.to_numeric(df["Kur_Vol"], errors="coerce"))))
    if "Tuketici_Guven" in df.columns:
        tg_chg = pd.to_numeric(df["Tuketici_Guven"], errors="coerce").pct_change().mul(100)
        msc_parts.append(("TukGuven", -1, _zscore(tg_chg)))   # negatif: güven düşerse stres artar

    if len(msc_parts) >= 2:
        composite = sum(sign * s for _, sign, s in msc_parts)
        df["Market_Stress_Composite"] = composite.round(4)
        components = [name for name, _, _ in msc_parts]
        print(f"  Market_Stress_Composite: oluşturuldu ({'+'.join(components)})")
    else:
        print("  ⚠ Market_Stress_Composite: yeterli kolon yok (CDS_5Y, Kur_Vol gerekli)")

    # ── 21. Alternatif Getiri Baskısı ────────────────────────────
    # zscore(Altın_Δ%) + zscore(BIST100_Δ%)
    # İkisi aynı anda artarsa → mevduattan çıkış baskısı çok güçlü
    agb_parts = []
    if "Altin_Getiri" in df.columns:
        agb_parts.append(_zscore(pd.to_numeric(df["Altin_Getiri"], errors="coerce")))
    if "BIST100_Getiri" in df.columns:
        agb_parts.append(_zscore(pd.to_numeric(df["BIST100_Getiri"], errors="coerce")))

    if len(agb_parts) >= 2:
        df["Alt_Getiri_Pressure"] = sum(agb_parts).round(4)
        print(f"  Alt_Getiri_Pressure: oluşturuldu (Altın + BIST100 z-score)")
    elif len(agb_parts) == 1:
        df["Alt_Getiri_Pressure"] = agb_parts[0].round(4)
        print(f"  Alt_Getiri_Pressure: tek bileşenle oluşturuldu")
    else:
        print("  ⚠ Alt_Getiri_Pressure: Altin_Getiri veya BIST100_Getiri eksik")

    # ── 22. Üretim Baskısı Sinyali ────────────────────────────────
    # -zscore(KKO_Δ%) + zscore(Bakır_Δ%)
    # KKO düşerken bakır artıyorsa → maliyet enflasyonu → faiz baskısı
    ubp_parts = []
    if "KKO" in df.columns:
        kko_chg = pd.to_numeric(df["KKO"], errors="coerce").pct_change().mul(100)
        ubp_parts.append(("KKO", -1, _zscore(kko_chg)))   # negatif: KKO düşüşü = baskı artar
    if "Bakir" in df.columns:
        bakir_chg = pd.to_numeric(df["Bakir"], errors="coerce").pct_change().mul(100)
        ubp_parts.append(("Bakir", +1, _zscore(bakir_chg)))

    if len(ubp_parts) >= 1:
        composite = sum(sign * s for _, sign, s in ubp_parts)
        df["Uretim_Baski"] = composite.round(4)
        components = [name for name, _, _ in ubp_parts]
        print(f"  Uretim_Baski: oluşturuldu ({'+'.join(components)})")
    else:
        print("  ⚠ Uretim_Baski: KKO ve Bakir kolonları eksik")

    # ── 23. Dış Şok Endeksi ──────────────────────────────────────
    # zscore(VIX) + zscore(EUR_USD_Δ%) + zscore(CDS_Δ%)
    # Global risk + TL kuru + ülke riski aynı anda artıyorsa → dış şok
    dse_parts = []
    if "VIX" in df.columns:
        dse_parts.append(_zscore(pd.to_numeric(df["VIX"], errors="coerce")))
    if "EUR_USD" in df.columns:
        eurusd_chg = pd.to_numeric(df["EUR_USD"], errors="coerce").pct_change().mul(100)
        dse_parts.append(_zscore(eurusd_chg))
    if "CDS_5Y" in df.columns:
        cds_chg = pd.to_numeric(df["CDS_5Y"], errors="coerce").pct_change().mul(100)
        dse_parts.append(_zscore(cds_chg))

    if len(dse_parts) >= 2:
        df["Dis_Sok_Endeksi"] = sum(dse_parts).round(4)
        print(f"  Dis_Sok_Endeksi: oluşturuldu (VIX + EUR_USD_Δ + CDS_Δ)")
    else:
        print("  ⚠ Dis_Sok_Endeksi: yeterli kolon yok (VIX, EUR_USD, CDS_5Y gerekli)")

    # ── 24. Davranışsal Proxy Göstergeleri (BKM + WebTufe) ──────────
    # ─────────────────────────────────────────────────────────────────
    # 24a. Reel Giyim Talebi — Greenspan "Men's Underwear Index"
    # Nominal harcama / fiyat endeksi → gerçek talep hacmi
    # Düşüş: hanehalkı nakit koruma moduna geçiyor (faizde baskı ↑)
    if "BKM_Giyim_TL" in df.columns and "WebTufe_Giyim_Endeks" in df.columns:
        giyim_tl  = pd.to_numeric(df["BKM_Giyim_TL"],       errors="coerce")
        giyim_end = pd.to_numeric(df["WebTufe_Giyim_Endeks"], errors="coerce")
        reel_giyim = (giyim_tl / giyim_end).round(4)
        df["Reel_Giyim"] = reel_giyim
        print("  Reel_Giyim: oluşturuldu (BKM_Giyim_TL / WebTufe_Giyim_Endeks)")
    else:
        print("  ⚠ Reel_Giyim: BKM_Giyim_TL veya WebTufe_Giyim_Endeks eksik")

    # 24b. Lipstick Ratio — "The Lipstick Effect"
    # Kozmetik/Giyim oranı: kriz döneminde kozmetik artarken giyim düşer
    # Stagflasyon sinyali: genel tüketim düşerken bu oran yükselir
    if "BKM_Kozmetik_TL" in df.columns and "BKM_Giyim_TL" in df.columns:
        kozmetik = pd.to_numeric(df["BKM_Kozmetik_TL"], errors="coerce")
        giyim_tl = pd.to_numeric(df["BKM_Giyim_TL"],   errors="coerce")
        lipstick = (kozmetik / giyim_tl).round(4)
        df["Lipstick_Ratio"] = lipstick
        print("  Lipstick_Ratio: oluşturuldu (BKM_Kozmetik_TL / BKM_Giyim_TL)")
    else:
        print("  ⚠ Lipstick_Ratio: BKM_Kozmetik_TL veya BKM_Giyim_TL eksik")

    # 24c. Reel Yemek Talebi — Service Economy Proxy
    # Dışarıda yemek yeme hacmi: harcanabilir gelir ve güven sinyali
    # Fiyat artışından kaynaklanan nominal artıştan arındırılmış
    if "BKM_Yemek_TL" in df.columns and "WebTufe_Hizmet_Endeks" in df.columns:
        yemek_tl  = pd.to_numeric(df["BKM_Yemek_TL"],        errors="coerce")
        hizmet_end = pd.to_numeric(df["WebTufe_Hizmet_Endeks"], errors="coerce")
        reel_yemek = (yemek_tl / hizmet_end).round(4)
        df["Reel_Yemek"] = reel_yemek
        print("  Reel_Yemek: oluşturuldu (BKM_Yemek_TL / WebTufe_Hizmet_Endeks)")
    else:
        print("  ⚠ Reel_Yemek: BKM_Yemek_TL veya WebTufe_Hizmet_Endeks eksik")

    # 24d. Reel Kozmetik Talebi — Lipstick Effect için doğru deflator
    # BKM_Kozmetik_TL / WebTufe_KisiselBakim_Endeks
    # Not: Lipstick_Ratio (24b) = nominal kozmetik/giyim spending oranı → DOĞRU (spending mix'i)
    # Reel_Kozmetik = nominal kozmetik harcaması / kişisel bakım fiyat endeksi → RAW HACİM (doğru)
    if "BKM_Kozmetik_TL" in df.columns and "WebTufe_KisiselBakim_Endeks" in df.columns:
        kozmetik    = pd.to_numeric(df["BKM_Kozmetik_TL"],             errors="coerce")
        kbakim_end  = pd.to_numeric(df["WebTufe_KisiselBakim_Endeks"], errors="coerce")
        df["Reel_Kozmetik"] = (kozmetik / kbakim_end).round(4)
        print("  Reel_Kozmetik: oluşturuldu (BKM_Kozmetik_TL / WebTufe_KisiselBakim_Endeks)")
    else:
        print("  ⚠ Reel_Kozmetik: BKM_Kozmetik_TL veya WebTufe_KisiselBakim_Endeks eksik")

    # ── 25. WebTufe Enflasyon Oran Göstergeleri ──────────────────────
    # Her biri "bu kategori genel enflasyonun ne kadar üstünde?" sorusunu yanıtlar.
    # Düzey oranı: her iki endeks de aynı dönem bazlıdır → anlamlı karşılaştırma ✅
    # Değişimi yorumla: oran YÜKSELIYORSA o kategori genel CPI'ı aşıyor demektir.

    # 25a. Gıda Spread — Stagflasyon öncü sinyali
    # Gıda enflasyonu arzdan kaynaklı (supply-side) → TCMB'nin faiz kesmesini geciktirir
    # Artan oran: hanehalkının zorunlu gıda harcamaları artıyor → refah baskısı → mevduata baskı
    if "WebTufe_Gida_Endeks" in df.columns and "WebTufe_Endeks" in df.columns:
        gida = pd.to_numeric(df["WebTufe_Gida_Endeks"], errors="coerce")
        gen  = pd.to_numeric(df["WebTufe_Endeks"],      errors="coerce")
        df["Gida_Spread"] = (gida / gen).round(6)
        print("  Gida_Spread: oluşturuldu (WebTufe_Gida / WebTufe_Genel)")
    else:
        print("  ⚠ Gida_Spread: WebTufe_Gida_Endeks veya WebTufe_Endeks eksik")

    # 25b. Enerji Spread — İthalat kaynaklı şok göstergesi
    # Enerji TL değer kaynaklı artarsa → TCMB'nin elini bağlar, faiz kesmekten çekinir
    if "WebTufe_Enerji_Endeks" in df.columns and "WebTufe_Endeks" in df.columns:
        enerji = pd.to_numeric(df["WebTufe_Enerji_Endeks"], errors="coerce")
        gen    = pd.to_numeric(df["WebTufe_Endeks"],        errors="coerce")
        df["Enerji_Spread"] = (enerji / gen).round(6)
        print("  Enerji_Spread: oluşturuldu (WebTufe_Enerji / WebTufe_Genel)")
    else:
        print("  ⚠ Enerji_Spread: WebTufe_Enerji_Endeks veya WebTufe_Endeks eksik")

    # 25c. Hizmet vs Gıda — Ücret-fiyat sarmalı (wage-price spiral) erken uyarısı
    # Hizmet enflasyonu ücretle sürülür (sticky) → gıdayı geçmeye başlarsa
    # faiz indirimini zorlaştırır (çekirdek enflasyonun kalıcı kalması riski)
    # Düşen oran (2025 Türkiye): gıda hızlı artıyor, hizmet geride → ücretler henüz yetişmedi
    if "WebTufe_Hizmet_Endeks" in df.columns and "WebTufe_Gida_Endeks" in df.columns:
        hizmet = pd.to_numeric(df["WebTufe_Hizmet_Endeks"], errors="coerce")
        gida   = pd.to_numeric(df["WebTufe_Gida_Endeks"],   errors="coerce")
        df["Hizmet_vs_Gida"] = (hizmet / gida).round(6)
        print("  Hizmet_vs_Gida: oluşturuldu (Hizmet / Gıda — ücret sarmalı öncü)")
    else:
        print("  ⚠ Hizmet_vs_Gida: WebTufe_Hizmet_Endeks veya WebTufe_Gida_Endeks eksik")

    # 25d. Zorunlu Harcama Baskısı — Gıda + Enerji birlikte genel CPI'ı aşıyor mu?
    # Yüksek değer: tüm zorunlu harcamalar fiyatlanıyor → harcanabilir gelir erir
    # → mevduat birikimi güçleşir → bankalar rekabetçi faiz vermek zorunda kalır
    if all(c in df.columns for c in ["WebTufe_Gida_Endeks","WebTufe_Enerji_Endeks","WebTufe_Endeks"]):
        gida   = pd.to_numeric(df["WebTufe_Gida_Endeks"],   errors="coerce")
        enerji = pd.to_numeric(df["WebTufe_Enerji_Endeks"], errors="coerce")
        gen    = pd.to_numeric(df["WebTufe_Endeks"],        errors="coerce")
        df["Zorunlu_Harcama_Baskisi"] = ((gida + enerji) / (2 * gen)).round(6)
        print("  Zorunlu_Harcama_Baskisi: oluşturuldu ((Gıda+Enerji) / (2×Genel))")
    else:
        print("  ⚠ Zorunlu_Harcama_Baskisi: gerekli kolonlar eksik")

    # ── Tarih formatlarını geri yükle ───────────────────────────────
    for col in ["Min Tarih", "Max Tarih"]:
        if col in df.columns and pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = df[col].dt.strftime("%d.%m.%Y")

    return df


if __name__ == "__main__":
    # Standalone test — FORA.xlsx'ten okur, feature engineering uygular, yazmaz.
    _df = read_fora()
    if _df is not None:
        _df["Min Tarih"] = pd.to_datetime(_df["Min Tarih"], dayfirst=True, errors="coerce")
        _df["Max Tarih"] = pd.to_datetime(_df["Max Tarih"], dayfirst=True, errors="coerce")
        _out = derive_advanced_features(_df)
        print(f"\nÇıktı: {_out.shape[0]} satır × {_out.shape[1]} kolon (FORA.xlsx'e yazılmadı)")
