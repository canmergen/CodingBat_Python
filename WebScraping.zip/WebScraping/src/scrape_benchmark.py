"""
scrape_benchmark.py
-------------------
hesapkurdu.com'dan tüm bankaların 1 günlük vadeli TL mevduat faiz oranlarını
Playwright ile çeker ve benchmark.xlsx arşivine ekler.

Arşiv yapısı (benchmark.xlsx):
  Date | TEB | Deniz | Fiba | Akbank | QNB | ... | Avg_Target | Avg_All

main.py tarafından aggregate_benchmark() çağrılır:
  benchmark.xlsx → haftalık ortalama → FIRAST.xlsx
  - Benchmark      : TEB + Deniz + Fiba + Akbank ortalaması
  - Benchmark_All  : tüm mevcut banka ortalaması

Not: ING hariç tutulur.
"""

import os
import time
import pandas as pd
from playwright.sync_api import sync_playwright

from src.utils import read_firast, save_firast, log_baslik

# ---------------------------------------------------------------------------
URL              = "https://www.hesapkurdu.com/mevduat-teklifleri/1-gun-100000-tl?type=1"
BENCHMARK_PATH   = "benchmark.xlsx"         # Günlük arşiv — FIRAST.xlsx ile aynı dizinde
EXCLUDE_BANKS    = {"ing"}

# 4 hedef banka — FIRAST'daki "Benchmark" kolonunu bunlar belirler
TARGET_BANKS = ["TEB", "Deniz", "Fiba", "Akbank"]

# hesapkurdu banka adı → kısa kolon adı
BANK_NAME_MAP = {
    "CEPTETEB"                       : "TEB",
    "TEB"                            : "TEB",
    "DenizBank"                      : "Deniz",
    "Akbank"                         : "Akbank",
    "Fibabanka"                      : "Fiba",
    "Yapı Kredi"                     : "YapiKredi",
    "Odeabank"                       : "Odeabank",
    "QNB"                            : "QNB",
    "Enpara.com"                     : "Enpara",
    "Alternatif Bank"                : "AltBank",
    "Türkiye Finans Katılım Bankası" : "TurkiyeFinans",
    "Vakıf Katılım"                  : "VakifKatilim",
    "Hayat Finans"                   : "HayatFinans",
    "ON Dijital Bankacılık"          : "ON",
    "Aktif Bank"                     : "AktifBank",
    "Ziraat Bankası"                 : "Ziraat",
    "Garanti BBVA"                   : "Garanti",
    "Halkbank"                       : "Halkbank",
    "VakıfBank"                      : "Vakifbank",
    "İş Bankası"                     : "IsBank",
    "HSBC"                           : "HSBC",
    "ICBC Turkey"                    : "ICBC",
    "ING"                            : "ING",      # filtered out below
}

UA = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)

_JS_EXTRACT = """
() => {
    const results = [];
    const BAD = ["feedback","order","filter","stars","logo",
                 "legend_toggle","HesapKurdu Logo","Ak Portf\u00f6y",
                 "percent-circle","help_outline","search-white","search"];
    const cards = document.querySelectorAll("[class*='Container_root']");
    for (const card of cards) {
        // T\u00fcm img'leri tara — BAD olmayan ilk alt'\u0131 al (Odeabank fix)
        const imgs = card.querySelectorAll("img[alt]");
        let alt = null;
        for (const img of imgs) {
            const a = img.alt.trim();
            if (a && a.length >= 2 && !BAD.includes(a)) { alt = a; break; }
        }
        if (!alt) continue;
        const text = card.innerText || "";
        // Ondalıklı veya tam sayı oran: "% 43,25" veya "% 43"
        const m = text.match(/% ?([0-9]{2,3}(?:[.,][0-9]{1,2})?)/);
        if (!m) continue;
        results.push({bank: alt, rate_str: m[1]});
    }
    return results;
}
"""
# ---------------------------------------------------------------------------


# hangikredi.com'dan alınacak bankalar ve hedef kolon adı
_HANGIKREDI_URL     = "https://www.hangikredi.com/yatirim-araclari/mevduat-faiz-oranlari"
_HANGIKREDI_TARGETS = {
    "anadolubank" : "Anadolubank",
    "fibabanka"   : "Fiba",
}


def _scrape_hangikredi_rates() -> dict[str, float]:
    """
    hangikredi.com'dan Anadolubank ve Fibabanka'nın günlük mevduat oranını çeker.
    Aralık varsa (örn. %30-42) maksimum değeri alır.
    """
    rates: dict[str, float] = {}

    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True)
        ctx = browser.new_context(user_agent=UA)
        page = ctx.new_page()
        print("  hangikredi.com sayfası açılıyor...")
        page.goto(_HANGIKREDI_URL, wait_until="load", timeout=60_000)
        time.sleep(6)

        rows = page.evaluate("""
            () => {
                const out = [];
                const trs = document.querySelectorAll("tr");
                for (const tr of trs) {
                    const txt = tr.innerText || "";
                    if (txt.includes("%") && txt.trim().length > 3)
                        out.push(txt.replace(/\\n/g, " ").replace(/\\t/g, " ").trim());
                }
                return out;
            }
        """)
        browser.close()

    import re
    for row in rows:
        row_lower = row.lower()
        for keyword, col_name in _HANGIKREDI_TARGETS.items():
            if keyword in row_lower:
                # "% 30 - 42" veya "% 44" formatlarını parse et: hem % sonrası hem tire sonrası sayıları al
                nums = re.findall(r"(?:%|-)\s*(\d{2,3}(?:[.,]\d{1,2})?)", row)
                if nums:
                    vals = [float(n.replace(",", ".")) for n in nums if n]
                    valid = [v for v in vals if 5 < v < 100]
                    if valid:
                        rates[col_name] = max(valid)
    return rates


def _scrape_rates() -> dict[str, float]:
    """Playwright ile hesapkurdu.com'u açar, {kolon_adı: oran} döndürür."""
    rates: dict[str, float] = {}

    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True)
        ctx = browser.new_context(user_agent=UA)
        page = ctx.new_page()
        print("  hesapkurdu.com sayfası açılıyor...")
        page.goto(URL, wait_until="load", timeout=60_000)
        time.sleep(8)
        pairs = page.evaluate(_JS_EXTRACT)
        browser.close()

    print(f"  {len(pairs)} banka-oran çifti alındı.")

    seen: set[str] = set()
    for item in pairs:
        bank_raw = item["bank"]
        rate_str = item["rate_str"].replace(",", ".")
        try:
            rate = float(rate_str)
        except ValueError:
            continue
        if rate < 5 or rate > 100:
            continue
        col = BANK_NAME_MAP.get(bank_raw, bank_raw.replace(" ", "_"))
        # ING filtresi
        if col.lower() in EXCLUDE_BANKS or bank_raw.lower() in EXCLUDE_BANKS:
            continue
        if col not in seen:
            rates[col] = rate
            seen.add(col)

    # hangikredi'den Anadolubank + Fiba ekle (varsa hesapkurdu'yu ezmez)
    hk_rates = _scrape_hangikredi_rates()
    for col, rate in hk_rates.items():
        if col not in rates:
            rates[col] = rate
            print(f"  hangikredi'den eklendi: {col} = {rate}")

    return rates


def scrape_benchmark():
    """
    Bugünkü faiz oranlarını çekip benchmark.xlsx arşivine ekler.
    Aynı gün zaten varsa üzerine yazar.
    """
    log_baslik(
        "Benchmark (günlük banka teklifleri arşivi)",
        "https://www.hesapkurdu.com/mevduat-teklifleri/1-gun-100000-tl + https://www.hangikredi.com/yatirim-araclari/mevduat-faiz-oranlari · Playwright",
    )
    today_str = pd.Timestamp.today().strftime("%d.%m.%Y")
    today_ts  = pd.Timestamp.today().normalize()

    # Günlük oranları çek
    rates = _scrape_rates()
    if not rates:
        print("Uyarı: Hiçbir banka faiz oranı alınamadı.")
        return

    print(f"  Bankalar: {rates}")

    # Ortalamalar
    target_vals = [rates[b] for b in TARGET_BANKS if b in rates]
    all_vals    = list(rates.values())
    avg_target  = round(sum(target_vals) / len(target_vals), 4) if target_vals else None
    avg_all     = round(sum(all_vals)    / len(all_vals),    4) if all_vals    else None

    # Yeni satır oluştur
    new_row = {"Date": today_ts}
    new_row.update(rates)
    new_row["Avg_Target"] = avg_target   # TEB + Deniz + Fiba + Akbank ort.
    new_row["Avg_All"]    = avg_all      # Tüm bankalar ort.

    # Mevcut arşivi oku veya baştan oluştur
    if os.path.exists(BENCHMARK_PATH):
        df_raw = pd.read_excel(BENCHMARK_PATH)
        df_raw["Date"] = pd.to_datetime(df_raw["Date"], dayfirst=True, errors="coerce")
        # Bugün varsa kaldır (üzerine yazacağız)
        df_raw = df_raw[df_raw["Date"].dt.normalize() != today_ts]
    else:
        df_raw = pd.DataFrame()
        print(f"  benchmark.xlsx yok, sıfırdan oluşturuluyor.")

    # Yeni satırı ekle ve tarihe göre sırala
    df_new = pd.DataFrame([new_row])
    df_raw = pd.concat([df_raw, df_new], ignore_index=True)
    df_raw = df_raw.sort_values("Date").reset_index(drop=True)

    # Banka oranlarını olduğu gibi bırak — eksik günler NaN kalır
    bank_cols = [c for c in df_raw.columns if c not in ("Date", "Avg_Target", "Avg_All")]

    # Ortalamaları hesapla (NaN olanlar ortalamaya dahil edilmez)
    for idx in df_raw.index:
        t_vals = [df_raw.at[idx, b] for b in TARGET_BANKS
                  if b in df_raw.columns and pd.notna(df_raw.at[idx, b])]
        a_vals = [df_raw.at[idx, c] for c in bank_cols
                  if c in df_raw.columns and pd.notna(df_raw.at[idx, c])]
        df_raw.at[idx, "Avg_Target"] = round(sum(t_vals) / len(t_vals), 4) if t_vals else None
        df_raw.at[idx, "Avg_All"]    = round(sum(a_vals) / len(a_vals), 4) if a_vals else None

    filled = {b: df_raw.at[df_raw.index[-1], b]
              for b in bank_cols
              if b not in rates and b in df_raw.columns
              and pd.notna(df_raw.at[df_raw.index[-1], b])}
    if filled:
        detail = ", ".join(f"{b}={v}" for b, v in filled.items())
        print(f"  Forward-fill uygulandı ({len(filled)} banka): {detail}")

    # Güncel ortalamaları logla
    last = df_raw.iloc[-1]
    avg_target = last.get("Avg_Target")
    avg_all    = last.get("Avg_All")

    # Date'i okunabilir formatta kaydet
    df_raw["Date"] = df_raw["Date"].dt.strftime("%d.%m.%Y")
    df_raw.to_excel(BENCHMARK_PATH, index=False)

    print(f"  benchmark.xlsx güncellendi. "
          f"Avg_Target={avg_target}  Avg_All={avg_all}")


def aggregate_benchmark():
    """
    benchmark.xlsx'deki günlük verileri okur,
    FIRAST.xlsx'teki her hafta aralığı için ortalama hesaplar ve yazar.

    FIRAST'ya eklenen kolonlar:
      Benchmark     → o haftadaki Avg_Target (TEB+Deniz+Fiba+Akbank) ortalaması
      Benchmark_All → o haftadaki Avg_All    (tüm bankalar) ortalaması
    """
    log_baslik(
        "Benchmark, Benchmark_All",
        "benchmark.xlsx (günlük arşiv) → FIRAST haftalık ortalama (harici kaynak yok)",
    )
    if not os.path.exists(BENCHMARK_PATH):
        print("  benchmark.xlsx bulunamadı, atlanıyor.")
        return

    df_raw = pd.read_excel(BENCHMARK_PATH)
    if df_raw.empty:
        print("  benchmark.xlsx boş, atlanıyor.")
        return

    df_raw["Date"] = pd.to_datetime(df_raw["Date"], dayfirst=True, errors="coerce")

    df = read_firast()
    if df is None or df.empty:
        print("  FIRAST.xlsx bulunamadı, atlanıyor.")
        return

    df["Min_Tarih"] = pd.to_datetime(df["Min_Tarih"], dayfirst=True, errors="coerce")
    df["Max_Tarih"] = pd.to_datetime(df["Max_Tarih"], dayfirst=True, errors="coerce")

    if "Benchmark"     not in df.columns: df["Benchmark"]     = None
    if "Benchmark_All" not in df.columns: df["Benchmark_All"] = None

    updated = 0
    for idx, row in df.iterrows():
        r_start = row["Min_Tarih"]
        r_end   = row["Max_Tarih"]
        if pd.isna(r_start) or pd.isna(r_end):
            continue

        mask   = (df_raw["Date"] >= r_start) & (df_raw["Date"] <= r_end)
        subset = df_raw.loc[mask]
        if subset.empty:
            continue

        avg_t = subset["Avg_Target"].dropna().mean()
        avg_a = subset["Avg_All"].dropna().mean()

        if not pd.isna(avg_t):
            df.at[idx, "Benchmark"]     = round(avg_t, 4)
        if not pd.isna(avg_a):
            df.at[idx, "Benchmark_All"] = round(avg_a, 4)
        updated += 1

    # Boş haftalar NaN olarak kalır (interpolasyon yok)
    for bench_col in ("Benchmark", "Benchmark_All"):
        df[bench_col] = pd.to_numeric(df[bench_col], errors="coerce").round(4)

    # Benchmark_All'ı Benchmark'ın hemen yanına taşı
    cols = [c for c in df.columns if c != "Benchmark_All"]
    if "Benchmark" in cols:
        bench_idx = cols.index("Benchmark")
        cols.insert(bench_idx + 1, "Benchmark_All")
        df = df[cols]

    # Tarih formatını geri yükle
    for col in ["Min_Tarih", "Max_Tarih"]:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = df[col].dt.strftime("%d.%m.%Y")

    save_firast(df)
    print(f"  {updated} hafta satırı güncellendi "
          f"(Benchmark + Benchmark_All).")


if __name__ == "__main__":
    scrape_benchmark()
