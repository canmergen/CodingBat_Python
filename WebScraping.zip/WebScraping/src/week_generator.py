import pandas as pd
from datetime import datetime, timedelta
from src.utils import read_firast, save_firast, log_baslik

def generate_weeks(start_date: "datetime" = None):
    """
    Pazartesi-Cuma (iş haftası) bazında haftalık zaman çizelgesi oluşturur.
    Her hafta: Min_Tarih = Pazartesi, Max_Tarih = Cuma (5 iş günü).
    """
    log_baslik(
        "Yıl, Hafta, Min_Tarih, Max_Tarih",
        "internal · Pzt-Cum haftalık zaman çizelgesi (harici kaynak yok)",
    )

    # --- 1. Kanonik Zaman Çizelgesi Oluştur ---
    canonical_rows = []
    
    if start_date is None:
        from datetime import datetime as _dt
        start_date = _dt(2024, 9, 16)   # İlk Pazartesi

    # Başlangıcın Pazartesi olduğunu doğrula
    if start_date.weekday() != 0:
        raise ValueError(
            f"start_date ({start_date:%d.%m.%Y}) Pazartesi değil! "
            f"Pazartesi-Cuma yapısı için başlangıç Pazartesi olmalı."
        )

    curr_min = start_date                          # Pazartesi
    curr_max = start_date + timedelta(days=4)      # Cuma (+4 gün)
    target_date = datetime.now()
    
    # Başlangıç değerleri
    curr_year = start_date.year
    week_num = 1
    
    full_columns = [
        'Yıl', 'Hafta', 'Min_Tarih', 'Max_Tarih',
        'TLREF', 'AOFM', 'PP_Getiri',
        'TCMB_Mevduat_1M', 'TCMB_Mevduat_1M_Onceki_Hafta',
        'TCMB_Mevduat_3M', 'TCMB_Mevduat_3M_Onceki_Hafta',
        'Benchmark', 'Benchmark_All',
        'BIST100', 'Ticari_Kredi',
        'Sepet_Kur', 'Full_Workday',
    ]
    
    while curr_min <= target_date:
        # Yıl geçişi: hafta başlangıcının takvim yılı değiştiğinde sıfırla
        if curr_min.year != curr_year:
            curr_year = curr_min.year
            week_num = 1

        row_data = {col: None for col in full_columns}
        row_data.update({
            "Yıl": curr_year,
            "Hafta": f"Hafta {week_num}",
            "Min_Tarih": curr_min.strftime("%d/%m/%Y"),
            "Max_Tarih": curr_max.strftime("%d/%m/%Y")
        })
        canonical_rows.append(row_data)
        
        week_num += 1
        curr_min = curr_max + timedelta(days=3)     # Cuma + 3 = sonraki Pazartesi
        curr_max = curr_min + timedelta(days=4)     # Pazartesi + 4 = Cuma
        
    df_canonical = pd.DataFrame(canonical_rows)
    ilk = df_canonical.iloc[0]
    son = df_canonical.iloc[-1]
    print(f"Haftalık zaman çizelgesi oluşturuldu: {len(df_canonical)} hafta (Pzt-Cum).")
    print(f"  İlk hafta : {ilk['Min_Tarih']} – {ilk['Max_Tarih']}")
    print(f"  Son hafta : {son['Min_Tarih']} – {son['Max_Tarih']}")

    # --- 2. Mevcut Dosyayı Oku ---
    df_existing = read_firast()
    if df_existing is None:
        print("Mevcut FIRAST.xlsx bulunamadı. Sıfırdan başlanıyor.")
        df_existing = pd.DataFrame()
    else:
        print(f"Mevcut FIRAST.xlsx okundu: {len(df_existing)} satır.")

    # Tanımlı tüm kolonların varlığını garantile
    for col in full_columns:
        if col not in df_existing.columns:
            df_existing[col] = None

    # --- 3. Yerinde Onarım ve Güncelleme ---
    # df_canonical sırası esas alınır (Satır 0 = Hafta 1, vb.)
    # Bu yapı df_existing üzerine empoze edilir.
    
    updated_count = 0
    
    # Kanonik zaman çizelgesini dolaş
    for i, expected_row in df_canonical.iterrows():
        # Bu satır indeksinin dosyada var olup olmadığını kontrol et
        if i < len(df_existing):
            # Satır mevcut. A-D kolonlarının kanonik ile eşleştiğinden emin ol..
            
            # Fark varsa logla
            needs_update = False
            for col in ["Yıl", "Hafta", "Min_Tarih", "Max_Tarih"]:
                current_val = df_existing.at[i, col]
                expected_val = expected_row[col]
                
                # NaN veya uyumsuzluk kontrolü
                if pd.isna(current_val) or str(current_val) != str(expected_val):
                    needs_update = True
            
            if needs_update:
                # Tanımlayıcı kolonları zorunlu güncelle
                df_existing.at[i, "Yıl"] = expected_row["Yıl"]
                df_existing.at[i, "Hafta"] = expected_row["Hafta"]
                df_existing.at[i, "Min_Tarih"] = expected_row["Min_Tarih"]
                df_existing.at[i, "Max_Tarih"] = expected_row["Max_Tarih"]
                updated_count += 1
        else:
            # Satır yok — sonuna ekle
            
            remaining_canonical = df_canonical.iloc[i:]
            df_existing = pd.concat([df_existing, remaining_canonical], ignore_index=True)
            print(f"{len(remaining_canonical)} yeni hafta eklendi.")
            break  # Kalan satırlar concat ile işlendi
            
    # --- 4. Doğrula ve Kaydet ---
    
    # Tekrar eden satırları kaldır
    if not df_existing.empty and 'Min_Tarih' in df_existing.columns:
        df_existing.drop_duplicates(subset=['Min_Tarih'], keep='first', inplace=True)

    # Kolon sıralamasını uygula
    current_cols = df_existing.columns.tolist()
    ordered_cols = [c for c in full_columns if c in current_cols] + [c for c in current_cols if c not in full_columns]
    df_existing = df_existing[ordered_cols]

    if updated_count > 0:
        print(f"  {updated_count} mevcut satırın tarihleri Pzt-Cum yapısına güncellendi.")

    save_firast(df_existing)
    print("Hafta oluşturma tamamlandı.")

if __name__ == "__main__":
    generate_weeks()
