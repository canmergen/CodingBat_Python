"""
add_details_sheet.py
--------------------
FIRAST.xlsx ve FIRAST_MODEL.xlsx'e 'Details' sayfası ekler.

FIRAST.xlsx Details (5 sütun):
  Feature, Anlam, Kaynak, Ne zaman üretiliyor, Nerede üretildi

FIRAST_MODEL.xlsx Details (7 sütun — FIRAST + 2 ek):
  + NaN Stratejisi (fill nasıl yapıldı)
  + Kalan NaN Sayısı (fill sonrası NaN — son hafta hariç)
"""

import os

import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment

from src.utils import log_baslik, read_firast


# ─────────────────────────────────────────────────────────────────────
# Kolon başına meta-bilgi katalogu
# Her entry: (Anlam, Kaynak, Ne_Zaman_Uretiliyor)
# ─────────────────────────────────────────────────────────────────────
META: dict[str, tuple[str, str, str]] = {
    # ═══ Zaman indeksi (deterministik) ═══
    "Yıl":        ("Haftanın takvim yılı (2024/2025/2026)", "pipeline (week_generator)", "Deterministik · her zaman"),
    "Hafta":      ("Yıl içinde haftanın sırası (string: 'Hafta N')", "pipeline (week_generator)", "Deterministik · her zaman"),
    "Min_Tarih":  ("Haftanın başlangıç günü (Pazartesi, dd.mm.yyyy)", "pipeline (week_generator)", "Deterministik · her zaman"),
    "Max_Tarih":  ("Haftanın bitiş günü (Cuma, dd.mm.yyyy)", "pipeline (week_generator)", "Deterministik · her zaman"),

    # ═══ TR faiz/fonlama fixing'leri ═══
    "TLREF":  ("Türk Lirası Referans Faizi — Borsa İstanbul günlük fixing'lerin haftalık ortalaması", "https://evds3.tcmb.gov.tr · TP.BISTTLREF.ORAN", "Pzt 14:30 TR (günlük fixing) · haftalık Cuma tam"),
    "AOFM":   ("TCMB Ağırlıklı Ortalama Fonlama Maliyeti — haftalık ortalama", "https://evds3.tcmb.gov.tr · TP.APIFON4", "EVDS T+1 · Salı sabah cari Pzt verisi"),
    "TCMB_Net_Fonlama_TL": ("TCMB günlük net fon miktarı (Milyon TL) — pozitif gevşek, negatif sıkı likidite", "https://evds3.tcmb.gov.tr · TP.APIFON3", "EVDS T+1 · Salı sabah"),

    # ═══ TCMB mevduat faizleri (haftalık EVDS yayını) ═══
    "TCMB_Mevduat_1M":     ("Bankalarca 1 aya kadar TL mevduata uygulanan ağırlıklı ortalama faiz — Cuma kapanış (SEED)", "https://evds3.tcmb.gov.tr · TP.TRY.MT01 + SEED (Ekim 2024 – Ağustos 2025 Cuma spot)", "EVDS haftalık · Cuma akşamı yayın"),
    "TCMB_Mevduat_3M":     ("Bankalarca 3 aya kadar TL mevduata uygulanan ağırlıklı ortalama faiz — Cuma kapanış (SEED)", "https://evds3.tcmb.gov.tr · TP.TRY.MT02 + SEED", "EVDS haftalık · Cuma akşamı yayın"),
    "TCMB_Mevduat_1M_Onceki_Hafta": ("TCMB_Mevduat_1M'in +1 shift'lenmiş hali — geçen haftanın Cuma değeri (Pzt sabah bilinen leakage-free feature)", "shift(1) + EVDS backfill (23-27.09.2024)", "Pzt sabah · nowcast için hazır"),
    "TCMB_Mevduat_3M_Onceki_Hafta": ("TCMB_Mevduat_3M'in +1 shift'lenmiş hali", "shift(1) + EVDS backfill", "Pzt sabah · nowcast için hazır"),

    # ═══ TL kredi faizleri (EVDS haftalık) ═══
    "Ticari_Kredi":        ("Ticari kredi (TL, akım) ağırlıklı ortalama faiz oranı", "https://evds3.tcmb.gov.tr · TP_KTF17 (Playwright portlet)", "EVDS haftalık · Cuma akşamı yayın"),
    "Ihtiyac_Kredi_Faizi": ("İhtiyaç kredisi faiz oranı (TL, akım)", "https://evds3.tcmb.gov.tr · TP.KTF10", "EVDS haftalık · Cuma akşamı yayın"),

    # ═══ Borsa & endeksler ═══
    "BIST100":   ("Borsa İstanbul 100 Endeksi haftalık ortalaması (EVDS)", "https://evds3.tcmb.gov.tr · TP.MK.F.BILESIK", "TR borsa · Pzt 18:00 close (haftalık Cuma tam)"),
    "XBANK":     ("BIST Banka Endeksi haftalık ortalaması (yfinance)", "https://finance.yahoo.com · yfinance XBANK.IS", "TR borsa · Pzt 18:00 close"),
    "VIX":       ("CBOE Volatility Index — US piyasa korku endeksi haftalık ortalaması", "https://finance.yahoo.com · yfinance ^VIX", "US market · Pzt 23:00 TR close"),

    # ═══ Para piyasası ═══
    "PP_Getiri": ("TEFAS Para Piyasası fonlarının haftalık net getirisi ortalaması (fallback: AOFM/365×iş_günü)", "https://www.tefas.gov.tr/FonKarsilastirma.aspx + AOFM fallback", "TEFAS T+1 · Salı sabah"),

    # ═══ Banka rekabet ortamı ═══
    "Benchmark":     ("hesapkurdu 1-gün 100K TL mevduat hedef bankalar (TEB+Deniz+Fiba+Akbank) haftalık ortalama", "https://www.hesapkurdu.com/mevduat-teklifleri/1-gun-100000-tl + https://www.hangikredi.com/yatirim-araclari/mevduat-faiz-oranlari + seed_benchmark 2025-2026", "Pzt sabah canlı"),
    "Benchmark_All": ("Tüm bankaların haftalık ortalama mevduat faizi (arşiv başlangıcı 2026 Şub — sparse)", "https://www.hesapkurdu.com/mevduat-teklifleri/1-gun-100000-tl (tüm bankalar)", "Pzt sabah canlı"),

    # ═══ Döviz & emtia (yfinance) ═══
    "USD_TRY":        ("USD/TRY haftalık ortalama spot kur", "https://finance.yahoo.com · yfinance USDTRY=X", "24/7 FX · Pzt 02:00 TR'den itibaren"),
    "EUR_USD":        ("EUR/USD haftalık ortalama spot kur", "https://finance.yahoo.com · yfinance EURUSD=X", "24/7 FX · Pzt 02:00 TR'den itibaren"),
    "EUR_TRY":        ("EUR/TRY haftalık ortalama spot kur", "https://finance.yahoo.com · yfinance EURTRY=X", "24/7 FX · Pzt 02:00 TR'den itibaren"),
    "DXY":            ("Dollar Index (ABD Doları sepet endeksi)", "https://finance.yahoo.com · yfinance DX-Y.NYB", "24/5 · Pzt 01:00 TR'den itibaren"),
    "Sepet_Kur":      ("TCMB resmi sepet kuru: 0.5×USD ForexBuying + 0.5×EUR ForexBuying", "https://www.tcmb.gov.tr/kurlar/YYYYMM/DDMMYYYY.xml (günlük XML)", "Pzt 15:30 TR · günlük bülten"),
    "Altin_USD":      ("Altın vadeli (USD/troy ons) haftalık ortalama", "https://finance.yahoo.com · yfinance GC=F", "24/5 commodity · Pzt 01:00 TR"),
    "Gumus":          ("Gümüş vadeli (USD/troy ons)", "https://finance.yahoo.com · yfinance SI=F", "24/5 · Pzt 01:00 TR"),
    "Bakir":          ("Bakır vadeli (USD/pound)", "https://finance.yahoo.com · yfinance HG=F", "24/5 · Pzt 01:00 TR"),
    "Brent":          ("Brent ham petrol vadeli (USD/varil)", "https://finance.yahoo.com · yfinance BZ=F", "Pzt 12:00 TR'den itibaren"),
    "Gram_Altin_TRY": ("Gram altın TRY karşılığı = Altin_USD × USD_TRY / 31.1035", "pipeline türetme (yfinance kaynaklı)", "24/5 FX + altın anlık"),

    # ═══ Volatilite (5 günlük rolling) ═══
    "Kur_Vol":  ("USD/TRY 5 günlük getiri standart sapması — haftalık kur volatilitesi", "https://finance.yahoo.com · yfinance USDTRY=X · rolling(5).std()", "Haftalık (5 gün veri birikince)"),
    "BIST_Vol": ("BIST100 5 günlük getiri standart sapması — haftalık borsa volatilitesi", "https://finance.yahoo.com · yfinance XU100.IS · rolling(5).std()", "Haftalık (5 gün veri birikince)"),

    # ═══ Makro (EVDS aylık) ═══
    "KKO":               ("İmalat Sanayi Kapasite Kullanım Oranı (%)", "https://evds3.tcmb.gov.tr · TP.KKO2.IS.TOP", "Aylık · ayın 25'i civarı TCMB yayını"),
    "Tuketici_Guven":    ("Tüketici Güven Endeksi (TÜİK)", "https://evds3.tcmb.gov.tr · TP.TG2.Y01", "Aylık · ay sonu yayını"),
    "Sanayi_Uretim":     ("Sanayi Üretim Endeksi (2021=100, Mevsim+Takvim arındırılmış)", "https://evds3.tcmb.gov.tr · TP.TSANAYMT2021.Y1", "Aylık · ay sonu yayını"),
    "Cekirdek_Enflasyon": ("Çekirdek Enflasyon B Endeksi — aylık % değişim (EVDS ham endeksten hesap)", "https://evds3.tcmb.gov.tr · TP.FE.OKTG02 + pct_change", "Aylık · TÜFE yayın günü"),
    "Enflasyon_Beklenti_12ay": ("TCMB Beklenti Anketi: 12 ay sonrası enflasyon beklentisi (%)", "https://evds3.tcmb.gov.tr · TP.PKAUO.S01.E.U (API key)", "Aylık · TCMB Beklenti Anketi yayın günü"),
    "GSYH_Buyume_Beklenti":    ("TCMB Beklenti Anketi: GSYH büyüme beklentisi (cari yıl, %)", "https://evds3.tcmb.gov.tr · TP.PKAUO.S07.A.U (API key)", "Aylık"),
    "Issizlik":          ("TÜİK İşsizlik Oranı (%)", "https://evds3.tcmb.gov.tr · TP.YISGUCU2.G8 (API key)", "Aylık"),

    # ═══ Finansal Hizmetler Güven Endeksi ═══
    "Fin_Guven":     ("Finansal Hizmetler Güven Endeksi — manşet", "https://evds3.tcmb.gov.tr · TP.FHGE.S01", "Aylık · TCMB yayını"),
    **{f"Fin_Guven_S{i:02d}": (f"FHGE alt endeks S{i:02d} (TCMB Finansal Hizmetler Anketi anket bileşeni)", f"https://evds3.tcmb.gov.tr · TP.FHGE.S{i:02d}", "Aylık") for i in range(2, 17)},

    # ═══ Enflasyon (ENAG + TÜİK) ═══
    "WebTufe_TUFE_Aylik":  ("ENAG E-TÜFE aylık % değişim (manşet enflasyon)", "https://www.apiwebtufe.com/api/v1/tufe", "Aylık · ay başı yayını"),
    "WebTufe_TUFE_Yillik": ("ENAG E-TÜFE yıllık % değişim", "https://www.apiwebtufe.com/api/v1/tufe", "Aylık · ay başı yayını"),
    "TUIK_TUFE_Aylik":     ("TÜİK TÜFE aylık % değişim (resmi)", "https://www.apiwebtufe.com/api/v1/tufe (TÜİK mirror)", "Aylık · ayın 3. iş günü TÜİK yayını"),
    "TUIK_TUFE_Yillik":    ("TÜİK TÜFE yıllık % değişim (resmi)", "https://www.apiwebtufe.com/api/v1/tufe", "Aylık · ayın 3. iş günü"),

    # ═══ ENAG ana grup endeksleri (günlük) ═══
    "WebTufe_Gida_Endeks":        ("Gıda ve alkolsüz içecekler endeksi (günlük)", "https://www.apiwebtufe.com/api/v1/download/gruplar/index/csv", "Günlük · Pzt sabah güncel"),
    "WebTufe_Enerji_Endeks":      ("Konut/su/elektrik/gaz/diğer yakıtlar endeksi", "https://www.apiwebtufe.com/api/v1/download/gruplar/index/csv", "Günlük · Pzt sabah güncel"),
    "WebTufe_Ulastirma_Endeks":   ("Ulaştırma endeksi", "https://www.apiwebtufe.com/api/v1/download/gruplar/index/csv", "Günlük · Pzt sabah güncel"),
    "WebTufe_Hizmet_Endeks":      ("Lokanta ve konaklama hizmetleri endeksi", "https://www.apiwebtufe.com/api/v1/download/gruplar/index/csv", "Günlük · Pzt sabah güncel"),
    "WebTufe_Giyim_Endeks":       ("Giyim ve ayakkabı endeksi", "https://www.apiwebtufe.com/api/v1/download/gruplar/index/csv", "Günlük · Pzt sabah güncel"),
    "WebTufe_Endeks":             ("Web TÜFE (genel manşet endeksi)", "https://www.apiwebtufe.com/api/v1/download/gruplar/index/csv", "Günlük · Pzt sabah güncel"),
    "WebTufe_KisiselBakim_Endeks":("Kişisel bakım, sosyal koruma, çeşitli mal ve hizmetler endeksi", "https://www.apiwebtufe.com/api/v1/download/gruplar/index/csv", "Günlük · Pzt sabah güncel"),
    "WebTufe_Aclik_Siniri":       ("Günlük açlık sınırı (TL) — 4 kişilik aile temel gıda maliyeti", "https://www.apiwebtufe.com/api/v1/aclik-siniri", "Günlük · Pzt sabah güncel"),

    # ═══ BKM sektörel kart harcamaları (aylık) ═══
    "BKM_Giyim_TL":           ("BKM Grup 11 — Giyim ve Aksesuar aylık toplam kart harcaması (Milyon TL)", "https://bkm.com.tr/secilen-sektore-gore-aylik-gelisim?filter_group=11", "Aylık · sonraki ayın ortası"),
    "BKM_Yemek_TL":           ("BKM Grup 10 — Yemek/Restoran aylık toplam kart harcaması (Milyon TL)", "https://bkm.com.tr/secilen-sektore-gore-aylik-gelisim?filter_group=10", "Aylık · sonraki ayın ortası"),
    "BKM_Saglik_Kozmetik_TL": ("BKM Grup 9 — Sağlık/Ecza/Kozmetik aylık toplam kart harcaması (Milyon TL)", "https://bkm.com.tr/secilen-sektore-gore-aylik-gelisim?filter_group=9", "Aylık · sonraki ayın ortası"),

    # ═══ Sosyal sinyal ═══
    "USDT_TRY_Hacim":    ("Tether'ın TRY cinsinden 24 saatlik küresel işlem hacmi (CoinGecko)", "https://api.coingecko.com/api/v3/coins/tether/market_chart", "7/24 · Pzt sabah güncel (365 gün limit)"),
    "GT_Mevduat_Faizi":  ("'mevduat faizi' Google Trends haftalık arama endeksi (0-100)", "https://trends.google.com · pytrends · TR geo", "7/24 · Pzt sabah güncel"),
    "GT_En_Yuksek":      ("'en yüksek faiz' Google Trends haftalık arama endeksi", "https://trends.google.com · pytrends · TR geo", "7/24 · Pzt sabah güncel"),

    # ═══ Kredi risk primi ═══
    "CDS_5Y": ("Türkiye 5 yıllık CDS primi (baz puan) — ülke risk göstergesi", "https://www.worldgovernmentbonds.com/cds/turkey + https://tr.investing.com/rates-bonds/turkey-cds-5-year-usd-historical-data fallback (Playwright)", "Pzt gün sonu · 18:00+ TR"),

    # ═══ İş günü sayacı ═══
    "Full_Workday": ("Hafta tam 5 iş günü mü (1=tatil yok, 0=en az 1 tatil)", "holidays.Turkey kütüphanesi", "Deterministik · her zaman"),

    # ═══ Takvim & mevsimsellik bayrakları (0/1) ═══
    "Payday":                   ("Haftada ay başı (1), ortası (15) veya ay son günü var mı", "pipeline türetme", "Deterministik · her zaman"),
    "Emekli_Maas_Donemi":       ("Haftada ayın 17-25 arası gün var mı (SGK emekli maaş dağıtımı)", "pipeline türetme", "Deterministik · her zaman"),
    "Tax_Season":               ("Hafta vergi ayında mı ({3,4,5,7,11}): Gelir/Kurumlar/Emlak/MTV ödeme ayları", "pipeline türetme", "Deterministik · her zaman"),
    "Ay_Sonu_Haftasi":          ("Haftada ayın son 5 günü var mı (bilanço kapama + şirket ödemeleri)", "pipeline türetme", "Deterministik · her zaman"),
    "Bayram_Haftasi":           ("Haftada dini bayram günü var mı (Ramazan/Kurban)", "holidays.Turkey + BAYRAM_KEYWORDS", "Deterministik · her zaman"),
    "Bayram_Arefesi":           ("Haftada dini bayram arefesi var mı (bayramdan -5 gün)", "holidays.Turkey türetme", "Deterministik · her zaman"),
    "Bayram_Sonrasi":           ("Haftada dini bayram sonrası var mı (bayramdan +7 gün)", "holidays.Turkey türetme", "Deterministik · her zaman"),
    "Milli_Bayram_Haftasi":     ("Haftada milli tatil var mı (23 Nisan, 29 Ekim, 1 Mayıs, 19 Mayıs, 15 Temmuz, 30 Ağustos, yılbaşı)", "holidays.Turkey - BAYRAM_KEYWORDS", "Deterministik · her zaman"),
    "Season":                   ("Mevsim (1=Kış, 2=İlkbahar, 3=Yaz, 4=Sonbahar) — Month'tan türetme", "pipeline türetme", "Deterministik · her zaman"),
    "Month":                    ("Haftanın orta ayı (1-12)", "pipeline türetme", "Deterministik · her zaman"),
    "YearEnd":                  ("Aralık'ın son 2 haftası (bilanço/rapor kapama)", "pipeline türetme", "Deterministik · her zaman"),
    "Okul_Tatili":              ("15 Haz – 15 Eyl arası yaz tatili haftası", "https://meb.gov.tr (sabit pencere, kod içi)", "Deterministik · her zaman"),
    "Somestr_Tatili":           ("Ocak 20 – Şubat 3 arası MEB yarıyıl tatili (2 hafta)", "https://meb.gov.tr (sabit pencere, kod içi)", "Deterministik · her zaman"),
    "Ara_Tatil":                ("Kasım 10-15 + Nisan 7-15 arası MEB ara tatilleri (2016+)", "https://meb.gov.tr (sabit pencere, kod içi)", "Deterministik · her zaman"),
    "Quarter_End":              ("Mart/Haziran/Eylül/Aralık ayının son 1 haftası (day≥25)", "pipeline türetme", "Deterministik · her zaman"),
    "Ramazan":                  ("Haftada Ramazan ayı günü var mı", "hijridate kütüphanesi (Hicri 9. ay)", "Deterministik · her zaman"),
    "Black_Friday":             ("Kasım 4. Perşembe + sonraki 7 gün (Kara Cuma + Cyber Monday)", "pipeline türetme", "Deterministik · her zaman"),
    "Yaz_Turizm":               ("Mayıs-Ekim (sahil/resort döviz girişi dönemi)", "pipeline türetme", "Deterministik · her zaman"),
    "Kis_Turizm":               ("Aralık-Mart (kayak merkezleri iç turizm harcaması)", "pipeline türetme", "Deterministik · her zaman"),
    "Temetu_Donemi":            ("15 Nisan – 15 Haziran BİST şirket temettü dağıtım dönemi", "pipeline türetme", "Deterministik · her zaman"),
    "PPK_Haftasi":              ("Haftada TCMB PPK toplantısı var mı", "fetch_ppk_dates (TCMB takvim + sabit geçmiş)", "Deterministik · her zaman"),
    "PPK_Oncesi":               ("PPK toplantısından önceki 7 gün penceresi", "fetch_ppk_dates türetme", "Deterministik · her zaman"),
    "PPK_Sonrasi":              ("PPK toplantısından sonraki 7 gün penceresi", "fetch_ppk_dates türetme", "Deterministik · her zaman"),
    "Enflasyon_Aciklama_Haftasi": ("Ayın ilk 7 günü (TÜİK TÜFE 3. iş günü yayın dönemi)", "pipeline türetme", "Deterministik · her zaman"),

    # ═══ Anomali flag'leri (z-score bazlı) ═══
    "Market_Anomaly": ("CDS_5Y + Kur_Vol + VIX z-score ortalaması > 2σ ise 1", "pipeline türetme (FIRAST z-score)", "Derived · kaynak kolonlar dolunca"),
    "Faiz_Anomaly":   ("TLREF/TCMB_Mevduat_1M oranı |z-score| > 1.5σ ise 1", "pipeline türetme", "Derived · TLREF + TCMB_Mevduat_1M dolunca"),
    "Kur_Spike":      ("USD/TRY haftalık % değişim |z-score| > 2σ — ani kur şoku", "pipeline türetme (USD_TRY pct_change)", "Derived · haftalık"),
    "Altin_Rush":     ("Gram_Altin_TRY haftalık % değişim |z-score| > 2σ — altına kaçış", "pipeline türetme (Gram_Altin_TRY pct_change)", "Derived · haftalık"),
    "CDS_Spike":      ("CDS_5Y haftadan haftaya değişim |z-score| > 2σ — ani risk artışı", "pipeline türetme (CDS_5Y diff)", "Derived · CDS geldikten sonra"),
    "Enflasyon_Sok":  ("WebTufe_TUFE_Aylik |z-score| > 2σ — enflasyon şoku", "pipeline türetme", "Derived · aylık TÜFE yayın sonrası"),
    "Likidite_Sikisma": ("AOFM - TLREF spread |z-score| > 2σ — bankalar arası stres", "pipeline türetme (AOFM - TLREF)", "Derived · AOFM + TLREF dolunca"),

    # ═══ Stres / kompozit ═══
    "Market_Stress":  ("BIST_Vol + Kur_Vol + VIX z-score ortalaması (sürekli değer)", "pipeline türetme (z-score avg)", "Derived · 3 vol kolonu dolunca"),

    # ═══ Etkileşim / spread ═══
    "Faiz_Spread":    ("TCMB_Mevduat_1M − TLREF (piyasa-referans faiz farkı)", "pipeline türetme", "Derived · haftalık yayın sonrası"),
    "Reel_Faiz":      ("TLREF/12 − WebTufe_TUFE_Aylik (aylık reel faiz yaklaşımı)", "pipeline türetme", "Derived · aylık TÜFE dolunca"),

    # ═══ Haftalık getiri/değişim ═══
    "BIST100_Getiri":     ("BIST100 haftalık % değişim", "pipeline türetme (pct_change)", "Derived · Pzt close sonrası haftalık"),
    "Altin_Getiri":       ("Gram_Altin_TRY haftalık % değişim", "pipeline türetme (pct_change)", "Derived · haftalık"),
    "Kur_Degisim":        ("USD/TRY haftalık % değişim", "pipeline türetme (pct_change)", "Derived · haftalık"),
    "Sepet_Kur_Degisim":  ("Sepet_Kur haftalık % değişim", "pipeline türetme (pct_change)", "Derived · Pzt 15:30 sonrası"),

    # ═══ Davranışsal proxy (BKM + WebTufe) ═══
    "Reel_Giyim":      ("BKM_Giyim_TL / WebTufe_Giyim_Endeks — reel giyim harcaması (Greenspan proxy)", "pipeline türetme (BKM + ENAG)", "Derived · aylık BKM yayın sonrası"),
    "Lipstick_Ratio":  ("BKM_Saglik_Kozmetik_TL / BKM_Giyim_TL — Lipstick Effect (kozmetik/giyim oranı)", "pipeline türetme (BKM)", "Derived · aylık"),
    "Reel_Yemek":      ("BKM_Yemek_TL / WebTufe_Hizmet_Endeks — reel yemek harcaması (service economy)", "pipeline türetme", "Derived · aylık"),
    "Reel_Kozmetik":   ("BKM_Saglik_Kozmetik_TL / WebTufe_KisiselBakim_Endeks — reel kozmetik harcaması", "pipeline türetme", "Derived · aylık"),

    # ═══ ENAG spread göstergeleri ═══
    "Gida_Spread":              ("WebTufe_Gida_Endeks / WebTufe_Endeks — gıda enflasyonu genel TÜFE'yi aşma oranı", "pipeline türetme", "Derived · günlük"),
    "Enerji_Spread":            ("WebTufe_Enerji_Endeks / WebTufe_Endeks — enerji spread", "pipeline türetme", "Derived · günlük"),
    "Hizmet_vs_Gida":           ("WebTufe_Hizmet_Endeks / WebTufe_Gida_Endeks — ücret-fiyat sarmalı sinyali", "pipeline türetme", "Derived · günlük"),
    "Zorunlu_Harcama_Baskisi":  ("(Gıda + Enerji) / (2×Genel) — zorunlu kalemlerin genel TÜFE'ye oranı", "pipeline türetme", "Derived · günlük"),
}


# ─────────────────────────────────────────────────────────────────────
# FIRAST_MODEL için NaN fill stratejileri
# ─────────────────────────────────────────────────────────────────────
NAN_STRATEGY: dict[str, str] = {
    # Zaman indeksi
    "Yıl": "Deterministik — NaN olmaz",
    "Hafta": "Deterministik — NaN olmaz",
    "Min_Tarih": "Deterministik — NaN olmaz",
    "Max_Tarih": "Deterministik — NaN olmaz",
    # Cross-feature spread / ratio
    "Benchmark": "TLREF + rolling 8-hafta median spread",
    "Benchmark_All": "Benchmark × median oran (tüm boş haftalar)",
    "WebTufe_TUFE_Aylik": "TUIK_TUFE_Aylik × median oran + ffill/bfill fallback",
    "Cekirdek_Enflasyon": "WebTufe_TUFE_Aylik × median oran + ffill/bfill fallback",
    # Back-extrapolation
    "WebTufe_Endeks": "TUIK_TUFE_Aylik cumprod geri (ilk 13 hafta)",
    # Seasonal delta
    "Issizlik": "last + (aynı_ay_yıl−1 − aynı_ay_yıl−2) seasonal Δ + ffill fallback",
    # Enflasyon-adjusted growth
    "BKM_Giyim_TL":           "İleri + geri enflasyon-adjusted: last × (WebTufe_Endeks_t / WebTufe_Endeks_last)",
    "BKM_Yemek_TL":           "İleri + geri enflasyon-adjusted: last × (WebTufe_Endeks_t / WebTufe_Endeks_last)",
    "BKM_Saglik_Kozmetik_TL": "İleri + geri enflasyon-adjusted: last × (WebTufe_Endeks_t / WebTufe_Endeks_last)",
    # FFILL — aylık seriler (ay içi sabit)
    "KKO": "ffill (aylık yayın, ay içi sabit)",
    "Tuketici_Guven": "ffill (aylık yayın, ay içi sabit)",
    "Sanayi_Uretim": "ffill (aylık yayın, ay içi sabit)",
    "Enflasyon_Beklenti_12ay": "ffill (aylık yayın)",
    "GSYH_Buyume_Beklenti": "ffill (aylık yayın)",
    "Fin_Guven": "ffill (aylık yayın)",
    **{f"Fin_Guven_S{i:02d}": "ffill (aylık yayın)" for i in range(2, 17)},
    "TUIK_TUFE_Aylik": "ffill + bfill (ilk haftalar geç başladı, yavaş değişen seri)",
    "TUIK_TUFE_Yillik": "ffill (aylık yayın) — ilk 65 hafta NaN bırakıldı",
    # FFILL — izole piyasa boşlukları
    "CDS_5Y": "ffill + bfill (izole scrape boşlukları + ilk haftalar)",
    "Kur_Vol": "ffill (5-gün rolling tatil eksiği)",
    "BIST_Vol": "ffill (5-gün rolling tatil eksiği)",
    # FFILL — haftalık EVDS geç yayın
    "Ihtiyac_Kredi_Faizi": "ffill (haftalık geç yayın)",
    "Ticari_Kredi": "ffill (haftalık geç yayın)",
    "TCMB_Mevduat_1M": "ffill (Cuma akşam yayını geç gelirse)",
    "TCMB_Mevduat_3M": "ffill (Cuma akşam yayını geç gelirse)",
    "TCMB_Mevduat_1M_Onceki_Hafta": "ffill (shift kaynağı)",
    "TCMB_Mevduat_3M_Onceki_Hafta": "ffill (shift kaynağı)",
    # NaN bırak (genuine warmup — donor yok)
    "USDT_TRY_Hacim": "NaN bırak (CoinGecko 365-gün limiti, ilk 29 hafta warmup)",
    "WebTufe_TUFE_Yillik": "NaN bırak (ENAG yıllık geç başladı, ilk 65 hafta)",
    "WebTufe_Aclik_Siniri":       "WebTufe_Gida_Endeks × median oran + ffill/bfill fallback",
    "WebTufe_Gida_Endeks":        "WebTufe_Endeks × median(Gida/Genel) + ffill/bfill fallback",
    "WebTufe_Enerji_Endeks":      "WebTufe_Endeks × median(Enerji/Genel) + ffill/bfill fallback",
    "WebTufe_Ulastirma_Endeks":   "WebTufe_Endeks × median(Ulastirma/Genel) + ffill/bfill fallback",
    "WebTufe_Hizmet_Endeks":      "WebTufe_Endeks × median(Hizmet/Genel) + ffill/bfill fallback",
    "WebTufe_Giyim_Endeks":       "WebTufe_Endeks × median(Giyim/Genel) + ffill/bfill fallback",
    "WebTufe_KisiselBakim_Endeks":"WebTufe_Endeks × median(KisiselBakim/Genel) + ffill/bfill fallback",
    # Recompute — ham kolonlar fill sonrası
    "Faiz_Spread":       "Recompute: TCMB_Mevduat_1M − TLREF",
    "Reel_Faiz":         "Recompute: TLREF/12 − WebTufe_TUFE_Aylik",
    "BIST100_Getiri":    "Recompute: BIST100 pct_change × 100 (ilk hafta NaN kalır — warmup)",
    "Altin_Getiri":      "Recompute: Gram_Altin_TRY pct_change × 100 (ilk hafta NaN)",
    "Kur_Degisim":       "Recompute: USD_TRY pct_change × 100 (ilk hafta NaN)",
    "Sepet_Kur_Degisim": "Recompute: Sepet_Kur pct_change × 100 (ilk hafta NaN)",
    "Reel_Giyim":        "Recompute: BKM_Giyim_TL / WebTufe_Giyim_Endeks",
    "Lipstick_Ratio":    "Recompute: BKM_Saglik_Kozmetik_TL / BKM_Giyim_TL",
    "Reel_Yemek":        "Recompute: BKM_Yemek_TL / WebTufe_Hizmet_Endeks",
    "Reel_Kozmetik":     "Recompute: BKM_Saglik_Kozmetik_TL / WebTufe_KisiselBakim_Endeks",
    "Gida_Spread":       "Recompute: WebTufe_Gida / WebTufe_Endeks",
    "Enerji_Spread":     "Recompute: WebTufe_Enerji / WebTufe_Endeks",
    "Hizmet_vs_Gida":    "Recompute: WebTufe_Hizmet / WebTufe_Gida",
    "Zorunlu_Harcama_Baskisi": "Recompute: (Gıda+Enerji) / (2×Genel)",
    # z-score flag'leri — ham kolon dolunca derive_firast_features tekrar hesaplar
    "Market_Stress":    "Recompute: BIST/Kur_Vol + VIX z-score ortalaması",
    "Market_Anomaly":   "Recompute: CDS+Kur_Vol+VIX z-score ortalaması > 2σ",
    "Faiz_Anomaly":     "Recompute: TLREF/TCMB_1M oranı |z| > 1.5σ",
    "Kur_Spike":        "Recompute: USD_TRY haftalık % |z| > 2σ",
    "Altin_Rush":       "Recompute: Gram_Altin_TRY haftalık % |z| > 2σ",
    "CDS_Spike":        "Recompute: CDS_5Y diff |z| > 2σ",
    "Enflasyon_Sok":    "Recompute: WebTufe_TUFE_Aylik |z| > 2σ",
    "Likidite_Sikisma": "Recompute: AOFM − TLREF spread |z| > 2σ",
    # Fill gerekmez — pipeline zaten dolu çekiyor
    "TLREF": "Fill gerekmez (EVDS haftalık fixing, tam)",
    "AOFM": "Fill gerekmez (EVDS günlük → haftalık ort)",
    "TCMB_Net_Fonlama_TL": "Fill gerekmez (EVDS günlük)",
    "PP_Getiri": "Fill gerekmez (TEFAS + AOFM fallback)",
    "BIST100": "Fill gerekmez (EVDS haftalık)",
    "XBANK": "Fill gerekmez (yfinance)",
    "VIX": "Fill gerekmez (yfinance)",
    "USD_TRY": "Fill gerekmez (yfinance 24/7)",
    "EUR_USD": "Fill gerekmez (yfinance 24/7)",
    "EUR_TRY": "Fill gerekmez (yfinance 24/7)",
    "DXY": "Fill gerekmez (yfinance)",
    "Sepet_Kur": "Fill gerekmez (TCMB XML günlük)",
    "Altin_USD": "Fill gerekmez (yfinance)",
    "Gumus": "Fill gerekmez (yfinance)",
    "Bakir": "Fill gerekmez (yfinance)",
    "Brent": "Fill gerekmez (yfinance)",
    "Gram_Altin_TRY": "Fill gerekmez (Altin_USD × USD_TRY türetme)",
    "GT_Mevduat_Faizi": "Fill gerekmez (pytrends haftalık)",
    "GT_En_Yuksek": "Fill gerekmez (pytrends haftalık)",
    "Full_Workday": "Fill gerekmez (deterministik)",
    # Deterministik takvim flag'leri (0/1)
    "Payday": "Deterministik 0/1 (NaN olmaz)",
    "Emekli_Maas_Donemi": "Deterministik 0/1",
    "Tax_Season": "Deterministik 0/1",
    "Ay_Sonu_Haftasi": "Deterministik 0/1",
    "Bayram_Haftasi": "Deterministik 0/1",
    "Bayram_Arefesi": "Deterministik 0/1",
    "Bayram_Sonrasi": "Deterministik 0/1",
    "Milli_Bayram_Haftasi": "Deterministik 0/1",
    "Season": "Deterministik (1-4)",
    "Month": "Deterministik (1-12)",
    "YearEnd": "Deterministik 0/1",
    "Okul_Tatili": "Deterministik 0/1",
    "Somestr_Tatili": "Deterministik 0/1",
    "Ara_Tatil": "Deterministik 0/1",
    "Quarter_End": "Deterministik 0/1",
    "Ramazan": "Deterministik 0/1",
    "Black_Friday": "Deterministik 0/1",
    "Yaz_Turizm": "Deterministik 0/1",
    "Kis_Turizm": "Deterministik 0/1",
    "Temetu_Donemi": "Deterministik 0/1",
    "PPK_Haftasi": "Deterministik 0/1",
    "PPK_Oncesi": "Deterministik 0/1",
    "PPK_Sonrasi": "Deterministik 0/1",
    "Enflasyon_Aciklama_Haftasi": "Deterministik 0/1",
}


# ─────────────────────────────────────────────────────────────────────
# Fill stratejisinin ekonomik/istatistiksel mantığı — "neden bu yöntem"
# ─────────────────────────────────────────────────────────────────────
NAN_STRATEGY_REASON: dict[str, str] = {
    # Zaman indeksi
    "Yıl": "Takvimden deterministik üretilir — NaN olasılığı yok.",
    "Hafta": "Takvimden deterministik üretilir — NaN olasılığı yok.",
    "Min_Tarih": "week_generator çıktısı, kesin değer.",
    "Max_Tarih": "week_generator çıktısı, kesin değer.",
    # Cross-feature spread / ratio
    "Benchmark": "Benchmark–TLREF spread'i rejim bazlı değişir; rolling 8 hafta son dönem bankacılık rekabetini yansıtır, statik median geçmiş ortamı yansıtırdı.",
    "Benchmark_All": "Tüm bankaların Benchmark'a oranı (kamu bankaları dahil) tarihsel olarak stabil → oran × Benchmark güvenli proxy.",
    "WebTufe_TUFE_Aylik": "ENAG ve TÜİK aynı olgunun iki ölçümü; oran tarihsel median ile sabitlenir, donor da NaN ise bfill son çare.",
    "Cekirdek_Enflasyon": "Çekirdek ≈ manşet'in {0.85–1.05}× çarpanı; oran ile tutturulur, donor yoksa komşu gözleme dayan.",
    # Back-extrapolation
    "WebTufe_Endeks": "Fiyat endeksi kümülatif; bilinen son değerden TÜİK aylık değişimle geriye hesap tutarlı.",
    # Seasonal delta
    "Issizlik": "İşsizlik güçlü mevsimsel (yaz düşük, kış yüksek); yıldan yıla aynı ay farkı statik ffill'den daha gerçekçi.",
    # Enflasyon-adjusted growth
    "BKM_Giyim_TL":           "Kart harcaması nominal → TÜFE endeksiyle ölçeklenerek reel büyüme korunur; ilk haftalar için ters formülle geri çekilir.",
    "BKM_Yemek_TL":           "Nominal kart harcaması; enflasyon büyümesiyle ileri+geri projeksiyon.",
    "BKM_Saglik_Kozmetik_TL": "Nominal kart harcaması; enflasyon büyümesiyle ileri+geri projeksiyon.",
    # FFILL (aylık, ay içi sabit)
    "KKO":                     "Aylık yayın, ay içinde değer değişmez — ffill doğal davranış.",
    "Tuketici_Guven":          "Aylık yayın, ay içinde sabit — ffill yayın tarihinden bir sonrakine kadar geçerli.",
    "Sanayi_Uretim":           "Aylık yayın, ay içinde sabit.",
    "Enflasyon_Beklenti_12ay": "Aylık Beklenti Anketi, ay içinde sabit.",
    "GSYH_Buyume_Beklenti":    "Aylık Beklenti Anketi, ay içinde sabit.",
    "Fin_Guven":               "Aylık FHGE yayını, ay içinde sabit.",
    **{f"Fin_Guven_S{i:02d}": "Aylık FHGE alt endeks, ay içinde sabit." for i in range(2, 17)},
    # FFILL+BFILL
    "TUIK_TUFE_Aylik":  "TÜFE aylık yavaş değişir; seri geç başladıysa ilk bilinen gözlem ±1-2 ay geriye yansıtılabilir (bfill güvenli).",
    "TUIK_TUFE_Yillik": "Yıllık bileşik değer 15+ ay geriye bfill edilirse çarpık olur — erken hafta NaN bırakıldı.",
    "CDS_5Y":           "Ülke risk primi yavaş değişir; izole scrape hatası ve ilk haftalar için ffill/bfill makul.",
    "Kur_Vol":          "5-gün rolling std; tatil haftası kaynaklı tek hafta eksiği ffill ile geçer.",
    "BIST_Vol":         "5-gün rolling std; tek hafta eksiği ffill.",
    "Ihtiyac_Kredi_Faizi": "Haftalık EVDS yayını Cuma geç gelirse son değer bir hafta geçerli.",
    "Ticari_Kredi":        "Haftalık EVDS yayını geç gelirse son değer geçerli.",
    "TCMB_Mevduat_1M":     "Cuma akşam EVDS yayını pipeline öncesi gelmediyse son değer geçerli (yavaş değişen faiz).",
    "TCMB_Mevduat_3M":     "Cuma akşam EVDS yayını gelmediyse ffill.",
    "TCMB_Mevduat_1M_Onceki_Hafta": "shift(1) kaynağı ffill ile taşınır.",
    "TCMB_Mevduat_3M_Onceki_Hafta": "shift(1) kaynağı ffill ile taşınır.",
    # Cross-feature alt endeksler
    "WebTufe_Aclik_Siniri":       "Açlık sınırı gıda sepeti ile paralel hareket eder — oran ile türetilebilir.",
    "WebTufe_Gida_Endeks":        "Gıda alt endeksinin manşete oranı tarihsel olarak stabil; median oran × manşet güvenli proxy.",
    "WebTufe_Enerji_Endeks":      "Enerji alt endeksinin manşete oranı tarihsel olarak stabil.",
    "WebTufe_Ulastirma_Endeks":   "Ulaştırma alt endeksi manşete oran ile türetilebilir.",
    "WebTufe_Hizmet_Endeks":      "Hizmet alt endeksi manşete oran ile türetilebilir.",
    "WebTufe_Giyim_Endeks":       "Giyim alt endeksi manşete oran ile türetilebilir.",
    "WebTufe_KisiselBakim_Endeks":"Kişisel bakım alt endeksi manşete oran ile türetilebilir.",
    # NaN bırak
    "USDT_TRY_Hacim":      "CoinGecko free tier 365-gün sınırı; güvenilir alternatif donor yok → ilk 29 hafta gerçek warmup.",
    "WebTufe_TUFE_Yillik": "Yıllık değer geriye uydurmak 15 ay'lık bileşik etkiyi taklit eder — çarpık olur, NaN bırakıldı.",
    # Recompute
    "Faiz_Spread":       "Ham kolonlar (TCMB_Mevduat_1M, TLREF) fill edildikten sonra farktan türet.",
    "Reel_Faiz":         "TLREF ve WebTufe_TUFE_Aylik fill edildikten sonra yeniden hesap.",
    "BIST100_Getiri":    "pct_change ilk satırı doğası gereği NaN; 0 ile doldurmak sahte 'değişim yok' sinyali verir — model ilk haftayı warmup olarak filtrelesin.",
    "Altin_Getiri":      "İlk hafta pct_change NaN — 0 ile doldurmak sahte sinyal olur, NaN bırakıldı.",
    "Kur_Degisim":       "İlk hafta pct_change NaN — NaN bırakıldı (warmup).",
    "Sepet_Kur_Degisim": "İlk hafta pct_change NaN — NaN bırakıldı (warmup).",
    "Reel_Giyim":        "BKM ve WebTufe endeksleri fill edildikten sonra oran olarak türet.",
    "Lipstick_Ratio":    "BKM alt kalemleri fill edildikten sonra oran olarak türet.",
    "Reel_Yemek":        "BKM ve WebTufe_Hizmet_Endeks fill edildikten sonra türet.",
    "Reel_Kozmetik":     "BKM ve WebTufe_KisiselBakim_Endeks fill edildikten sonra türet.",
    "Gida_Spread":       "WebTufe alt/genel endeksler fill edildikten sonra oran türetilir.",
    "Enerji_Spread":     "WebTufe endeksleri fill edildikten sonra türet.",
    "Hizmet_vs_Gida":    "WebTufe alt endeksler fill edildikten sonra türet.",
    "Zorunlu_Harcama_Baskisi": "WebTufe endeksleri fill edildikten sonra türet.",
    "Market_Stress":     "Volatilite kolonları fill edildikten sonra z-score ortalaması yeniden.",
    "Market_Anomaly":    "Ham kolonlar fill edildikten sonra z-score eşik bayrağı yeniden.",
    "Faiz_Anomaly":      "TLREF ve TCMB_Mevduat_1M fill edildikten sonra z-score eşik yeniden.",
    "Kur_Spike":         "USD_TRY fill gerekli değil, derive_firast_features tekrar hesaplar.",
    "Altin_Rush":        "Gram_Altin_TRY temelli z-score — ham kolon tamsa yeniden hesap gerekmez.",
    "CDS_Spike":         "CDS_5Y fill edildikten sonra z-score yeniden.",
    "Enflasyon_Sok":     "WebTufe_TUFE_Aylik fill edildikten sonra z-score yeniden.",
    "Likidite_Sikisma":  "AOFM − TLREF spread z-score — ham kolonlar zaten dolu.",
    # Fill gerekmez
    "TLREF": "Pipeline EVDS'den haftalık fixing'in ortalamasını çeker — tam seri.",
    "AOFM": "Pipeline EVDS günlük değerlerden haftalık ortalama çeker — tam.",
    "TCMB_Net_Fonlama_TL": "EVDS günlük seri tam; NaN oluşmuyor.",
    "PP_Getiri": "TEFAS dolu, boşsa AOFM fallback ile doldurulur.",
    "BIST100": "EVDS haftalık tam.",
    "XBANK": "yfinance tatil kolonda işaretli, haftalık ortalama tam.",
    "VIX": "yfinance VIX haftalık ortalama tam.",
    "USD_TRY": "yfinance 24/7 — haftalık ortalama tam.",
    "EUR_USD": "yfinance 24/7 — tam.",
    "EUR_TRY": "yfinance 24/7 — tam.",
    "DXY": "yfinance 24/5 — haftalık ortalama tam.",
    "Sepet_Kur": "TCMB günlük XML kapsamı tam.",
    "Altin_USD": "yfinance GC=F tam.",
    "Gumus": "yfinance SI=F tam.",
    "Bakir": "yfinance HG=F tam.",
    "Brent": "yfinance BZ=F tam.",
    "Gram_Altin_TRY": "Altin_USD × USD_TRY türetmesi — donor tam olduğundan NaN oluşmaz.",
    "GT_Mevduat_Faizi": "pytrends haftalık — rate-limit'e rağmen retry ile dolu.",
    "GT_En_Yuksek": "pytrends haftalık — rate-limit'e rağmen retry ile dolu.",
    "Full_Workday": "holidays.Turkey kütüphanesinden deterministik.",
    # Deterministik bayraklar
    "Payday": "Ay başı/ortası/sonu deterministik üretilir.",
    "Emekli_Maas_Donemi": "Ayın 17-25 aralığı deterministik.",
    "Tax_Season": "{3,4,5,7,11} ay bayrağı deterministik.",
    "Ay_Sonu_Haftasi": "Ay son 5 günü deterministik.",
    "Bayram_Haftasi": "holidays.Turkey + BAYRAM_KEYWORDS deterministik.",
    "Bayram_Arefesi": "Bayramdan -5 gün penceresi deterministik.",
    "Bayram_Sonrasi": "Bayramdan +7 gün penceresi deterministik.",
    "Milli_Bayram_Haftasi": "holidays.Turkey - BAYRAM_KEYWORDS deterministik.",
    "Season": "Month'tan deterministik (1-4).",
    "Month": "Min_Tarih'in orta ayı deterministik.",
    "YearEnd": "Aralık son 2 haftası deterministik.",
    "Okul_Tatili": "15 Haz – 15 Eyl sabit pencere.",
    "Somestr_Tatili": "Ocak 20 – Şubat 3 sabit pencere.",
    "Ara_Tatil": "MEB ara tatil sabit pencereleri.",
    "Quarter_End": "Mart/Haz/Eyl/Ara son haftası deterministik.",
    "Ramazan": "hijridate ile Hicri 9. ay deterministik.",
    "Black_Friday": "Kasım 4. Perşembe sabit kural.",
    "Yaz_Turizm": "Mayıs-Ekim sabit ay bayrağı.",
    "Kis_Turizm": "Aralık-Mart sabit ay bayrağı.",
    "Temetu_Donemi": "15 Nisan – 15 Haziran sabit pencere.",
    "PPK_Haftasi": "fetch_ppk_dates çıktısından deterministik.",
    "PPK_Oncesi": "PPK tarihinden -7 gün deterministik.",
    "PPK_Sonrasi": "PPK tarihinden +7 gün deterministik.",
    "Enflasyon_Aciklama_Haftasi": "Ayın ilk 7 günü sabit kural.",
}


def _write_details(wb, rows: list[dict], headers: list[str], widths: dict[int, int]):
    if "Details" in wb.sheetnames:
        del wb["Details"]
    wb.create_sheet("Details")
    ws = wb["Details"]
    for i, h in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=i, value=h)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill(start_color="FF6200", end_color="FF6200", fill_type="solid")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for r, row in enumerate(rows, start=2):
        for ci, key in enumerate(headers, start=1):
            cell = ws.cell(row=r, column=ci, value=row[key])
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    for col_idx, w in widths.items():
        ws.column_dimensions[ws.cell(row=1, column=col_idx).column_letter].width = w


def add_details_sheet_model():
    """FIRAST_MODEL.xlsx için Details — FIRAST Details + NaN Stratejisi + Kalan NaN.
    Kalan NaN sayısı SON SATIR (cari hafta) hariç hesaplanır — cari haftanın
    doğal NaN'ları fill kalitesini yansıtmaz.
    """
    log_baslik(
        "FIRAST_MODEL 'Details' sheet (feature kataloğu + fill stratejisi)",
        "pipeline türetme · son satır hariç NaN sayımı",
    )
    file_path = "FIRAST_MODEL.xlsx"
    if not os.path.exists(file_path):
        print(f"  ⚠ {file_path} bulunamadı.")
        return

    # FIRAST_MODEL.xlsx'i oku (header row=1 startrow=2 formatında)
    df_model = None
    for header in (1, 2, 0):
        try:
            candidate = pd.read_excel(file_path, header=header, sheet_name="Sheet1")
            if "Min_Tarih" in candidate.columns and "Max_Tarih" in candidate.columns:
                df_model = candidate
                break
        except Exception:
            continue
    if df_model is None or df_model.empty:
        print(f"  ⚠ {file_path} Sheet1 okunamadı.")
        return

    cols = list(df_model.columns)
    # Son satır hariç NaN sayımı
    df_without_last = df_model.iloc[:-1]

    rows = []
    eksik_meta, eksik_nan, eksik_reason = [], [], []
    for c in cols:
        anlam, kaynak, ne_zaman = META.get(c, ("(meta tanımsız)", "?", "?"))
        if c not in META:
            eksik_meta.append(c)
        strategy = NAN_STRATEGY.get(c, "(strateji tanımsız)")
        if c not in NAN_STRATEGY:
            eksik_nan.append(c)
        reason = NAN_STRATEGY_REASON.get(c, "(mantık tanımsız)")
        if c not in NAN_STRATEGY_REASON:
            eksik_reason.append(c)
        s = pd.to_numeric(df_without_last[c], errors="coerce") \
            if c not in ("Yıl", "Hafta", "Min_Tarih", "Max_Tarih") else df_without_last[c]
        kalan_nan = int(s.isna().sum()) if c not in ("Yıl", "Hafta", "Min_Tarih", "Max_Tarih") \
            else int(df_without_last[c].isna().sum())
        rows.append({
            "Feature": c,
            "Anlam": anlam,
            "Kaynak": kaynak,
            "Ne zaman üretiliyor": ne_zaman,
            "Nerede üretildi": "FIRAST_MODEL",
            "NaN Stratejisi": strategy,
            "NaN Stratejisi Mantığı": reason,
            "Kalan NaN Sayısı": kalan_nan,
        })

    wb = load_workbook(file_path)
    headers = ["Feature", "Anlam", "Kaynak", "Ne zaman üretiliyor",
               "Nerede üretildi", "NaN Stratejisi", "NaN Stratejisi Mantığı",
               "Kalan NaN Sayısı"]
    widths = {1: 34, 2: 62, 3: 55, 4: 46, 5: 22, 6: 58, 7: 72, 8: 18}
    _write_details(wb, rows, headers, widths)
    wb.save(file_path)
    total_nan = sum(r["Kalan NaN Sayısı"] for r in rows)
    print(f"  Details: {len(rows)} feature · toplam kalan NaN (son satır hariç): {total_nan}")
    if eksik_meta:
        print(f"  ⚠ META'da tanımsız: {eksik_meta[:5]}{'...' if len(eksik_meta)>5 else ''}")
    if eksik_nan:
        print(f"  ⚠ NAN_STRATEGY'de tanımsız: {eksik_nan[:5]}{'...' if len(eksik_nan)>5 else ''}")
    if eksik_reason:
        print(f"  ⚠ NAN_STRATEGY_REASON'da tanımsız: {eksik_reason[:5]}{'...' if len(eksik_reason)>5 else ''}")


def add_details_sheet():
    log_baslik(
        "FIRAST 'Details' sheet (feature kataloğu)",
        "internal · meta-bilgi yazımı (harici kaynak yok)",
    )

    file_path = "FIRAST.xlsx"
    if not os.path.exists(file_path):
        print(f"  ⚠ {file_path} bulunamadı.")
        return

    df_sheet1 = read_firast()
    if df_sheet1 is None or df_sheet1.empty:
        print("  ⚠ FIRAST Sheet1 okunamadı.")
        return
    cols = list(df_sheet1.columns)

    rows = []
    eksik = []
    for c in cols:
        if c in META:
            anlam, kaynak, ne_zaman = META[c]
        else:
            anlam, kaynak, ne_zaman = "(meta tanımsız — META sözlüğüne ekle)", "?", "?"
            eksik.append(c)
        rows.append({
            "Feature": c,
            "Anlam": anlam,
            "Kaynak": kaynak,
            "Ne zaman üretiliyor": ne_zaman,
            "Nerede üretildi": "FIRAST_Extended",
        })

    wb = load_workbook(file_path)
    headers = ["Feature", "Anlam", "Kaynak", "Ne zaman üretiliyor", "Nerede üretildi"]
    widths = {1: 34, 2: 62, 3: 55, 4: 46, 5: 22}
    _write_details(wb, rows, headers, widths)
    wb.save(file_path)
    print(f"  Details: {len(rows)} feature kataloglandı.")
    if eksik:
        print(f"  ⚠ META'da tanımsız {len(eksik)} kolon: {eksik[:10]}{'...' if len(eksik)>10 else ''}")


if __name__ == "__main__":
    add_details_sheet()
