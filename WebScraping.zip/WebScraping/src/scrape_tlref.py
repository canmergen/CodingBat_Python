"""
scrape_tlref.py
---------------
TLREF (Türk Lirası Referans Faizi) verisini EVDS3'ten çeker ve
FIRAST.xlsx'e yazar.

Kaynak : EVDS3 /igmevdsms-dis/fe (Playwright oturumu)
Seri   : TP.BISTTLREF.ORAN · günlük
Yöntem : Her FIRAST haftası için Min_Tarih – Max_Tarih aralığındaki
         günlük TLREF değerlerinin ortalaması alınır.

Not: Eski Selenium+pagination yaklaşımının yerini aldı; borsaistanbul.com
scrape'i artık gerekli değil.
"""

import pandas as pd

from src.evds3_client import fetch_evds3_series, items_to_series
from src.utils import read_firast, save_firast, log_baslik

SERIES_CODE = "TP.BISTTLREF.ORAN"
COLUMN_NAME = "TLREF"


def scrape_tlref(start_date=None):
    log_baslik(
        "TLREF",
        "https://evds3.tcmb.gov.tr · TP.BISTTLREF.ORAN · günlük → haftalık ort.",
    )

    df = read_firast()
    if df is None or df.empty:
        print("  FIRAST.xlsx bulunamadı veya boş.")
        return

    if COLUMN_NAME not in df.columns:
        df[COLUMN_NAME] = None

    df["Min_Tarih"] = pd.to_datetime(df["Min_Tarih"], dayfirst=True, errors="coerce")
    df["Max_Tarih"] = pd.to_datetime(df["Max_Tarih"], dayfirst=True, errors="coerce")

    start = df["Min_Tarih"].min().strftime("%d-%m-%Y")
    end = df["Max_Tarih"].max().strftime("%d-%m-%Y")
    print(f"  Tarih aralığı: {start} → {end}")

    items = fetch_evds3_series([SERIES_CODE], start_date=start, end_date=end, frequency="1")
    series = items_to_series(items, SERIES_CODE).dropna().sort_index()
    if series.empty:
        print("  ⚠ EVDS3'ten TLREF verisi gelmedi.")
        _restore_dates(df)
        return
    print(f"  {len(series)} günlük kayıt alındı.")

    # Her haftanın Min-Max aralığındaki günlük değerlerin ortalamasını yaz
    updated = 0
    last_2 = set(df.index[-2:])
    for idx, row in df.iterrows():
        if idx not in last_2 and pd.notna(row.get(COLUMN_NAME)):
            continue
        r_start, r_end = row["Min_Tarih"], row["Max_Tarih"]
        if pd.isna(r_start) or pd.isna(r_end):
            continue
        mask = (series.index >= r_start) & (series.index <= r_end)
        subset = series.loc[mask].dropna()
        if not subset.empty:
            val = round(float(subset.mean()), 4)
            if df.at[idx, COLUMN_NAME] != val:
                df.at[idx, COLUMN_NAME] = val
                updated += 1

    filled = df[COLUMN_NAME].notna().sum()
    print(f"  TLREF: {filled}/{len(df)} hafta dolu, {updated} güncellendi.")

    _restore_dates(df)
    save_firast(df)


def _restore_dates(df):
    for col in ("Min_Tarih", "Max_Tarih"):
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = df[col].dt.strftime("%d.%m.%Y")


if __name__ == "__main__":
    scrape_tlref()
