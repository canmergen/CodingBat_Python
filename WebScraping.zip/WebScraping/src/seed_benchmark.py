"""
seed_benchmark.py
-----------------
2025 (Hafta 1) – 2026 (Hafta 1) arası 54 haftanın Benchmark değerlerini
iş birimi tarafından elle sağlanan tablodan FIRAST.xlsx'e yazar.

Sadece `Benchmark` kolonu BOŞ olan haftalara yazar; dolu hücreleri
override etmez. hesapkurdu.com günlük arşivi geriye dönük eksik kalmış
haftaları tamamlamak için.

aggregate_benchmark çağrıldıktan SONRA çalıştırılmalıdır.
"""

import pandas as pd

from src.utils import log_baslik, read_firast, save_firast


SEED = pd.DataFrame({
    # Haftanın Cuma'sı — FIRAST Pzt-Cum penceresiyle (Min_Tarih ≤ Cuma ≤ Max_Tarih)
    # güvenli eşleşme sağlar
    "Date": pd.to_datetime([
        "2025-01-03", "2025-01-10", "2025-01-17", "2025-01-24",
        "2025-01-31", "2025-02-07", "2025-02-14", "2025-02-21",
        "2025-02-28", "2025-03-07", "2025-03-14", "2025-03-21",
        "2025-03-28", "2025-04-04", "2025-04-11", "2025-04-18",
        "2025-04-25", "2025-05-02", "2025-05-09", "2025-05-16",
        "2025-05-23", "2025-05-30", "2025-06-06", "2025-06-13",
        "2025-06-20", "2025-06-27", "2025-07-04", "2025-07-11",
        "2025-07-18", "2025-07-25", "2025-08-01", "2025-08-08",
        "2025-08-15", "2025-08-22", "2025-08-29", "2025-09-05",
        "2025-09-12", "2025-09-19", "2025-09-26", "2025-10-03",
        "2025-10-10", "2025-10-17", "2025-10-24", "2025-10-31",
        "2025-11-07", "2025-11-14", "2025-11-21", "2025-11-28",
        "2025-12-05", "2025-12-12", "2025-12-19", "2025-12-26",
        "2026-01-02", "2026-01-09",
    ]),
    "Benchmark": [
        49.00, 47.88, 47.83, 46.83,
        46.83, 46.33, 45.17, 45.17,
        44.50, 44.50, 45.00, 45.33,
        45.33, 48.83, 49.33, 49.67,
        50.00, 50.00, 51.00, 51.67,
        51.67, 51.33, 50.67, 50.67,
        50.67, 50.67, 50.67, 49.67,
        49.67, 49.33, 47.67, 47.33,
        46.67, 46.33, 47.00, 46.67,
        46.33, 46.33, 46.33, 46.33,
        45.67, 45.67, 45.33, 45.33,
        45.00, 44.67, 44.67, 45.00,
        45.00, 44.67, 44.33, 44.00,
        44.00, 43.33,
    ],
})


def seed_benchmark():
    log_baslik(
        "Benchmark (geçmiş boş hafta tamamlama)",
        "sabit tablo (iş birimi arşivi) · 2025 Hafta 1 – 2026 Hafta 1 · yalnız boş hücreler",
    )

    df = read_firast()
    if df is None or df.empty:
        print("  FIRAST.xlsx bulunamadı veya boş.")
        return

    if "Benchmark" not in df.columns:
        df["Benchmark"] = None

    df["Min_Tarih"] = pd.to_datetime(df["Min_Tarih"], dayfirst=True, errors="coerce")
    df["Max_Tarih"] = pd.to_datetime(df["Max_Tarih"], dayfirst=True, errors="coerce")

    filled = skipped = 0
    for _, row in SEED.iterrows():
        d = row["Date"]  # haftanın Cuma'sı (veya Paz) — mask Min ≤ d ≤ Max ile eşleşir
        mask = (df["Min_Tarih"] <= d) & (df["Max_Tarih"] >= d)
        if not mask.any():
            continue
        idx = df.index[mask][0]
        cur = df.at[idx, "Benchmark"]
        if pd.isna(cur):
            df.at[idx, "Benchmark"] = row["Benchmark"]
            filled += 1
        else:
            skipped += 1

    print(f"  {filled} boş hafta dolduruldu, {skipped} dolu hücre korundu "
          f"(toplam SEED: {len(SEED)}).")

    for col in ("Min_Tarih", "Max_Tarih"):
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = df[col].dt.strftime("%d.%m.%Y")

    save_firast(df)


if __name__ == "__main__":
    seed_benchmark()
