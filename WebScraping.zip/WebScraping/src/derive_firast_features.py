"""
derive_firast_features.py
-----------------------
FIRAST.xlsx içindeki ham kolonlardan türetilmiş feature'lar hesaplar
ve doğrudan FIRAST.xlsx'e yazar. Lag / Rolling / Delta dönüşümleri
bu adımın kapsamında DEĞİLDİR — model eğitim aşamasında ayrıca
hesaplanır (FIRAST.xlsx tek otorite kaynaktır).

Üretilen feature'lar (20 kolon):
  Etkileşim / Spread (6):
    Faiz_Spread, Reel_Faiz,
    Gida_Spread, Enerji_Spread, Hizmet_vs_Gida, Zorunlu_Harcama_Baskisi
  Haftalık getiri / değişim (4):
    BIST100_Getiri, Altin_Getiri, Kur_Degisim, Sepet_Kur_Degisim
  Davranışsal proxy (4):
    Reel_Giyim, Lipstick_Ratio, Reel_Yemek, Reel_Kozmetik
  Stres / anomali flag'leri (6):
    Market_Stress, Kur_Spike, Altin_Rush, CDS_Spike,
    Enflasyon_Sok, Likidite_Sikisma
"""

import pandas as pd
from src.utils import read_firast, save_firast, log_baslik


def _zscore_flag(series: pd.Series, name: str, threshold: float = 2.0) -> pd.Series:
    """Z-score |z| > threshold olan satırları 1, diğerlerini 0 yapar."""
    s = pd.to_numeric(series, errors="coerce")
    mu, std = s.mean(), s.std()
    if std and std > 0:
        z = (s - mu) / std
        flag = (z.abs() > threshold).astype(int)
        print(f"  {name}: {flag.sum()} hafta flaglandı (|z| > {threshold}σ)")
        return flag
    print(f"  ⚠ {name}: std=0, tüm değerler 0")
    return pd.Series(0, index=series.index)


def derive_firast_features():
    log_baslik(
        "Faiz_Spread, Reel_Faiz, BIST100/Altin_Getiri, Kur/Sepet_Kur_Degisim, Reel_Giyim/Yemek/Kozmetik, Lipstick_Ratio, Gida/Enerji_Spread, Hizmet_vs_Gida, Zorunlu_Harcama_Baskisi, Market_Stress, Kur/Altin/CDS_Spike, Enflasyon_Sok, Likidite_Sikisma",
        "internal · FIRAST ham kolonlarından türetme (harici kaynak yok)",
    )
    df = read_firast()
    if df is None or df.empty:
        print("FIRAST.xlsx bulunamadı veya boş.")
        return

    df["Min_Tarih"] = pd.to_datetime(df["Min_Tarih"], dayfirst=True, errors="coerce")
    df["Max_Tarih"] = pd.to_datetime(df["Max_Tarih"], dayfirst=True, errors="coerce")

    # ── Market Stress (Bileşik Volatilite) ────────────────────────
    stress_cols = []
    for col in ["BIST_Vol", "Kur_Vol", "VIX"]:
        if col in df.columns:
            s = pd.to_numeric(df[col], errors="coerce")
            mu, sigma = s.mean(), s.std()
            if sigma and sigma > 0:
                df[f"_z_{col}"] = (s - mu) / sigma
                stress_cols.append(f"_z_{col}")
    if stress_cols:
        df["Market_Stress"] = df[stress_cols].mean(axis=1).round(4)
        df.drop(columns=stress_cols, inplace=True)
        print(f"  Market_Stress: z-score avg of {[c.replace('_z_','') for c in stress_cols]}")
    else:
        print("  ⚠ Market_Stress: Volatilite kolonları yok")

    # ── Etkileşim / Spread ─────────────────────────────────────────
    if "TCMB_Mevduat_1M" in df.columns and "TLREF" in df.columns:
        tcmb = pd.to_numeric(df["TCMB_Mevduat_1M"], errors="coerce")
        tlref = pd.to_numeric(df["TLREF"], errors="coerce")
        df["Faiz_Spread"] = (tcmb - tlref).round(4)
        print("  Faiz_Spread: TCMB_Mevduat_1M - TLREF")

    if "TLREF" in df.columns and "WebTufe_TUFE_Aylik" in df.columns:
        tlref = pd.to_numeric(df["TLREF"], errors="coerce")
        wtufe = pd.to_numeric(df["WebTufe_TUFE_Aylik"], errors="coerce")
        df["Reel_Faiz"] = (tlref / 12 - wtufe).round(4)
        print("  Reel_Faiz: TLREF/12 - WebTufe_TUFE_Aylik")

    # ── Haftalık Getiri / Değişim ──────────────────────────────────
    if "BIST100" in df.columns:
        df["BIST100_Getiri"] = pd.to_numeric(df["BIST100"], errors="coerce").pct_change().mul(100).round(4)
        print("  BIST100_Getiri: haftalık %")

    if "Gram_Altin_TRY" in df.columns:
        df["Altin_Getiri"] = pd.to_numeric(df["Gram_Altin_TRY"], errors="coerce").pct_change().mul(100).round(4)
        print("  Altin_Getiri: haftalık %")

    if "USD_TRY" in df.columns:
        df["Kur_Degisim"] = pd.to_numeric(df["USD_TRY"], errors="coerce").pct_change().mul(100).round(4)
        print("  Kur_Degisim: USD/TRY haftalık %")

    if "Sepet_Kur" in df.columns:
        df["Sepet_Kur_Degisim"] = pd.to_numeric(df["Sepet_Kur"], errors="coerce").pct_change().mul(100).round(4)
        print("  Sepet_Kur_Degisim: haftalık %")

    # ── Davranışsal Proxy (BKM + WebTufe) ──────────────────────────
    if "BKM_Giyim_TL" in df.columns and "WebTufe_Giyim_Endeks" in df.columns:
        df["Reel_Giyim"] = (pd.to_numeric(df["BKM_Giyim_TL"], errors="coerce")
                            / pd.to_numeric(df["WebTufe_Giyim_Endeks"], errors="coerce")).round(4)
        print("  Reel_Giyim: BKM_Giyim_TL / WebTufe_Giyim_Endeks")

    if "BKM_Saglik_Kozmetik_TL" in df.columns and "BKM_Giyim_TL" in df.columns:
        df["Lipstick_Ratio"] = (pd.to_numeric(df["BKM_Saglik_Kozmetik_TL"], errors="coerce")
                                / pd.to_numeric(df["BKM_Giyim_TL"], errors="coerce")).round(4)
        print("  Lipstick_Ratio: BKM_Saglik_Kozmetik_TL / BKM_Giyim_TL")

    if "BKM_Yemek_TL" in df.columns and "WebTufe_Hizmet_Endeks" in df.columns:
        df["Reel_Yemek"] = (pd.to_numeric(df["BKM_Yemek_TL"], errors="coerce")
                            / pd.to_numeric(df["WebTufe_Hizmet_Endeks"], errors="coerce")).round(4)
        print("  Reel_Yemek: BKM_Yemek_TL / WebTufe_Hizmet_Endeks")

    if "BKM_Saglik_Kozmetik_TL" in df.columns and "WebTufe_KisiselBakim_Endeks" in df.columns:
        df["Reel_Kozmetik"] = (pd.to_numeric(df["BKM_Saglik_Kozmetik_TL"], errors="coerce")
                               / pd.to_numeric(df["WebTufe_KisiselBakim_Endeks"], errors="coerce")).round(4)
        print("  Reel_Kozmetik: BKM_Saglik_Kozmetik_TL / WebTufe_KisiselBakim_Endeks")

    # ── WebTufe Spread Göstergeleri ────────────────────────────────
    if "WebTufe_Gida_Endeks" in df.columns and "WebTufe_Endeks" in df.columns:
        df["Gida_Spread"] = (pd.to_numeric(df["WebTufe_Gida_Endeks"], errors="coerce")
                             / pd.to_numeric(df["WebTufe_Endeks"], errors="coerce")).round(6)
        print("  Gida_Spread: WebTufe_Gida / WebTufe_Genel")

    if "WebTufe_Enerji_Endeks" in df.columns and "WebTufe_Endeks" in df.columns:
        df["Enerji_Spread"] = (pd.to_numeric(df["WebTufe_Enerji_Endeks"], errors="coerce")
                               / pd.to_numeric(df["WebTufe_Endeks"], errors="coerce")).round(6)
        print("  Enerji_Spread: WebTufe_Enerji / WebTufe_Genel")

    if "WebTufe_Hizmet_Endeks" in df.columns and "WebTufe_Gida_Endeks" in df.columns:
        df["Hizmet_vs_Gida"] = (pd.to_numeric(df["WebTufe_Hizmet_Endeks"], errors="coerce")
                                / pd.to_numeric(df["WebTufe_Gida_Endeks"], errors="coerce")).round(6)
        print("  Hizmet_vs_Gida: Hizmet / Gıda")

    if all(c in df.columns for c in ["WebTufe_Gida_Endeks", "WebTufe_Enerji_Endeks", "WebTufe_Endeks"]):
        gida = pd.to_numeric(df["WebTufe_Gida_Endeks"], errors="coerce")
        enerji = pd.to_numeric(df["WebTufe_Enerji_Endeks"], errors="coerce")
        gen = pd.to_numeric(df["WebTufe_Endeks"], errors="coerce")
        df["Zorunlu_Harcama_Baskisi"] = ((gida + enerji) / (2 * gen)).round(6)
        print("  Zorunlu_Harcama_Baskisi: (Gıda+Enerji) / (2×Genel)")

    # ── Anomali Flag'leri (|z| > 2σ) ──────────────────────────────
    if "USD_TRY" in df.columns:
        usd_pct = pd.to_numeric(df["USD_TRY"], errors="coerce").pct_change() * 100
        df["Kur_Spike"] = _zscore_flag(usd_pct, "Kur_Spike")
    else:
        df["Kur_Spike"] = 0

    if "Gram_Altin_TRY" in df.columns:
        altin_pct = pd.to_numeric(df["Gram_Altin_TRY"], errors="coerce").pct_change() * 100
        df["Altin_Rush"] = _zscore_flag(altin_pct, "Altin_Rush")
    else:
        df["Altin_Rush"] = 0

    if "CDS_5Y" in df.columns:
        cds_delta = pd.to_numeric(df["CDS_5Y"], errors="coerce").diff()
        df["CDS_Spike"] = _zscore_flag(cds_delta, "CDS_Spike")
    else:
        df["CDS_Spike"] = 0

    if "WebTufe_TUFE_Aylik" in df.columns:
        df["Enflasyon_Sok"] = _zscore_flag(
            pd.to_numeric(df["WebTufe_TUFE_Aylik"], errors="coerce"),
            "Enflasyon_Sok",
        )
    else:
        df["Enflasyon_Sok"] = 0

    if "AOFM" in df.columns and "TLREF" in df.columns:
        liq = pd.to_numeric(df["AOFM"], errors="coerce") - pd.to_numeric(df["TLREF"], errors="coerce")
        df["Likidite_Sikisma"] = _zscore_flag(liq, "Likidite_Sikisma")
    else:
        df["Likidite_Sikisma"] = 0

    # ── Tarih formatlarını geri yükle ──────────────────────────────
    for col in ["Min_Tarih", "Max_Tarih"]:
        if col in df.columns and pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = df[col].dt.strftime("%d.%m.%Y")

    save_firast(df)
if __name__ == "__main__":
    derive_firast_features()
