"""
fetch_evds3_macro.py
--------------------
EVDS3'ten makroekonomik göstergeleri çeker ve FIRAST.xlsx'e yazar.

Çekilen veriler:
  - Tüketici Kredi Faizi   : TP.TRY.KT01  (Haftalık)
  - Kapasite Kullanım Oranı : TP.KKO2.IS   (Aylık → forward-fill)
  - Tüketici Güven Endeksi  : TP.TG2.Y01   (Aylık → forward-fill)
  - DİBS Gösterge Faiz 2Y   : TP.GS.G02   (Günlük → haftalık ort.)
  - DİBS Gösterge Faiz 10Y  : TP.GS.G10   (Günlük → haftalık ort.)
  - Zorunlu Karşılıklar     : TP.ZKO.YN01 (Aylık → forward-fill)
  - Sanayi Üretim Endeksi   : TP.SAUam2.Y1 (Aylık → forward-fill)

Not: Seri kodları doğru çalışmazsa EVDS3 arayüzünden kontrol edilmelidir.
     EVDS3 yanıtında nokta (.) alt çizgiye (_) dönüşür.
"""

import pandas as pd
from src.utils import read_firast, save_firast, log_baslik
from src.evds3_client import fetch_evds3_series, items_to_series


# ── Seri tanımları ─────────────────────────────────────────────────
# Diğer modüllerde çekilen seriler (burada tekrar çekilmez):
#   - TCMB 1M/3M mevduat faizi → fetch_tcmb_mevduat.py
#   - İhtiyaç kredi faizi       → fetch_evds3_macro.py (TP.KTF10 burada)
#   - TÜİK & WebTüfe TÜFE      → fetch_webtufe_tufe.py (apiwebtufe.com)
# DİBS 2Y/10Y serileri yfinance üzerinden alınıyor (EVDS3 portlet HTTP 500 dönüyor).
SERIES = [
    {
        "code": "TP.KKO2.IS.TOP",
        "col_name": "KKO",
        "freq": "5",   # aylık
        "agg": "avg",
        "desc": "Kapasite Kullanım Oranı (İmalat Sanayi Toplam)",
    },
    {
        "code": "TP.TG2.Y01",
        "col_name": "Tuketici_Guven",
        "freq": "5",   # aylık
        "agg": "avg",
        "desc": "Tüketici Güven Endeksi",
    },
    {
        "code": "TP.TSANAYMT2021.Y1",
        "col_name": "Sanayi_Uretim",
        "freq": "5",   # aylık
        "agg": "avg",
        "desc": "Sanayi Üretim Endeksi (2021=100, Mevsim+Takvim Etkisinden Arındırılmış)",
    },
    {
        "code": "TP.KTF10",
        "col_name": "Ihtiyac_Kredi_Faizi",
        "freq": "3",   # haftalık
        "agg": "avg",
        "desc": "İhtiyaç Kredisi Faiz Oranı (TL, Akım)",
    },
    {
        "code": "TP.APIFON3",
        "col_name": "TCMB_Net_Fonlama_TL",
        "freq": "1",   # günlük
        "agg": "avg",
        "desc": "TCMB Net Fonlama Miktarı (Milyon TL) — likidite göstergesi",
    },
    {
        "code": "TP.FHGE.S01",
        "col_name": "Fin_Guven",
        "freq": "5",
        "agg": "avg",
        "desc": "Finansal Hizmetler Güven Endeksi (manşet)",
    },
    # ── FHGE alt endeksleri (TP.FHGE.S02 – S16) ─────────────────────
    # TCMB Finansal Hizmetler Anketi'ndeki 15 alt soru — manşet endeksi
    # oluşturan bileşenler. Cari durum + gelecek 3 ay beklentileri karışık.
    # TCMB meta-data linkinden hangi kodun hangi soruya denk geldiği görülebilir.
    {"code": "TP.FHGE.S02", "col_name": "Fin_Guven_S02", "freq": "5", "agg": "avg", "desc": "FHGE alt endeks S02"},
    {"code": "TP.FHGE.S03", "col_name": "Fin_Guven_S03", "freq": "5", "agg": "avg", "desc": "FHGE alt endeks S03"},
    {"code": "TP.FHGE.S04", "col_name": "Fin_Guven_S04", "freq": "5", "agg": "avg", "desc": "FHGE alt endeks S04"},
    {"code": "TP.FHGE.S05", "col_name": "Fin_Guven_S05", "freq": "5", "agg": "avg", "desc": "FHGE alt endeks S05"},
    {"code": "TP.FHGE.S06", "col_name": "Fin_Guven_S06", "freq": "5", "agg": "avg", "desc": "FHGE alt endeks S06"},
    {"code": "TP.FHGE.S07", "col_name": "Fin_Guven_S07", "freq": "5", "agg": "avg", "desc": "FHGE alt endeks S07"},
    {"code": "TP.FHGE.S08", "col_name": "Fin_Guven_S08", "freq": "5", "agg": "avg", "desc": "FHGE alt endeks S08"},
    {"code": "TP.FHGE.S09", "col_name": "Fin_Guven_S09", "freq": "5", "agg": "avg", "desc": "FHGE alt endeks S09"},
    {"code": "TP.FHGE.S10", "col_name": "Fin_Guven_S10", "freq": "5", "agg": "avg", "desc": "FHGE alt endeks S10"},
    {"code": "TP.FHGE.S11", "col_name": "Fin_Guven_S11", "freq": "5", "agg": "avg", "desc": "FHGE alt endeks S11"},
    {"code": "TP.FHGE.S12", "col_name": "Fin_Guven_S12", "freq": "5", "agg": "avg", "desc": "FHGE alt endeks S12"},
    {"code": "TP.FHGE.S13", "col_name": "Fin_Guven_S13", "freq": "5", "agg": "avg", "desc": "FHGE alt endeks S13"},
    {"code": "TP.FHGE.S14", "col_name": "Fin_Guven_S14", "freq": "5", "agg": "avg", "desc": "FHGE alt endeks S14"},
    {"code": "TP.FHGE.S15", "col_name": "Fin_Guven_S15", "freq": "5", "agg": "avg", "desc": "FHGE alt endeks S15"},
    {"code": "TP.FHGE.S16", "col_name": "Fin_Guven_S16", "freq": "5", "agg": "avg", "desc": "FHGE alt endeks S16"},
    # ── Enflasyon Serileri ──────────────────────────────────────────
    # Çekirdek enflasyon ham indeksten (~3756) her satır için aylık %
    # değişim hesaplanır. Yıllık TÜFE değişimi fetch_webtufe_tufe'den gelir.
    {
        "code": "TP.FE.OKTG02",
        "col_name": "Cekirdek_Enflasyon",
        "freq": "5",   # aylık
        "agg": "avg",
        "desc": "Çekirdek Enflasyon B Endeksi — Aylık % Değişim (hesaplanmış)",
        "compute_pct_change": True,  # EVDS3 ham endeks (~3756) verir; % değişimi biz hesaplıyoruz
    },
    # ── TCMB Beklenti Anketi (API key gerektirir) ───────────────────────
    {
        "code": "TP.PKAUO.S01.E.U",
        "col_name": "Enflasyon_Beklenti_12ay",
        "freq": "5",   # aylık
        "agg": "avg",
        "desc": "TCMB Beklenti Anketi: 12 Ay Sonrası Enflasyon Beklentisi (%)",
        "api_key_required": True,
    },
    {
        "code": "TP.PKAUO.S07.A.U",
        "col_name": "GSYH_Buyume_Beklenti",
        "freq": "5",   # aylık
        "agg": "avg",
        "desc": "TCMB Beklenti Anketi: GSYH Büyime Beklentisi (Cari Yıl, %)",
        "api_key_required": True,
    },
    # ── İstihdam (API key gerektirir) ───────────────────────────────
    {
        "code": "TP.YISGUCU2.G8",
        "col_name": "Issizlik",
        "freq": "5",   # üç aylık (quarterly)
        "agg": "avg",
        "desc": "TÜİK İşsizlik Oranı (%)",
        "api_key_required": True,
    },
]


def fetch_evds3_macro(api_key: str | None = None):
    log_baslik(
        "KKO, Tuketici_Guven, Sanayi_Uretim, Fin_Guven (+ S02-S16), Cekirdek_Enflasyon, Enflasyon_Beklenti_12ay, GSYH_Buyume_Beklenti, Issizlik, Ihtiyac_Kredi_Faizi",
        "https://evds3.tcmb.gov.tr · çoklu TP.* serisi · aylık/haftalık",
    )
    df_excel = read_firast()
    if df_excel is None or df_excel.empty:
        print("FIRAST.xlsx bulunamadı veya boş.")
        return

    df_excel["Min_Tarih"] = pd.to_datetime(df_excel["Min_Tarih"], dayfirst=True, errors="coerce")
    df_excel["Max_Tarih"] = pd.to_datetime(df_excel["Max_Tarih"], dayfirst=True, errors="coerce")

    min_date = df_excel["Min_Tarih"].min()
    max_date = df_excel["Max_Tarih"].max()
    start_str = min_date.strftime("%d-%m-%Y")
    end_str = max_date.strftime("%d-%m-%Y")

    for s in SERIES:
        print(f"\n  → {s['desc']} ({s['code']})")

        col_name = s["col_name"]
        if col_name not in df_excel.columns:
            df_excel[col_name] = None

        try:
            items = fetch_evds3_series(
                [s["code"]],
                start_date=start_str,
                end_date=end_str,
                frequency=s["freq"],
                aggregation=s["agg"],
                api_key=api_key if s.get("api_key_required") else None,
            )
        except Exception as e:
            print(f"    ⚠ Hata: {e}")
            continue

        if not items:
            print(f"    ⚠ Veri alınamadı. Seri kodu doğru mu? → {s['code']}")
            continue

        series_vals = items_to_series(items, s["code"])
        valid_count = len(series_vals.dropna())
        print(f"    Geçerli değer sayısı: {valid_count}")

        if valid_count == 0:
            continue

        # Endeksten % defisim hesapla (EVDS3 formula=1/2 calismiyor)
        if s.get("compute_pct_change"):
            series_vals = series_vals.pct_change().mul(100).round(4)
            print(f"    Endeks → aylık % degisim hesaplandı.")

        # Haftalık ortalamaları FIRAST satırlarına yaz
        updated = 0
        last_2_idx = set(df_excel.index[-2:])
        for idx, row in df_excel.iterrows():
            # Artımsal: dolu satırları atla, son 2 hafta hariç
            if pd.notna(row.get(col_name)) and idx not in last_2_idx:
                continue
            r_start = row["Min_Tarih"]
            r_end = row["Max_Tarih"]
            if pd.isna(r_start) or pd.isna(r_end):
                continue
            mask = (series_vals.index >= r_start) & (series_vals.index <= r_end)
            subset = series_vals.loc[mask].dropna()
            if not subset.empty:
                df_excel.at[idx, col_name] = round(subset.mean(), 4)
                updated += 1

        print(f"    {updated} satır güncellendi.")

    # ── Tarih formatını geri yükle ve kaydet ──────────────────────
    for col in ["Min_Tarih", "Max_Tarih"]:
        if pd.api.types.is_datetime64_any_dtype(df_excel[col]):
            df_excel[col] = df_excel[col].dt.strftime("%d.%m.%Y")

    save_firast(df_excel)
if __name__ == "__main__":
    fetch_evds3_macro()
