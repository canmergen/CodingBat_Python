"""
fetch_sepet_kur.py
------------------
TCMB günlük döviz kuru XML servisinden USD/TRY ve EUR/TRY ForexBuying değerlerini çeker,
Sepet Kur = 0.5 × ForexBuying(USD) + 0.5 × ForexBuying(EUR) hesaplayarak
haftanın son geçerli iş günü kurunu FIRAST.xlsx'e yazar.

Kaynak   : https://www.tcmb.gov.tr/kurlar/YYYYMM/DDMMYYYY.xml  (TCMB açık XML)
Kur tipi : ForexBuying (Döviz Alış)
Mantık   : Her haftalık satır için aralık içindeki son geçerli iş gününün kuru alınır.
           (Doğrulama: 29/12-04/01/2026 haftası → 31/12 ForexBuying → Sepet=46.57 ✅)
"""

import xml.etree.ElementTree as ET
from datetime import timedelta

import pandas as pd
import requests

from src.utils import read_firast, save_firast, log_baslik

COLUMN_NAME   = "Sepet_Kur"
TCMB_XML_BASE = "https://www.tcmb.gov.tr/kurlar"
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"


def _fetch_day_rate(date: pd.Timestamp, session: requests.Session) -> float | None:
    """Verilen gün için TCMB XML'den Sepet Kur (ForexBuying) hesaplar."""
    url = f"{TCMB_XML_BASE}/{date.strftime('%Y%m')}/{date.strftime('%d%m%Y')}.xml"
    try:
        r = session.get(url, timeout=10)
        if r.status_code != 200:
            return None
        root = ET.fromstring(r.content)
        rates = {}
        for c in root.findall("Currency"):
            code = c.get("CurrencyCode")
            if code in ("USD", "EUR"):
                val = c.findtext("ForexBuying")
                if val and val.strip():
                    rates[code] = float(val.replace(",", "."))
        if "USD" in rates and "EUR" in rates:
            return 0.5 * rates["USD"] + 0.5 * rates["EUR"]
        return None
    except Exception:
        return None


def _last_valid_rate(start: pd.Timestamp,
                     end: pd.Timestamp,
                     session: requests.Session) -> float | None:
    """
    [start, end] aralığındaki son geçerli iş günü sepet kurunu döndürür.
    Yıl kesen haftalarda (örn: 29/12-04/01) start yılının son geçerli günü önceliklendirilir.
    (Doğrulama: 29/12-04/01/2026 → 31/12/2025 ForexBuying → Sepet=46.57 ✅)
    """
    # Yıl kesiminde önce start yılının son geçerli gününü dene
    if start.year != end.year:
        year_end = pd.Timestamp(year=start.year, month=12, day=31)
        candidate = year_end
        while candidate >= start:
            if candidate.weekday() < 5:
                rate = _fetch_day_rate(candidate, session)
                if rate is not None:
                    return rate
            candidate -= timedelta(days=1)

    # Normal: end'den geriye git
    current = end
    while current >= start:
        if current.weekday() < 5:
            rate = _fetch_day_rate(current, session)
            if rate is not None:
                return rate
        current -= timedelta(days=1)
    return None



def fetch_sepet_kur():
    log_baslik(
        "Sepet_Kur",
        "https://www.tcmb.gov.tr/kurlar/YYYYMM/DDMMYYYY.xml · günlük forex bülteni (50% USD + 50% EUR)",
    )
    df_excel = read_firast()
    if df_excel is None or df_excel.empty:
        print("Error: FIRAST.xlsx not found or empty.")
        return

    if COLUMN_NAME not in df_excel.columns:
        df_excel[COLUMN_NAME] = None

    df_excel["Min_Tarih"] = pd.to_datetime(df_excel["Min_Tarih"], dayfirst=True, errors="coerce")
    df_excel["Max_Tarih"] = pd.to_datetime(df_excel["Max_Tarih"], dayfirst=True, errors="coerce")

    session = requests.Session()
    session.headers.update({"User-Agent": UA})

    updated_count = 0
    last_2_idx = set(df_excel.index[-2:])
    for idx, row in df_excel.iterrows():
        # Artımsal: dolu satırları atla, son 2 hafta hariç
        if pd.notna(row.get(COLUMN_NAME)) and idx not in last_2_idx:
            continue
        r_start = row["Min_Tarih"]
        r_end   = row["Max_Tarih"]
        if pd.isna(r_start) or pd.isna(r_end):
            continue

        rate = _last_valid_rate(r_start, r_end, session)
        if rate is not None:
            df_excel.at[idx, COLUMN_NAME] = rate
            updated_count += 1

    print(f"Updated {updated_count} rows with '{COLUMN_NAME}'.")

    for col in ["Min_Tarih", "Max_Tarih"]:
        if pd.api.types.is_datetime64_any_dtype(df_excel[col]):
            df_excel[col] = df_excel[col].dt.strftime("%d.%m.%Y")

    save_firast(df_excel)
    print("Saved FIRAST.xlsx.")


if __name__ == "__main__":
    fetch_sepet_kur()
