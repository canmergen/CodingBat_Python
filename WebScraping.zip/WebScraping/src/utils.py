
import os
import sys
from pathlib import Path

import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font, Alignment

FIRAST_PATH = "FIRAST.xlsx"

_BORDER = "─" * 68
_step_state = {"i": 0, "total": 0}


def log_set_total(n: int) -> None:
    """Pipeline başında toplam adım sayısını bildirir; sayaç sıfırlanır."""
    _step_state["i"] = 0
    _step_state["total"] = n


def log_baslik(feature: str, kaynak: str) -> None:
    """
    Her adımdan önce standart header basar:
        ────────────────────────────────────────────────────────────
        ▸ [X/N] <feature listesi>
          src/<çağıran_modül>.py
          <kaynak URL · seri kodu · yöntem>
        ────────────────────────────────────────────────────────────
    Çağıran modülün dosya adı sys._getframe ile otomatik tespit edilir
    (hata olursa hangi .py dosyasında olduğu net görünür).
    """
    _step_state["i"] += 1
    total = _step_state["total"]
    tag = f"[{_step_state['i']}/{total}] " if total else ""

    # Çağıran dosyayı tespit et
    try:
        caller_path = sys._getframe(1).f_code.co_filename
        caller = Path(caller_path).relative_to(Path.cwd())
    except (ValueError, AttributeError):
        caller = Path(sys._getframe(1).f_code.co_filename).name

    print(f"\n{_BORDER}")
    print(f"▸ {tag}{feature}")
    print(f"  {caller}")
    print(f"  {kaynak}")
    print(_BORDER)

def read_firast():
    """
    FIRAST.xlsx dosyasını okur. Başlık satırı konumu farklı olabilir
    (header=1 varsayılan, header=2 veya header=0 fallback).
    """
    if not os.path.exists(FIRAST_PATH):
        return None

    for header in (1, 2, 0):
        try:
            df = pd.read_excel(FIRAST_PATH, header=header)
            if 'Min_Tarih' in df.columns and 'Max_Tarih' in df.columns:
                return df
        except Exception:
            continue

    return pd.DataFrame()

def save_firast(df):
    """
    Saves the DataFrame to FIRAST.xlsx preserving the custom layout.
    Structure:
    Row 1: Empty
    Row 2: "FIRAST" Title (Merged, Orange BG, White Text)
    Row 3: Headers
    Row 4+: Data
    """

    # We need to preserve 'Details' sheet if it exists
    existing_sheets = {}
    if os.path.exists(FIRAST_PATH):
        try:
            xls = pd.ExcelFile(FIRAST_PATH)
            if 'Details' in xls.sheet_names:
                existing_sheets['Details'] = xls.parse('Details')
        except:
            pass

    with pd.ExcelWriter(FIRAST_PATH, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, startrow=2, sheet_name='Sheet1')

        # Restore Details sheet
        if 'Details' in existing_sheets:
            existing_sheets['Details'].to_excel(writer, index=False, sheet_name='Details')

    # 2. Apply Formatting with OpenPyXL
    wb = load_workbook(FIRAST_PATH)
    ws = wb['Sheet1']

    max_col = len(df.columns)

    # Merge A2 to {MaxCol}2
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=max_col)

    # Set Value
    title_cell = ws.cell(row=2, column=1)
    title_cell.value = "FIRAST"

    # Style — Background: (255, 98, 0) -> Hex: FF6200
    orange_fill = PatternFill(start_color="FF6200", end_color="FF6200", fill_type="solid")
    white_font = Font(color="FFFFFF", bold=True, size=14)
    center_align = Alignment(horizontal="center", vertical="center")

    title_cell.fill = orange_fill
    title_cell.font = white_font
    title_cell.alignment = center_align

    # 3. Apply Column Formatting
    # Find 'PP_Getiri' column
    header_row = ws[3]
    pp_col_idx = None
    for cell in header_row:
        if cell.value == "PP_Getiri":
            pp_col_idx = cell.column
            break

    if pp_col_idx:
        for row in range(4, ws.max_row + 1):
            cell = ws.cell(row=row, column=pp_col_idx)
            cell.number_format = '0.000000'   # Ondalık format (örn. 0.008500)

    wb.save(FIRAST_PATH)
