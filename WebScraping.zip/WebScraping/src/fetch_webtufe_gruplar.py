"""
fetch_webtufe_gruplar.py
------------------------
WebTUFE günlük endeks ve açlık sınırı verilerini çekerek FIRAST.xlsx'e yazar.

Eklenen kolonlar:
  WebTufe_Gida_Endeks      : Gıda endeksi haftalık ort.
  WebTufe_Enerji_Endeks    : Konut/Su/Elektrik/Gaz endeksi haftalık ort.
  WebTufe_Ulastirma_Endeks : Ulaştırma endeksi haftalık ort.
  WebTufe_Hizmet_Endeks    : Lokantalar ve konaklama endeksi haftalık ort.
  WebTufe_Giyim_Endeks     : Giyim ve ayakkabı endeksi haftalık ort.
  WebTufe_Aclik_Siniri     : Günlük açlık sınırı (TL) haftalık ort.
"""

import io
import requests
import pandas as pd
from datetime import date
from src.utils import read_firast, save_firast, log_baslik

URL = "https://www.apiwebtufe.com/api/v1/download/gruplar/index/csv"
ACLIK_URL = "https://www.apiwebtufe.com/api/v1/aclik-siniri"

COL_MAP = {
    "Gıda ve alkolsüz içecekler":                              "WebTufe_Gida_Endeks",
    "Konut,Su,Elektrik,Gaz ve Diğer Yakıtlar":                 "WebTufe_Enerji_Endeks",
    "Ulaştırma":                                                "WebTufe_Ulastirma_Endeks",
    "Lokantalar ve konaklama hizmetleri":                       "WebTufe_Hizmet_Endeks",
    "Giyim ve ayakkabı":                                        "WebTufe_Giyim_Endeks",
    "Web TÜFE":                                                 "WebTufe_Endeks",
    "Kişisel bakım,sosyal koruma ve çeşitli mal ve hizmetler":  "WebTufe_KisiselBakim_Endeks",
}


def fetch_webtufe_gruplar():
    log_baslik(
        "WebTufe_{Gida,Enerji,Ulastirma,Hizmet,Giyim,KisiselBakim}_Endeks, WebTufe_Aclik_Siniri",
        "https://www.apiwebtufe.com/api/v1/download/gruplar/index/csv + /aclik-siniri · günlük",
    )
    df_firast = read_firast()
    if df_firast is None or df_firast.empty:
        print("  FIRAST.xlsx bulunamadı.")
        return

    df_firast["Min_Tarih"] = pd.to_datetime(df_firast["Min_Tarih"], dayfirst=True, errors="coerce")
    df_firast["Max_Tarih"] = pd.to_datetime(df_firast["Max_Tarih"], dayfirst=True, errors="coerce")

    # ── Ana grup endeks CSV ────────────────────────────────────────
    try:
        r = requests.get(URL, timeout=15)
        r.raise_for_status()
    except Exception as e:
        print(f"  ⚠ Ana grup API hatası: {e}")
    else:
        df_src = pd.read_csv(io.StringIO(r.text))
        df_src["date"] = pd.to_datetime(df_src["date"], errors="coerce")
        df_src = df_src.dropna(subset=["date"]).sort_values("date").reset_index(drop=True)
        print(f"  {len(df_src)} günlük kayıt "
              f"({df_src['date'].min().strftime('%Y-%m-%d')} → {df_src['date'].max().strftime('%Y-%m-%d')})")

        for firast_col in COL_MAP.values():
            if firast_col not in df_firast.columns:
                df_firast[firast_col] = None

        for src_col, firast_col in COL_MAP.items():
            if src_col not in df_src.columns:
                print(f"  ⚠ '{src_col}' bulunamadı.")
                continue
            daily = df_src.set_index("date")[src_col].dropna()
            updated = 0
            last_2_idx = set(df_firast.index[-2:])
            for idx, row in df_firast.iterrows():
                # Artımsal: dolu satırları atla, son 2 hafta hariç
                if pd.notna(row.get(firast_col)) and idx not in last_2_idx:
                    continue
                r_start, r_end = row["Min_Tarih"], row["Max_Tarih"]
                if pd.isna(r_start) or pd.isna(r_end):
                    continue
                subset = daily.loc[(daily.index >= r_start) & (daily.index <= r_end)].dropna()
                if not subset.empty:
                    df_firast.at[idx, firast_col] = round(subset.mean(), 4)
                    updated += 1
            print(f"  {firast_col}: {updated} satır güncellendi.")

    # ── Açlık Sınırı ──────────────────────────────────────────────
    print("\n  → Açlık Sınırı (TL, günlük)...")
    col = "WebTufe_Aclik_Siniri"
    if col not in df_firast.columns:
        df_firast[col] = None

    try:
        ra = requests.get(ACLIK_URL, timeout=15)
        ra.raise_for_status()
        data = ra.json()
    except Exception as e:
        print(f"    ⚠ Açlık sınırı API hatası: {e}")
        data = []

    if data and isinstance(data, list):
        values = [float(item.get("Açlık Sınırı", "nan")) for item in data]
        n = len(values)
        # API tarih döndürmüyor — son kayıt bugüne karşılık gelir
        end_date = pd.Timestamp(date.today())
        dates = pd.date_range(end=end_date, periods=n, freq="D")
        daily_aclik = pd.Series(values, index=dates)
        print(f"    {n} kayıt ({daily_aclik.index[0].strftime('%Y-%m-%d')} → "
              f"{daily_aclik.index[-1].strftime('%Y-%m-%d')}, "
              f"son: {values[-1]:,.0f} TL)")

        updated = 0
        last_2_idx = set(df_firast.index[-2:])
        for idx, row in df_firast.iterrows():
            # Artımsal: dolu satırları atla, son 2 hafta hariç
            if pd.notna(row.get(col)) and idx not in last_2_idx:
                continue
            r_start, r_end = row["Min_Tarih"], row["Max_Tarih"]
            if pd.isna(r_start) or pd.isna(r_end):
                continue
            subset = daily_aclik.loc[
                (daily_aclik.index >= r_start) & (daily_aclik.index <= r_end)
            ].dropna()
            if not subset.empty:
                df_firast.at[idx, col] = round(subset.mean(), 2)
                updated += 1
        print(f"    {col}: {updated} satır güncellendi.")

    # Tarih sütunlarını geri yükle
    for c in ["Min_Tarih", "Max_Tarih"]:
        if pd.api.types.is_datetime64_any_dtype(df_firast[c]):
            df_firast[c] = df_firast[c].dt.strftime("%d.%m.%Y")

    save_firast(df_firast)
if __name__ == "__main__":
    fetch_webtufe_gruplar()
