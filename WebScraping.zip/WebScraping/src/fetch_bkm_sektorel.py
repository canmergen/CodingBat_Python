"""
fetch_bkm_sektorel.py
---------------------
BKM (Bankalararası Kart Merkezi) sektörel aylık kart harcama verilerini
çekerek FIRAST.xlsx'e yazar.

Kaynak: https://bkm.com.tr/secilen-sektore-gore-aylik-gelisim/?filter_group={id}&List=Listele

Eklenen kolonlar (Milyon TL, toplam banka + kredi kartı tutarı):
  BKM_Giyim_TL      : Grup 11 — Giyim ve Aksesuar (Discretionary/Greenspan proxy)
  BKM_Yemek_TL      : Grup 10 — Yemek/Restoran (Service Economy proxy)
  BKM_Saglik_Kozmetik_TL : Grup 9  — Sağlık/Kozmetik (Lipstick Effect proxy)
"""

import requests
import pandas as pd
from bs4 import BeautifulSoup
from src.utils import read_firast, save_firast, log_baslik

BASE_URL = (
    "https://bkm.com.tr/secilen-sektore-gore-aylik-gelisim/"
    "?filter_group={grp}&List=Listele"
)

HEADERS = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"}

GROUPS = {
    11: "BKM_Giyim_TL",
    10: "BKM_Yemek_TL",
    9:  "BKM_Saglik_Kozmetik_TL",
}

AYLAR = {
    "OCAK": 1, "ŞUBAT": 2, "MART": 3, "NİSAN": 4,
    "MAYIS": 5, "HAZİRAN": 6, "TEMMUZ": 7, "AĞUSTOS": 8,
    "EYLÜL": 9, "EKİM": 10, "KASIM": 11, "ARALIK": 12,
}


def _parse_number(s: str) -> float:
    """BKM formatındaki sayıyı float'a çevirir: '83.259,77' → 83259.77"""
    s = s.strip().replace(".", "").replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return float("nan")


def _scrape_group(grp_id: int) -> pd.Series:
    """Bir grup için tüm ayların TOPLAM TL tutarını çeker (Milyon TL)."""
    url = BASE_URL.format(grp=grp_id)
    r = requests.get(url, timeout=15, headers=HEADERS)
    r.raise_for_status()

    soup = BeautifulSoup(r.text, "html.parser")
    tables = soup.find_all("table")

    records = []
    for table in tables:
        # Yıl başlığını bul
        header = table.find("th", class_="main_title")
        if not header:
            continue
        header_text = header.get_text(strip=True)
        try:
            year = int(header_text.split()[0])
        except (ValueError, IndexError):
            continue

        # Veri satırları: her `tr` → [Dönem, BK_İşlemAdedi, KK_İşlemAdedi, BK_Tutar, KK_Tutar]
        for row in table.find_all("tr"):
            cells = row.find_all("td")
            if len(cells) < 5:
                continue
            ay_str = cells[0].get_text(strip=True).upper()
            if ay_str not in AYLAR:
                continue
            month = AYLAR[ay_str]
            bk_tutar = _parse_number(cells[3].get_text(strip=True))
            kk_tutar = _parse_number(cells[4].get_text(strip=True))
            total = bk_tutar + kk_tutar
            date = pd.Timestamp(year=year, month=month, day=1)
            records.append((date, total))

    if not records:
        return pd.Series(dtype=float)

    s = pd.Series({d: v for d, v in records}).sort_index()
    return s


def fetch_bkm_sektorel():
    log_baslik(
        "BKM_Giyim_TL, BKM_Yemek_TL, BKM_Saglik_Kozmetik_TL",
        "https://bkm.com.tr/secilen-sektore-gore-aylik-gelisim · aylık sektörel kart harcaması",
    )
    df_firast = read_firast()
    if df_firast is None or df_firast.empty:
        print("  FIRAST.xlsx bulunamadı.")
        return

    df_firast["Min_Tarih"] = pd.to_datetime(df_firast["Min_Tarih"], dayfirst=True, errors="coerce")
    df_firast["Max_Tarih"] = pd.to_datetime(df_firast["Max_Tarih"], dayfirst=True, errors="coerce")
    max_date = df_firast["Max_Tarih"].max()

    for grp_id, col_name in GROUPS.items():
        print(f"\n  → Grup {grp_id} ({col_name})...")

        if col_name not in df_firast.columns:
            df_firast[col_name] = None

        try:
            monthly = _scrape_group(grp_id)
        except Exception as e:
            print(f"    ⚠ Hata: {e}")
            continue

        if monthly.empty:
            print("    ⚠ Veri alınamadı.")
            continue

        print(f"    {len(monthly)} aylık kayıt alındı "
              f"({monthly.index.min().strftime('%Y-%m')} → {monthly.index.max().strftime('%Y-%m')})")

        # Aylık değerleri günlük indekse yalnızca kendi yayın tarihlerinde yerleştir
        daily_idx = pd.date_range(monthly.index[0], max_date, freq="D")
        daily = monthly.reindex(daily_idx)

        updated = 0
        last_2_idx = set(df_firast.index[-2:])
        for idx, row in df_firast.iterrows():
            # Artımsal: dolu satırları atla, son 2 hafta hariç
            if pd.notna(row.get(col_name)) and idx not in last_2_idx:
                continue
            r_start = row["Min_Tarih"]
            r_end = row["Max_Tarih"]
            if pd.isna(r_start) or pd.isna(r_end):
                continue
            subset = daily.loc[(daily.index >= r_start) & (daily.index <= r_end)].dropna()
            if not subset.empty:
                df_firast.at[idx, col_name] = round(subset.mean(), 2)
                updated += 1

        print(f"    {updated} satır güncellendi.")

    # Tarih sütunlarını geri yükle
    for col in ["Min_Tarih", "Max_Tarih"]:
        if pd.api.types.is_datetime64_any_dtype(df_firast[col]):
            df_firast[col] = df_firast[col].dt.strftime("%d.%m.%Y")

    save_firast(df_firast)
if __name__ == "__main__":
    fetch_bkm_sektorel()
