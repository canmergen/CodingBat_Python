"""
build_firast_model.py
---------------------
FIRAST.xlsx'i okur, boşlukları feature-ilişki bazlı yöntemlerle doldurur
ve FIRAST_MODEL.xlsx olarak kaydeder.

Temel kural: SON SATIR (cari hafta) asla dokunulmaz — pipeline o haftanın
verisini günü geldikçe çeker, fill yapmak sahte leakage yaratır.

Fill stratejileri:
  CROSS_FEATURE_SPREAD   Benchmark = TLREF + rolling 8-hafta median spread
  CROSS_FEATURE_RATIO    Benchmark_All = Benchmark × median oran (2026 Şub+)
                         WebTufe_TUFE_Aylik (ilk 18 hafta) = TUIK_TUFE_Aylik × ratio
                         Cekirdek_Enflasyon = WebTufe_TUFE_Aylik × ratio
  EXTRAPOLATION          WebTufe_Endeks ilk 13 hafta = TUIK_TUFE_Aylik cumprod (geri)
  SEASONAL_DELTA         Issizlik = last + (aynı_ay_yıl-1 − aynı_ay_yıl-2)
  INFLATION_GROWTH       BKM_*_TL = last × (WebTufe_Endeks_t / WebTufe_Endeks_last)
  FFILL                  Aylık EVDS (KKO, Tuketici_Guven, Sanayi_Uretim,
                         Fin_Guven + S02-S16, Enflasyon_Beklenti_12ay,
                         GSYH_Buyume_Beklenti, TUIK_TUFE_*, Ihtiyac_Kredi_Faizi)
                         + izole piyasa boşlukları (CDS_5Y, Kur_Vol, BIST_Vol)
  NaN BIRAK              USDT_TRY_Hacim (ilk 29), WebTufe_TUFE_Yillik (ilk 65),
                         WebTufe alt endeksleri (ilk 13), WebTufe_Aclik_Siniri (ilk 4)
  RECOMPUTE              Türetilmiş feature'lar ham kolonlar dolunca yeniden hesap
"""

import os
import pandas as pd
import numpy as np
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment

from src.utils import read_firast, log_baslik


OUTPUT_PATH = "FIRAST_MODEL.xlsx"

FFILL_COLS = [
    "KKO", "Tuketici_Guven", "Sanayi_Uretim",
    "Enflasyon_Beklenti_12ay", "GSYH_Buyume_Beklenti",
    "Fin_Guven",
    *[f"Fin_Guven_S{i:02d}" for i in range(2, 17)],
    "TUIK_TUFE_Yillik",
    "Kur_Vol", "BIST_Vol",
    "Ihtiyac_Kredi_Faizi", "Ticari_Kredi",
    "TCMB_Mevduat_1M", "TCMB_Mevduat_3M",
    "TCMB_Mevduat_1M_Onceki_Hafta", "TCMB_Mevduat_3M_Onceki_Hafta",
]

# ffill + bfill (yavaş değişen seriler; ilk haftalar NaN olursa bfill geriye yayar)
FFILL_BFILL_COLS = [
    "TUIK_TUFE_Aylik",
    "CDS_5Y",
]

# WebTufe alt endeksleri: WebTufe_Endeks × median(alt/genel ratio) + ffill/bfill fallback
WEBTUFE_ALT_ENDEKS = [
    "WebTufe_Gida_Endeks", "WebTufe_Enerji_Endeks",
    "WebTufe_Ulastirma_Endeks", "WebTufe_Hizmet_Endeks",
    "WebTufe_Giyim_Endeks", "WebTufe_KisiselBakim_Endeks",
]



# ═══ Fill implementations ══════════════════════════════════════════════

def _fill_benchmark(df, col="Benchmark", donor="TLREF", window=8):
    bm = pd.to_numeric(df[col], errors="coerce")
    tl = pd.to_numeric(df[donor], errors="coerce")
    spread = bm - tl
    rolling_spread = spread.rolling(window=window, min_periods=2).median()
    # Baştaki rolling NaN'leri genel median ile ilk tanım: global median fallback
    global_spread = spread.median()
    rolling_spread = rolling_spread.fillna(global_spread)
    mask = bm.isna() & tl.notna() & rolling_spread.notna()
    df.loc[mask, col] = (tl + rolling_spread).loc[mask].round(4)
    return int(mask.sum())


def _fill_benchmark_all(df, col="Benchmark_All", donor="Benchmark"):
    bm_all = pd.to_numeric(df[col], errors="coerce")
    bm = pd.to_numeric(df[donor], errors="coerce")
    both = bm_all.notna() & bm.notna() & (bm != 0)
    if both.sum() < 2:
        return 0
    ratio = (bm_all[both] / bm[both]).median()
    mask = bm_all.isna() & bm.notna()
    df.loc[mask, col] = (bm * ratio).loc[mask].round(4)
    return int(mask.sum())


def _fill_ratio_from_donor(df, col, donor):
    target = pd.to_numeric(df[col], errors="coerce")
    don = pd.to_numeric(df[donor], errors="coerce")
    both = target.notna() & don.notna() & (don != 0)
    if both.sum() < 2:
        return 0
    ratio = (target[both] / don[both]).median()
    mask = target.isna() & don.notna()
    df.loc[mask, col] = (don * ratio).loc[mask].round(4)
    return int(mask.sum())


def _fill_webtufe_endeks_back(df, col="WebTufe_Endeks", driver="TUIK_TUFE_Aylik"):
    endeks = pd.to_numeric(df[col], errors="coerce").copy()
    tuik = pd.to_numeric(df[driver], errors="coerce")
    first_valid = endeks.first_valid_index()
    if first_valid is None or first_valid == 0:
        return 0
    filled = 0
    # Geriye doğru yürü: endeks_{i} = endeks_{i+1} / (1 + weekly_pct/100)
    for i in range(first_valid - 1, -1, -1):
        next_v = endeks.iloc[i + 1]
        if pd.isna(next_v):
            continue
        next_tuik = tuik.iloc[i + 1]
        monthly_pct = next_tuik if pd.notna(next_tuik) else 0
        weekly_pct = monthly_pct / 4.33
        endeks.iloc[i] = round(next_v / (1 + weekly_pct / 100), 4)
        filled += 1
    df[col] = endeks
    return filled


def _fill_bkm(df, col, endeks_col="WebTufe_Endeks"):
    """Forward + backward enflasyon-adjusted growth.
    BKM_t = last × (Endeks_t / Endeks_last)  — ileri
    BKM_{t-1} = BKM_t × (Endeks_{t-1} / Endeks_t)  — geri (ilk haftalar)"""
    bkm = pd.to_numeric(df[col], errors="coerce").copy()
    endeks = pd.to_numeric(df[endeks_col], errors="coerce")
    filled = 0
    # İleri yürüyüş
    last_val, last_endeks = np.nan, np.nan
    for i in range(len(df)):
        v, e = bkm.iloc[i], endeks.iloc[i]
        if pd.notna(v):
            last_val = v
            if pd.notna(e):
                last_endeks = e
        else:
            if pd.notna(last_val) and pd.notna(last_endeks) and pd.notna(e) and last_endeks != 0:
                bkm.iloc[i] = round(last_val * (e / last_endeks), 4)
                filled += 1
            elif pd.notna(last_val):
                bkm.iloc[i] = round(last_val, 4)
                filled += 1
    # Geri yürüyüş (ilk haftalar için)
    for i in range(len(df) - 2, -1, -1):
        if pd.notna(bkm.iloc[i]):
            continue
        next_v = bkm.iloc[i + 1]
        next_e = endeks.iloc[i + 1]
        cur_e = endeks.iloc[i]
        if pd.notna(next_v) and pd.notna(next_e) and pd.notna(cur_e) and next_e != 0:
            bkm.iloc[i] = round(next_v * (cur_e / next_e), 4)
            filled += 1
    df[col] = bkm
    return filled


def _ffill_bfill_col(df, col):
    s = pd.to_numeric(df[col], errors="coerce")
    n_before = s.isna().sum()
    df[col] = s.ffill().bfill()
    n_after = pd.to_numeric(df[col], errors="coerce").isna().sum()
    return int(n_before - n_after)


def _fill_ratio_with_fallback(df, col, donor):
    """Ratio fill + donor dolduysa kalan NaN'lere ffill/bfill."""
    n = _fill_ratio_from_donor(df, col, donor)
    s = pd.to_numeric(df[col], errors="coerce")
    before = s.isna().sum()
    df[col] = s.ffill().bfill()
    after = pd.to_numeric(df[col], errors="coerce").isna().sum()
    return n, int(before - after)


def _fill_issizlik_seasonal(df, col="Issizlik"):
    iz = pd.to_numeric(df[col], errors="coerce").copy()
    min_date = pd.to_datetime(df["Min_Tarih"], dayfirst=True, errors="coerce")
    tmp = pd.DataFrame({"date": min_date, "val": iz}).dropna()
    tmp["month"] = tmp["date"].dt.month
    tmp["year"] = tmp["date"].dt.year
    month_values = tmp.groupby(["year", "month"])["val"].first().reset_index()

    filled = 0
    last_val = np.nan
    for i in range(len(df)):
        v = iz.iloc[i]
        d = min_date.iloc[i]
        if pd.notna(v):
            last_val = v
            continue
        if pd.isna(d) or pd.isna(last_val):
            continue
        m, y = d.month, d.year
        prev_yr = month_values[(month_values["year"] == y - 1) & (month_values["month"] == m)]
        prev_prev = month_values[(month_values["year"] == y - 2) & (month_values["month"] == m)]
        if not prev_yr.empty and not prev_prev.empty:
            delta = prev_yr["val"].iloc[0] - prev_prev["val"].iloc[0]
            iz.iloc[i] = round(last_val + delta, 4)
        else:
            iz.iloc[i] = round(last_val, 4)
        filled += 1
    df[col] = iz
    return filled


def _ffill_col(df, col):
    s = pd.to_numeric(df[col], errors="coerce")
    n_before = s.isna().sum()
    df[col] = s.ffill()
    n_after = pd.to_numeric(df[col], errors="coerce").isna().sum()
    return int(n_before - n_after)


# ═══ Recompute derived features ════════════════════════════════════════

def _recompute_derived(df):
    # Reel_Faiz
    if "TLREF" in df.columns and "WebTufe_TUFE_Aylik" in df.columns:
        df["Reel_Faiz"] = (pd.to_numeric(df["TLREF"], errors="coerce") / 12
                           - pd.to_numeric(df["WebTufe_TUFE_Aylik"], errors="coerce")).round(4)
    # Faiz_Spread
    if "TCMB_Mevduat_1M" in df.columns and "TLREF" in df.columns:
        df["Faiz_Spread"] = (pd.to_numeric(df["TCMB_Mevduat_1M"], errors="coerce")
                             - pd.to_numeric(df["TLREF"], errors="coerce")).round(4)
    # Pct_change tipleri
    pct_map = {
        "BIST100_Getiri": "BIST100",
        "Altin_Getiri": "Gram_Altin_TRY",
        "Kur_Degisim": "USD_TRY",
        "Sepet_Kur_Degisim": "Sepet_Kur",
    }
    for tgt, src in pct_map.items():
        if src in df.columns:
            df[tgt] = pd.to_numeric(df[src], errors="coerce").pct_change().mul(100).round(4)

    # BKM reel / oran feature'ları
    if "BKM_Giyim_TL" in df.columns and "WebTufe_Giyim_Endeks" in df.columns:
        df["Reel_Giyim"] = (pd.to_numeric(df["BKM_Giyim_TL"], errors="coerce")
                            / pd.to_numeric(df["WebTufe_Giyim_Endeks"], errors="coerce")).round(4)
    if "BKM_Saglik_Kozmetik_TL" in df.columns and "BKM_Giyim_TL" in df.columns:
        df["Lipstick_Ratio"] = (pd.to_numeric(df["BKM_Saglik_Kozmetik_TL"], errors="coerce")
                                / pd.to_numeric(df["BKM_Giyim_TL"], errors="coerce")).round(4)
    if "BKM_Yemek_TL" in df.columns and "WebTufe_Hizmet_Endeks" in df.columns:
        df["Reel_Yemek"] = (pd.to_numeric(df["BKM_Yemek_TL"], errors="coerce")
                            / pd.to_numeric(df["WebTufe_Hizmet_Endeks"], errors="coerce")).round(4)
    if "BKM_Saglik_Kozmetik_TL" in df.columns and "WebTufe_KisiselBakim_Endeks" in df.columns:
        df["Reel_Kozmetik"] = (pd.to_numeric(df["BKM_Saglik_Kozmetik_TL"], errors="coerce")
                               / pd.to_numeric(df["WebTufe_KisiselBakim_Endeks"], errors="coerce")).round(4)

    # ENAG spread'leri
    if "WebTufe_Gida_Endeks" in df.columns and "WebTufe_Endeks" in df.columns:
        df["Gida_Spread"] = (pd.to_numeric(df["WebTufe_Gida_Endeks"], errors="coerce")
                             / pd.to_numeric(df["WebTufe_Endeks"], errors="coerce")).round(6)
    if "WebTufe_Enerji_Endeks" in df.columns and "WebTufe_Endeks" in df.columns:
        df["Enerji_Spread"] = (pd.to_numeric(df["WebTufe_Enerji_Endeks"], errors="coerce")
                               / pd.to_numeric(df["WebTufe_Endeks"], errors="coerce")).round(6)
    if "WebTufe_Hizmet_Endeks" in df.columns and "WebTufe_Gida_Endeks" in df.columns:
        df["Hizmet_vs_Gida"] = (pd.to_numeric(df["WebTufe_Hizmet_Endeks"], errors="coerce")
                                / pd.to_numeric(df["WebTufe_Gida_Endeks"], errors="coerce")).round(6)
    if all(c in df.columns for c in ["WebTufe_Gida_Endeks", "WebTufe_Enerji_Endeks", "WebTufe_Endeks"]):
        g = pd.to_numeric(df["WebTufe_Gida_Endeks"], errors="coerce")
        e = pd.to_numeric(df["WebTufe_Enerji_Endeks"], errors="coerce")
        gen = pd.to_numeric(df["WebTufe_Endeks"], errors="coerce")
        df["Zorunlu_Harcama_Baskisi"] = ((g + e) / (2 * gen)).round(6)


# ═══ Save with FIRAST title row format ════════════════════════════════

def _save_model(df, path):
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, startrow=2, sheet_name="Sheet1")

    wb = load_workbook(path)
    ws = wb["Sheet1"]
    max_col = len(df.columns)
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=max_col)
    title = ws.cell(row=2, column=1)
    title.value = "FIRAST_MODEL"
    title.fill = PatternFill(start_color="FF6200", end_color="FF6200", fill_type="solid")
    title.font = Font(color="FFFFFF", bold=True, size=14)
    title.alignment = Alignment(horizontal="center", vertical="center")

    # PP_Getiri ondalık format
    for cell in ws[3]:
        if cell.value == "PP_Getiri":
            pp_col = cell.column
            for row in range(4, ws.max_row + 1):
                ws.cell(row=row, column=pp_col).number_format = "0.000000"
            break
    wb.save(path)


# ═══ Main ══════════════════════════════════════════════════════════════

def build_firast_model():
    log_baslik(
        "FIRAST_MODEL.xlsx — feature-ilişki bazlı boşluk doldurma",
        "pipeline türetme · son satır (cari hafta) dokunulmaz",
    )
    df = read_firast()
    if df is None or df.empty:
        print("  ⚠ FIRAST.xlsx bulunamadı.")
        return

    n_rows = len(df)
    last_idx = n_rows - 1
    first_date = df["Min_Tarih"].iloc[0]
    last_date = df["Max_Tarih"].iloc[last_idx]
    print(f"  {n_rows} hafta · {first_date} → {last_date}")
    print(f"  Son satır (idx {last_idx}) dokunulmayacak — cari hafta")

    # Son satırı ayır, geri kalan üzerinde çalış
    last_row = df.iloc[[last_idx]].copy()
    work = df.iloc[:last_idx].reset_index(drop=True).copy()

    # 1) TUIK_TUFE_Aylik — ffill + bfill (ilk haftalar geç başladı, yavaş değişen seri)
    if "TUIK_TUFE_Aylik" in work.columns:
        n = _ffill_bfill_col(work, "TUIK_TUFE_Aylik")
        if n: print(f"  TUIK_TUFE_Aylik: {n} hafta ffill+bfill")

    # 2) WebTufe_Endeks ilk 13 hafta — TUIK_TUFE_Aylik cumprod geri
    if "WebTufe_Endeks" in work.columns and "TUIK_TUFE_Aylik" in work.columns:
        n = _fill_webtufe_endeks_back(work)
        if n: print(f"  WebTufe_Endeks: {n} hafta geriye extrapole (TUIK cumprod)")

    # 3) WebTufe_TUFE_Aylik — TUIK × ratio + ffill/bfill fallback
    if "WebTufe_TUFE_Aylik" in work.columns and "TUIK_TUFE_Aylik" in work.columns:
        n, extra = _fill_ratio_with_fallback(work, "WebTufe_TUFE_Aylik", "TUIK_TUFE_Aylik")
        if n: print(f"  WebTufe_TUFE_Aylik: {n} hafta (TUIK × ratio)")
        if extra: print(f"  WebTufe_TUFE_Aylik: {extra} hafta ek ffill+bfill")

    # 4) Cekirdek_Enflasyon — WebTufe_TUFE_Aylik × ratio + ffill/bfill fallback
    if "Cekirdek_Enflasyon" in work.columns and "WebTufe_TUFE_Aylik" in work.columns:
        n, extra = _fill_ratio_with_fallback(work, "Cekirdek_Enflasyon", "WebTufe_TUFE_Aylik")
        if n: print(f"  Cekirdek_Enflasyon: {n} hafta (WebTufe_TUFE_Aylik × ratio)")
        if extra: print(f"  Cekirdek_Enflasyon: {extra} hafta ek ffill+bfill")

    # 5) WebTufe alt endeksleri — WebTufe_Endeks × median(alt/genel) + ffill/bfill
    for col in WEBTUFE_ALT_ENDEKS:
        if col in work.columns and "WebTufe_Endeks" in work.columns:
            n, extra = _fill_ratio_with_fallback(work, col, "WebTufe_Endeks")
            if n: print(f"  {col}: {n} hafta (WebTufe_Endeks × ratio)")
            if extra: print(f"  {col}: {extra} hafta ek ffill+bfill")

    # 6) WebTufe_Aclik_Siniri — WebTufe_Gida_Endeks × ratio + ffill/bfill
    if "WebTufe_Aclik_Siniri" in work.columns and "WebTufe_Gida_Endeks" in work.columns:
        n, extra = _fill_ratio_with_fallback(work, "WebTufe_Aclik_Siniri", "WebTufe_Gida_Endeks")
        if n: print(f"  WebTufe_Aclik_Siniri: {n} hafta (WebTufe_Gida_Endeks × ratio)")
        if extra: print(f"  WebTufe_Aclik_Siniri: {extra} hafta ek ffill+bfill")

    # 7) Issizlik — seasonal delta
    if "Issizlik" in work.columns:
        n = _fill_issizlik_seasonal(work)
        if n: print(f"  Issizlik: {n} hafta (seasonal Δ + ffill fallback)")

    # 8) Benchmark — TLREF + rolling 8w median spread
    if "Benchmark" in work.columns and "TLREF" in work.columns:
        n = _fill_benchmark(work)
        if n: print(f"  Benchmark: {n} hafta (TLREF + rolling 8w median spread)")

    # 9) BKM_*_TL — enflasyon-adjusted growth (ileri + geri)
    for col in ["BKM_Giyim_TL", "BKM_Yemek_TL", "BKM_Saglik_Kozmetik_TL"]:
        if col in work.columns:
            n = _fill_bkm(work, col)
            if n: print(f"  {col}: {n} hafta (WebTufe_Endeks growth, ileri+geri)")

    # 10) Aylık EVDS + izole piyasa — ffill
    for col in FFILL_COLS:
        if col in work.columns:
            n = _ffill_col(work, col)
            if n > 0:
                print(f"  {col}: {n} hafta ffill")

    # 11) ffill + bfill (ilk haftalar geç başlayan yavaş değişen seriler)
    for col in FFILL_BFILL_COLS:
        if col in work.columns:
            n = _ffill_bfill_col(work, col)
            if n > 0:
                print(f"  {col}: {n} hafta ffill+bfill")

    # 12) Benchmark_All — Benchmark × ratio (tüm haftalar)
    if "Benchmark_All" in work.columns and "Benchmark" in work.columns:
        n = _fill_benchmark_all(work)
        if n: print(f"  Benchmark_All: {n} hafta (Benchmark × ratio)")

    # 13) Türetilmişleri yeniden hesapla
    # (pct_change tabanlı feature'ların ilk satırı doğası gereği NaN kalır —
    # 0 ile doldurmak sahte "değişim yok" sinyali verir, bilerek NaN bırakılır)
    _recompute_derived(work)
    print("  Türetilmişler yeniden hesaplandı")

    # Son satırı geri ekle
    result = pd.concat([work, last_row], ignore_index=True)

    # Tarih kolonları string kalsın (read_firast string döndürüyor)
    _save_model(result, OUTPUT_PATH)
    total_missing = result.isna().sum().sum()
    print(f"\n  → {OUTPUT_PATH}: {len(result)} hafta × {len(result.columns)} kolon · toplam NaN: {total_missing}")

    # Details sheet (feature kataloğu + NaN stratejisi + kalan NaN sayısı)
    from src.add_details_sheet import add_details_sheet_model
    add_details_sheet_model()


if __name__ == "__main__":
    build_firast_model()
