"""
update_calendar_features.py
---------------------------
Python mantığıyla takvim ve mevsimsellik dummy değişkenlerini oluşturur.
Harici veri gerektirmez — tamamen otomatik.

Oluşturulan değişkenler (pencere: Mon-Sun → hafta sonu edge-case'leri yakalar):
  Maaş & ödeme:
  - Payday                : Ay başı (1), ortası (15) veya ay son günü hafta içinde mi
  - Emekli_Maas_Donemi    : Ayın 17-25 arası (SGK emekli maaşı yayılım dönemi)
  - Tax_Season            : Vergi ödeme ayları ({3 Mart, 4 Nisan, 5 Mayıs, 7 Temmuz, 11 Kasım})
  - Ay_Sonu_Haftasi       : Ayın son 5 günü hafta içinde mi (bilanço kapama + şirket ödemeleri)

  Tatil & bayram:
  - Bayram_Haftasi        : Ramazan/Kurban Bayramı haftası
  - Bayram_Arefesi        : Bayramdan önceki 5 gün (nakit çekme zirvesi)
  - Bayram_Sonrasi        : Bayramdan sonraki 7 gün (mevduat geri dönüş)
  - Milli_Bayram_Haftasi  : Laik resmi tatiller (23 Nisan, 29 Ekim vb.)

  Mevsimsellik & okul:
  - Season, Month
  - YearEnd               : Aralık son 2 haftası
  - Okul_Tatili           : 15 Haz – 15 Eyl arası (yaz tatili)
  - Somestr_Tatili        : Ocak 20 – Şubat 3 arası (MEB yarıyıl tatili, 2 hafta)
  - Ara_Tatil             : Kasım 10-15 + Nisan 7-15 (MEB ara tatiller, 2016+)
  - Yaz_Turizm            : Mayıs-Ekim (sahil/resort döviz girişi)
  - Kis_Turizm            : Aralık-Mart (kayak merkezleri — iç turizm harcaması)

  Finansal takvim:
  - Quarter_End           : Mart/Haz/Eyl/Ara ayının son 1 haftası (day ≥ 25)
  - Temetu_Donemi         : 15 Nisan – 15 Haziran (BİST temettü yoğun dönemi)
  - PPK_Haftasi           : PPK toplantı haftası
  - PPK_Oncesi            : PPK toplantısından önceki 7 gün
  - PPK_Sonrasi           : PPK toplantısından sonraki 7 gün
  - Enflasyon_Aciklama_Haftasi : Ayın ilk 7 günü (TÜİK TÜFE 3. iş günü yayını)

  Perakende & tüketim:
  - Black_Friday          : Kasım 4. Perş + sonraki 7 gün (Cyber Monday yayılımı)

  Anomali:
  - Market_Anomaly, Faiz_Anomaly : z-score > 2σ bayrakları
"""

import calendar
from datetime import timedelta

import pandas as pd
from src.utils import read_firast, save_firast, log_baslik


def _is_payday(d) -> bool:
    """TR maaş ödeme günleri: ay başı (1), ay ortası (15), ay son günü."""
    if d.day in (1, 15):
        return True
    last_day = calendar.monthrange(d.year, d.month)[1]
    return d.day == last_day


def _is_ay_sonu(d) -> bool:
    """Ayın son 5 günü (bilanço kapama + şirket nakit ödemeleri)."""
    last_day = calendar.monthrange(d.year, d.month)[1]
    return d.day >= last_day - 4


# Vergi ödeme ayları — TR takvimi:
#  Mart (Gelir Vergisi 1. taksit beyanı/ödemesi)
#  Nisan (Kurumlar Vergisi)
#  Mayıs (Emlak 1. taksit + Kurumlar taksit)
#  Temmuz (Gelir Vergisi 2. taksit + MTV 2. taksit)
#  Kasım (Emlak 2. taksit)
TAX_MONTHS = {3, 4, 5, 7, 11}

# Ramazan Bayramı ve Kurban Bayramı'nı tanımlayan anahtar kelimeler (holidays lib)
BAYRAM_KEYWORDS = {"kurban", "ramazan bayram", "şeker bayram", "eid"}


def _auto_ramazan(years):
    """
    hijridate ile verilen Gregoryen yıllara denk gelen tüm Ramazan
    aralıklarını (başlangıç, bitiş) döndürür. 2030 gibi yılda 2 Ramazan
    görülen durumları da yakalar.
    """
    try:
        from hijridate import Hijri, Gregorian
    except ImportError:
        return []
    ranges = []
    year_set = set(years)
    # Yılı kapsayan Hijri yıllarını bul (Gregorian↔Hijri roundtrip)
    candidate_hy = set()
    for gy in year_set:
        try:
            candidate_hy.add(Gregorian(gy, 1, 1).to_hijri().year)
            candidate_hy.add(Gregorian(gy, 12, 31).to_hijri().year)
        except Exception:
            pass
    for hy in sorted(candidate_hy):
        try:
            s = Hijri(hy, 9, 1).to_gregorian()
            e = None
            for d in (30, 29):
                try:
                    e = Hijri(hy, 9, d).to_gregorian()
                    break
                except ValueError:
                    continue
            if e is None:
                continue
            if s.year in year_set or e.year in year_set:
                ranges.append((pd.Timestamp(s.isoformat()), pd.Timestamp(e.isoformat())))
        except Exception as ex:
            print(f"  Ramazan hesaplama hatası (Hijri {hy}): {ex}")
    return ranges


def _get_season(month: int) -> int:
    if month in (12, 1, 2):  return 1  # Kış
    if month in (3, 4, 5):   return 2  # İlkbahar
    if month in (6, 7, 8):   return 3  # Yaz
    return 4                            # Sonbahar


def _build_black_friday_dates(years) -> set:
    """
    Kara Cuma dönemi: Kasım 4. Perşembe + sonraki 7 gün
    (Cyber Monday ve erken yılbaşı kampanyalarını da kapsar).
    """
    dates = set()
    for yr in years:
        thursdays = [d for d in pd.date_range(f"{yr}-11-01", f"{yr}-11-30")
                     if d.dayofweek == 3]
        if len(thursdays) >= 4:
            base = thursdays[3].date()
            for i in range(8):  # Perş + 7 gün
                dates.add(base + timedelta(days=i))
    return dates


def _build_bayram_arefesi_set(bayram_dates: set, days_before: int = 5) -> set:
    """Her bayram grubunun başlangıcından önceki `days_before` günü döndürür."""
    arefesi = set()
    sorted_dates = sorted(bayram_dates)
    if not sorted_dates:
        return arefesi
    # Bayram ardışık günler grubunun BAŞLANGIÇLARINI bul
    group_starts = [sorted_dates[0]]
    for i in range(1, len(sorted_dates)):
        if (sorted_dates[i] - sorted_dates[i-1]).days > 1:
            group_starts.append(sorted_dates[i])
    for start in group_starts:
        for i in range(1, days_before + 1):
            arefesi.add(start - timedelta(days=i))
    return arefesi


def _build_bayram_sonrasi_set(bayram_dates: set, days_after: int = 7) -> set:
    """Her bayram grubunun son gününden sonraki `days_after` günü döndürür."""
    sonrasi = set()
    sorted_dates = sorted(bayram_dates)
    if not sorted_dates:
        return sonrasi
    group_ends = []
    for i, d in enumerate(sorted_dates):
        is_last = (i == len(sorted_dates) - 1
                   or (sorted_dates[i+1] - d).days > 1)
        if is_last:
            group_ends.append(d)
    for end in group_ends:
        for j in range(1, days_after + 1):
            sonrasi.add(end + timedelta(days=j))
    return sonrasi


def _build_ppk_ring_sets(ppk_dates: set, days: int = 7):
    """PPK her toplantısının -days ve +days gün penceresini ayrı set olarak döndürür."""
    oncesi, sonrasi = set(), set()
    for d in ppk_dates:
        for i in range(1, days + 1):
            oncesi.add(d - timedelta(days=i))
            sonrasi.add(d + timedelta(days=i))
    return oncesi, sonrasi


def _build_bayram_dates(tr_holidays: dict) -> set:
    """Holidays dict'ten Kurban / Ramazan Bayramı tarihleri çıkarır."""
    bayram = set()
    for d, name in tr_holidays.items():
        name_lower = name.lower()
        if any(kw in name_lower for kw in BAYRAM_KEYWORDS):
            bayram.add(d)
    return bayram


def _build_milli_bayram_dates(tr_holidays: dict) -> set:
    """Resmi tatillerden dini bayramları çıkarır → milli/laik tatiller."""
    milli = set()
    for d, name in tr_holidays.items():
        name_lower = name.lower()
        if not any(kw in name_lower for kw in BAYRAM_KEYWORDS):
            milli.add(d)
    return milli


def update_calendar_features(ppk_dates=None):
    log_baslik(
        "Payday, Emekli_Maas_Donemi, Tax_Season, Ay_Sonu_Haftasi, Bayram_Haftasi/Arefesi/Sonrasi, Milli_Bayram_Haftasi, Season/Month/YearEnd, Okul_Tatili/Somestr_Tatili/Ara_Tatil, Yaz/Kis_Turizm, Temetu_Donemi, PPK_Haftasi/Oncesi/Sonrasi, Enflasyon_Aciklama_Haftasi, Black_Friday, Quarter_End, Ramazan, Market/Faiz_Anomaly",
        "internal · holidays.Turkey + hijridate + fetch_ppk_dates çıktısı (harici kaynak yok)",
    )
    # ── FIRAST yükle ────────────────────────────────────────────────
    df = read_firast()
    if df is None or df.empty:
        print("FIRAST.xlsx bulunamadı.")
        return

    df["Min_Tarih"] = pd.to_datetime(df["Min_Tarih"], dayfirst=True, errors="coerce")
    df["Max_Tarih"] = pd.to_datetime(df["Max_Tarih"], dayfirst=True, errors="coerce")

    all_years = set(df["Min_Tarih"].dropna().dt.year.tolist() +
                    df["Max_Tarih"].dropna().dt.year.tolist())

    # ── Ramazan tarihleri (hijridate ile FIRAST yıllarına göre) ─────
    effective_ramazan = _auto_ramazan(all_years)
    if effective_ramazan:
        print(f"  Ramazan tarihleri otomatik (hijridate): "
              f"{[(str(s.date()), str(e.date())) for s, e in effective_ramazan]}")
    else:
        print("  ⚠ Ramazan tarihi hesaplanamadı (hijridate kurulu mu?)")

    # ── Tatil kütüphanesi ─────────────────────────────────────────
    try:
        from src.holidays import get_tr_holidays
        tr_holidays = get_tr_holidays()
    except ImportError:
        try:
            import holidays as hol_lib
            tr_holidays = hol_lib.Turkey(years=list(all_years))
        except ImportError:
            print("  ⚠ holidays modülü bulunamadı.")
            tr_holidays = {}

    # ── Tarih setleri (satır satır lookup için) ───────────────────
    black_friday_dates = _build_black_friday_dates(all_years)
    bayram_dates       = _build_bayram_dates(tr_holidays)
    milli_dates        = _build_milli_bayram_dates(tr_holidays)
    bayram_arefesi     = _build_bayram_arefesi_set(bayram_dates, days_before=5)
    bayram_sonrasi     = _build_bayram_sonrasi_set(bayram_dates, days_after=7)

    # PPK tarihlerini date set'e dönüştür (datetime.date veya string kabul eder)
    import datetime as _dt
    ppk_date_set = set()
    if ppk_dates:
        for item in ppk_dates:
            if isinstance(item, _dt.date):
                ppk_date_set.add(item)
            else:
                try:
                    ppk_date_set.add(pd.to_datetime(item, dayfirst=True).date())
                except Exception:
                    pass

    ppk_oncesi_set, ppk_sonrasi_set = _build_ppk_ring_sets(ppk_date_set, days=7)

    # ── Tüm kolonları hazırla ─────────────────────────────────────
    all_cols = [
        "Payday", "Emekli_Maas_Donemi", "Tax_Season", "Ay_Sonu_Haftasi",
        "Resmi_Tatil_Haftasi", "Bayram_Haftasi", "Bayram_Arefesi", "Bayram_Sonrasi",
        "Milli_Bayram_Haftasi",
        "Season", "Month", "YearEnd",
        "Okul_Tatili", "Somestr_Tatili", "Ara_Tatil",
        "Quarter_End", "Ramazan",
        "Black_Friday",
        "Yaz_Turizm", "Kis_Turizm", "Temetu_Donemi",
        "PPK_Haftasi", "PPK_Oncesi", "PPK_Sonrasi",
        "Enflasyon_Aciklama_Haftasi",
        "Market_Anomaly", "Faiz_Anomaly",
    ]
    for col in all_cols:
        if col not in df.columns:
            df[col] = 0

    # ── Satır satır doldur ────────────────────────────────────────
    updated = 0
    for idx, row in df.iterrows():
        r_start = row["Min_Tarih"]
        r_end   = row["Max_Tarih"]
        if pd.isna(r_start) or pd.isna(r_end):
            continue

        days_in_week  = pd.date_range(r_start, r_end, freq="D")
        # Tatil tespitinde Cmt+Paz'ı da dahil et (23 Nisan/29 Ekim hafta sonuna
        # düştüğünde pre-holiday nakit hareketi Per-Cum'da yaşanır)
        days_full_week = pd.date_range(r_start, r_end + pd.Timedelta(days=2), freq="D")
        mid_date      = r_start + (r_end - r_start) / 2
        month         = mid_date.month
        week_of_month = (mid_date.day - 1) // 7 + 1   # 1. - 5. hafta

        # ── Payday (TR: ay başı, ay ortası, ay sonu — Mon-Sun pencere) ──
        df.at[idx, "Payday"] = int(any(_is_payday(d) for d in days_full_week))

        # ── Emekli_Maas_Donemi (SGK: ayın 17-25 arası, TC son rakamına göre dağıtık) ──
        df.at[idx, "Emekli_Maas_Donemi"] = int(
            any(17 <= d.day <= 25 for d in days_full_week)
        )

        # ── Tax_Season ({3, 4, 5, 7, 11}) ────────────────────────
        df.at[idx, "Tax_Season"] = int(month in TAX_MONTHS)

        # ── Ay_Sonu_Haftasi (ayın son 5 günü hafta içinde mi) ───
        df.at[idx, "Ay_Sonu_Haftasi"] = int(any(_is_ay_sonu(d) for d in days_full_week))

        # ── Season & Month ───────────────────────────────────────
        df.at[idx, "Season"] = _get_season(month)
        df.at[idx, "Month"]  = month

        # ── YearEnd ──────────────────────────────────────────────
        df.at[idx, "YearEnd"] = int(month == 12 and mid_date.day >= 15)

        # ── Okul_Tatili (15 Haz – 15 Eyl) ────────────────────────
        okul_tatili = 0
        for d in days_full_week:
            if (d.month == 6 and d.day >= 15) or d.month in (7, 8) \
               or (d.month == 9 and d.day <= 15):
                okul_tatili = 1
                break
        df.at[idx, "Okul_Tatili"] = okul_tatili

        # ── Somestr_Tatili (Ocak 20 – Şubat 3) — MEB yarıyıl tatili, 2 hafta ──
        somestr = 0
        for d in days_full_week:
            if (d.month == 1 and d.day >= 20) or (d.month == 2 and d.day <= 3):
                somestr = 1
                break
        df.at[idx, "Somestr_Tatili"] = somestr

        # ── Ara_Tatil (Kasım 10-15 + Nisan 7-15 — MEB ara tatilleri) ──
        ara = 0
        for d in days_full_week:
            if (d.month == 11 and 10 <= d.day <= 15) \
               or (d.month == 4 and 7 <= d.day <= 15):
                ara = 1
                break
        df.at[idx, "Ara_Tatil"] = ara

        # ── Quarter_End (day >= 25 — ayın son haftası) ──────────
        df.at[idx, "Quarter_End"] = int(month in (3, 6, 9, 12) and mid_date.day >= 25)

        # ── Ramazan (Mon-Sun pencere — son gün Cmt/Paz'a düşerse yakalar) ──
        r_end_full = r_end + pd.Timedelta(days=2)
        ramazan = 0
        for rm_start, rm_end in effective_ramazan:
            if r_start <= rm_end and r_end_full >= rm_start:
                ramazan = 1
                break
        df.at[idx, "Ramazan"] = ramazan

        # ── Bayram_Haftasi (dini) ────────────────────────────────
        df.at[idx, "Bayram_Haftasi"] = int(
            any(d.date() in bayram_dates for d in days_full_week)
        )

        # ── Bayram_Arefesi (bayramdan -5 gün) — nakit çekme zirvesi ──
        df.at[idx, "Bayram_Arefesi"] = int(
            any(d.date() in bayram_arefesi for d in days_full_week)
        )

        # ── Bayram_Sonrasi (bayramdan +7 gün) — mevduat geri dönüş ──
        df.at[idx, "Bayram_Sonrasi"] = int(
            any(d.date() in bayram_sonrasi for d in days_full_week)
        )

        # ── Milli_Bayram_Haftasi (laik resmi tatiller) ───────────
        df.at[idx, "Milli_Bayram_Haftasi"] = int(
            any(d.date() in milli_dates for d in days_full_week)
        )

        # ── Black_Friday (Kasım 4. Perş + sonraki 7 gün) ─────────
        df.at[idx, "Black_Friday"] = int(
            any(d.date() in black_friday_dates for d in days_full_week)
        )

        # ── Yaz_Turizm (Mayıs-Ekim — sahil/resort döviz girişi) ──
        df.at[idx, "Yaz_Turizm"] = int(month in (5, 6, 7, 8, 9, 10))

        # ── Kis_Turizm (Aralık-Mart — kayak merkezleri) ─────────
        df.at[idx, "Kis_Turizm"] = int(month in (12, 1, 2, 3))

        # ── Temetu_Donemi (15 Nisan – 15 Haziran) ────────────────
        temetu = 0
        if (month == 4 and mid_date.day >= 15) \
           or month == 5 \
           or (month == 6 and mid_date.day <= 15):
            temetu = 1
        df.at[idx, "Temetu_Donemi"] = temetu

        # ── PPK_Haftasi / PPK_Oncesi / PPK_Sonrasi ──────────────
        if ppk_date_set:
            df.at[idx, "PPK_Haftasi"] = int(any(d.date() in ppk_date_set for d in days_full_week))
            df.at[idx, "PPK_Oncesi"]  = int(any(d.date() in ppk_oncesi_set for d in days_full_week))
            df.at[idx, "PPK_Sonrasi"] = int(any(d.date() in ppk_sonrasi_set for d in days_full_week))
        else:
            df.at[idx, "PPK_Haftasi"] = 0
            df.at[idx, "PPK_Oncesi"]  = 0
            df.at[idx, "PPK_Sonrasi"] = 0

        # ── Enflasyon_Aciklama_Haftasi (TÜİK TÜFE ayın ilk 7 günü) ──
        # TÜİK TÜFE ayın 3. iş gününde açıklanır → genelde 3-5 Tarih
        df.at[idx, "Enflasyon_Aciklama_Haftasi"] = int(
            any(1 <= d.day <= 7 for d in days_full_week)
        )

        # ── Market_Anomaly ───────────────────────────────────────
        # CDS_5Y ÷ Kur_Vol ÷ VIX z-score ortalaması > 2σ ise 1
        # (Hesap satır sonrasında tek seferlik yapılıyor — aşağıda)

        updated += 1

    # ── Market_Anomaly: vectorized, loop'tan sonra ────────────────
    # CDS_5Y + Kur_Vol + VIX z-score ortalaması > 2σ → 1, diğerleri 0
    import numpy as np
    anomaly_cols = ["CDS_5Y", "Kur_Vol", "VIX"]
    available    = [c for c in anomaly_cols if c in df.columns]
    if available:
        scores = pd.DataFrame()
        for c in available:
            s = pd.to_numeric(df[c], errors="coerce")
            mu, std = s.mean(), s.std()
            scores[c] = (s - mu) / std if std > 0 else 0.0
        z_avg = scores.mean(axis=1)
        df["Market_Anomaly"] = (z_avg > 2.0).astype(int)
        n_flagged = df["Market_Anomaly"].sum()
        print(f"  Market_Anomaly: {n_flagged} hafta flaglandı "
              f"(z-score > 2σ üzerinde CDS/Kur_Vol/VIX ortalaması)")
    else:
        df["Market_Anomaly"] = 0
        print("  Market_Anomaly: CDS/Kur_Vol/VIX kolonları henüz yok → 0")
    # ── Faiz_Anomaly: TLREF / TCMB_Mevduat_1M oranı |z-score| > 1.5σ ──
    # TLREF politika faizine anormal yaklaştığında → faiz fiyatlandırma anomalisi
    # (Threshold 2.0 → 1.5: daha çok hafta flag'lensin, varyans artsın)
    faiz_cols = ["TLREF", "TCMB_Mevduat_1M"]
    if all(c in df.columns for c in faiz_cols):
        tlref  = pd.to_numeric(df["TLREF"],   errors="coerce")
        tcmb1m = pd.to_numeric(df["TCMB_Mevduat_1M"], errors="coerce")
        ratio  = tlref / tcmb1m
        r_mu, r_std = ratio.mean(), ratio.std()
        if r_std > 0:
            z_ratio = (ratio - r_mu) / r_std
            df["Faiz_Anomaly"] = (z_ratio.abs() > 1.5).astype(int)
        else:
            df["Faiz_Anomaly"] = 0
        n_faiz = df["Faiz_Anomaly"].sum()
        print(f"  Faiz_Anomaly: {n_faiz} hafta flaglandı "
              f"(TLREF/TCMB_Mevduat_1M ratio |z-score| > 1.5σ)")
    else:
        df["Faiz_Anomaly"] = 0
        print("  Faiz_Anomaly: TLREF/TCMB_1M henüz yok → 0")

    print(f"  {updated} satır güncellendi ({', '.join(all_cols)})")

    # ── Kaydet ───────────────────────────────────────────────────
    for col in ["Min_Tarih", "Max_Tarih"]:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = df[col].dt.strftime("%d.%m.%Y")

    save_firast(df)
if __name__ == "__main__":
    update_calendar_features()
