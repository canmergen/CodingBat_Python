"""
holidays.py
-----------
Türkiye resmi tatillerini dinamik olarak döndürür.
`holidays` kütüphanesi kullanılır — yıl bağımsız, hardcoded tarih yok.

Kütüphane her yıl için hem sabit tatilleri (1 Ocak, 23 Nisan, 29 Ekim...)
hem de dinî tatilleri (Ramazan/Kurban Bayramı) otomatik hesaplar.
2027, 2028 ve sonrası için ek güncelleme gerekmez.
"""

import holidays as _holidays
from functools import lru_cache


@lru_cache(maxsize=None)
def _get_tr_holidays(year: int):
    """Verilen yıl için Türkiye tatil nesnesi döndürür (önbellekli)."""
    return _holidays.Turkey(years=year)


def is_holiday(date_obj) -> bool:
    """
    Verilen tarih Türkiye'de resmi tatil mi?
    Weekday kontrolü burada yapılmaz — sadece tatil takvimi kontrol edilir.
    """
    d = date_obj.date() if hasattr(date_obj, "date") else date_obj
    return d in _get_tr_holidays(d.year)
