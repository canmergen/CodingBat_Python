"""
evds3_client.py
---------------
EVDS3 POST /igmevdsms-dis/fe endpoint'i için ortak Playwright tabanlı istemci.
AOFM, BIST100 ve TCMB Mevduat script'leri bu modülü kullanır.

Çalışma prensibi:
  1. Playwright ile mevcut ticari kredi portletini açar (oturum kurar).
  2. requests.Session'a cookie'leri aktarır.
  3. İstenen seri kodlarıyla /fe endpoint'ine POST atar.
  4. Dönen JSON items listesini döndürür.
"""

import json
import time

import requests
from playwright.sync_api import sync_playwright

PORTLET_URL = (
    "https://evds3.tcmb.gov.tr"
    "/charts/portlet/Njk4YjFjMzljNjAxMWY0MDU2MDdjYzll/tr"
)
FE_URL = "https://evds3.tcmb.gov.tr/igmevdsms-dis/fe"

UA = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)


def fetch_evds3_series(
    series_codes: list[str],
    start_date: str = "01-01-2020",
    end_date: str | None = None,
    frequency: str = "3",       # 3 = haftalık
    aggregation: str = "avg",
    api_key: str | None = None,  # EVDS2/EVDS3 API anahtarı (ek seri erişimi için)
) -> list[dict]:
    """
    EVDS3'ten seri verisi çeker.

    Parametreler
    ------------
    series_codes : liste, örn. ["TP.APIFON4"] veya ["TP.TRY.MT01", "TP.TRY.MT02"]
    start_date   : "dd-mm-yyyy" formatı
    end_date     : "dd-mm-yyyy" formatı; None ise bugünün tarihi kullanılır
    frequency    : "3" = haftalık, "5" = aylık (EVDS3 kodu)
    aggregation  : her seri için toplanma tipi ("avg" veya "last")

    Dönüş
    ------
    items listesi; her eleman dict (Tarih, YEARWEEK, <seri_kodu>, UNIXTIME)
    """
    from datetime import date

    if end_date is None:
        end_date = date.today().strftime("%d-%m-%Y")

    # --- 1. Playwright ile oturum kur ---
    cookies_store: list[dict] = []

    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True)
        ctx = browser.new_context(user_agent=UA)
        page = ctx.new_page()
        page.goto(PORTLET_URL, wait_until="domcontentloaded", timeout=60_000)
        time.sleep(2)
        cookies_store = ctx.cookies()
        browser.close()

    # --- 2. requests ile POST isteği gönder ---
    session = requests.Session()
    headers = {
        "User-Agent": UA,
        "Referer": PORTLET_URL,
        "Content-Type": "application/json",
    }
    if api_key:
        headers["apiKey"] = api_key
    session.headers.update(headers)
    for c in cookies_store:
        session.cookies.set(c["name"], c["value"], domain=c.get("domain", ""))

    n = len(series_codes)
    payload = {
        "type": "json",
        "series": "-".join(series_codes),
        "aggregationTypes": "-".join([aggregation] * n),
        "formulas": "-".join(["0"] * n),
        "startDate": start_date,
        "endDate": end_date,
        "frequency": frequency,
        "decimalSeperator": ",",
        "decimal": "2",
        "dateFormat": "0",
        "lang": "tr",
        "ozelFormuller": [],
        "groupSeperator": True,
        "isRaporSayfasi": True,
    }

    r = session.post(FE_URL, json=payload, timeout=30)

    if r.status_code != 200:
        print(f"  Hata: HTTP {r.status_code} → {r.text[:200]}")
        return []

    data = r.json()
    return data.get("items", [])


def items_to_series(items: list[dict], key: str) -> "pd.Series":
    """
    items listesini verilen seri koduyla pandas Series'e dönüştürür.
    EVDS3 virgüllü ondalık formatını (örn. "37,00") float'a çevirir.
    """
    import pandas as pd

    if not items:
        return pd.Series(dtype=float)

    df = pd.DataFrame(items)
    df["Date"] = pd.to_datetime(df["Tarih"], dayfirst=True)
    df.set_index("Date", inplace=True)

    # key formatı: "TP.APIFON4" → EVDS3 yanıtında "TP_APIFON4" olarak gelir
    evds_key = key.replace(".", "_")
    if evds_key not in df.columns:
        print(f"  Uyarı: '{evds_key}' kolonu bulunamadı. Mevcut: {list(df.columns)}")
        return pd.Series(dtype=float)

    series = (
        df[evds_key]
        .astype(str)
        .str.replace(".", "", regex=False)   # binlik ayrac nokta kaldır (9.462,47 → 946247)
        .str.replace(",", ".", regex=False)  # ondalık virgülü noktaya çevir (946247 → 9462.47)
        .pipe(pd.to_numeric, errors="coerce")
    )
    return series
