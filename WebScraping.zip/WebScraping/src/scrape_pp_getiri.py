"""
scrape_pp_getiri.py
-------------------
TEFAS FonKarsilastirma sayfasından Para Piyasası Şemsiye Fonu (ID=107)
haftalık getirilerini Playwright ile çeker.

Yöntem (orijinal Selenium mantığıyla aynı, daha hızlı):
  1. TEFAS sayfasını aç
  2. Dropdown'dan "Para Piyasası Şemsiye Fonu" (107) seç
  3. Her boş hafta için: start/end date doldur → ButtonSearchDates → bekle
  4. Sonuç tablosundan Getiri (%) değerlerini DOM'dan oku
  5. Ortalamasını hesapla (/ 100 → ondalık)
  6. FIRAST.xlsx'e yaz

Fallback: TEFAS çalışmazsa AOFM / 365 × iş_günü / 100
"""

import time
import pandas as pd
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeout
from src.utils import read_firast, save_firast, log_baslik

TARGET_COLUMN = "PP_Getiri"
TEFAS_URL     = "https://www.tefas.gov.tr/FonKarsilastirma.aspx"

# Selector'lar (browser subagent ile doğrulandı)
SEL_DROPDOWN  = "#DropDownListUmbrellaFundTypeYAT"
SEL_START     = "[name='ctl00$MainContent$TextBoxStartDate']"
SEL_END       = "[name='ctl00$MainContent$TextBoxEndDate']"
SEL_BUTTON    = "[name='ctl00$MainContent$ButtonSearchDates']"
# Karşılaştırma sonuç tablosu (browser subagent ile doğrulandı)
SEL_TABLE     = "#main-table"
SEL_TABLE_ALT = "table:has(th:has-text('Fon Kodu'))"


def _scrape_all_weeks(weeks: list[tuple]) -> dict:
    """
    weeks: [(idx, start_str "%d.%m.%Y", end_str "%d.%m.%Y"), ...]
    Döner: {idx: float veya None}
    """
    results = {idx: None for idx, _, _ in weeks}

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page(user_agent=(
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
        ))

        # ── Sayfayı aç ────────────────────────────────────────────
        print(f"  TEFAS açılıyor...")
        try:
            page.goto(TEFAS_URL, wait_until="domcontentloaded", timeout=30_000)
            time.sleep(3)
        except PlaywrightTimeout:
            print("  ⚠ TEFAS sayfa timeout")
            browser.close()
            return results

        # Popup kapat (varsa)
        try:
            popup = page.locator("#duyuru > div > a")
            if popup.is_visible(timeout=3_000):
                popup.click()
                time.sleep(1)
        except Exception:
            pass

        # ── Dropdown: Para Piyasası Şemsiye Fonu (107) ────────────
        try:
            page.select_option(SEL_DROPDOWN, value="107")
            time.sleep(3)
            print("  Fon türü seçildi (Para Piyasası 107)")
        except Exception as e:
            print(f"  ⚠ Dropdown seçilemedi: {e}")
            browser.close()
            return results

        # ── Her hafta için tarih doldur ve sonucu oku ─────────────
        for idx, start_str, end_str in weeks:
            print(f"  [{idx}] {start_str} – {end_str} ...", end=" ", flush=True)
            try:
                # Start date
                page.fill(SEL_START, "")
                page.fill(SEL_START, start_str)
                # End date
                page.fill(SEL_END, "")
                page.fill(SEL_END, end_str)
                # Butona tıkla ve yüklenmesini bekle
                page.click(SEL_BUTTON)
                try:
                    page.wait_for_load_state("networkidle", timeout=10_000)
                except PlaywrightTimeout:
                    pass  # Bazen networkidle uzun sürer, devam et
                time.sleep(2)

                # Tabloyu bul (#main-table → fallback: Fon Kodu içeren tablo)
                table = page.locator(SEL_TABLE)
                if table.count() == 0:
                    table = page.locator(SEL_TABLE_ALT).first
                if table.count() == 0:
                    print("⚠ tablo bulunamadı")
                    continue

                rows = table.locator("tbody tr").all()
                if not rows:
                    print("⚠ satır yok")
                    continue

                returns = []
                for tr in rows:
                    cells = tr.locator("td").all()
                    if len(cells) < 2:
                        continue
                    # Son hücre = Getiri (%)
                    last_cell = cells[-1].inner_text().strip()
                    try:
                        val = float(last_cell.replace(",", ".").replace("%", "").strip())
                        if 0.001 < abs(val) < 5.0:
                            returns.append(val)
                    except (ValueError, TypeError):
                        pass

                if returns:
                    avg = round(sum(returns) / len(returns) / 100.0, 6)
                    results[idx] = avg
                    print(f"✓ {avg:.6f} ({len(returns)} fon)")
                else:
                    print("⚠ getiri değeri parse edilemedi")

            except Exception as e:
                print(f"⚠ {e}")

            time.sleep(1.0)

        browser.close()

    return results


def _derive_from_aofm(df: pd.DataFrame) -> dict:
    """Fallback: PP Getiri ≈ AOFM / 365 × iş_günü / 100"""
    if "AOFM" not in df.columns:
        return {}
    workday_col = next((c for c in ["Full_Workday", "Tam İş Günü"] if c in df.columns), None)
    results = {}
    for idx, row in df.iterrows():
        aofm = pd.to_numeric(row.get("AOFM"), errors="coerce")
        if pd.isna(aofm):
            continue
        wd = 5
        if workday_col:
            w = pd.to_numeric(row.get(workday_col), errors="coerce")
            if pd.notna(w) and 1 <= w <= 7:
                wd = int(w)
        results[idx] = round(aofm / 365 / 100 * wd, 6)
    return results


def scrape_pp_getiri():
    log_baslik(
        "PP_Getiri",
        "https://www.tefas.gov.tr/FonKarsilastirma.aspx · Playwright (fallback: AOFM)",
    )
    df = read_firast()
    if df is None or df.empty:
        print("FIRAST.xlsx bulunamadı veya boş.")
        return

    if TARGET_COLUMN not in df.columns:
        df[TARGET_COLUMN] = None

    # Eski % değerleri ondalığa düzelt
    fixed = 0
    for i in df.index:
        val = df.at[i, TARGET_COLUMN]
        if pd.notna(val) and isinstance(val, (int, float)) and val > 0.01:
            df.at[i, TARGET_COLUMN] = val / 100.0
            fixed += 1
    if fixed:
        print(f"  {fixed} eski değer ondalığa çevrildi.")

    df["Min_Tarih"] = pd.to_datetime(df["Min_Tarih"], dayfirst=True, errors="coerce")
    df["Max_Tarih"] = pd.to_datetime(df["Max_Tarih"], dayfirst=True, errors="coerce")

    # Son 2 satır her zaman yeniden çekilir (mevcut hafta tamamlanmamış olabilir)
    # Önceki tüm dolu satırlar atlanır — artımsal mantık
    last_2_indices = set(df.index[-2:])
    empty_rows = [
        (idx, row["Min_Tarih"].strftime("%d.%m.%Y"), row["Max_Tarih"].strftime("%d.%m.%Y"))
        for idx, row in df.iterrows()
        if (pd.isna(row[TARGET_COLUMN]) or idx in last_2_indices)
        and pd.notna(row["Min_Tarih"])
        and pd.notna(row["Max_Tarih"])
    ]

    skipped = len(df) - len(empty_rows)
    print(f"  {skipped} satır atlandı, {len(empty_rows)} satır çekilecek (son 2 hafta dahil).")

    if not empty_rows:
        _save(df)
        return

    # ── Playwright ile TEFAS ────────────────────────────────────────
    pw_results = _scrape_all_weeks(empty_rows)
    updated = sum(1 for v in pw_results.values() if v is not None)
    for idx, val in pw_results.items():
        if val is not None:
            df.at[idx, TARGET_COLUMN] = val

    # ── AOFM Fallback ──────────────────────────────────────────────
    still_empty = [idx for idx, _, _ in empty_rows if pd.isna(df.at[idx, TARGET_COLUMN])]
    if still_empty:
        print(f"  AOFM fallback ({len(still_empty)} satır)...")
        aofm_map = _derive_from_aofm(df)
        aofm_ok = sum(
            1 for idx in still_empty
            if idx in aofm_map and not pd.isna(aofm_map[idx])
        )
        for idx in still_empty:
            if idx in aofm_map:
                df.at[idx, TARGET_COLUMN] = aofm_map[idx]
        print(f"  AOFM fallback: {aofm_ok} satır türetildi.")

    total = df[TARGET_COLUMN].notna().sum()
    print(f"\n  PP Getiri: {total}/{len(df)} satır dolu.")

    _save(df)
def _save(df):
    for col in ["Min_Tarih", "Max_Tarih"]:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = df[col].dt.strftime("%d.%m.%Y")
    save_firast(df)


if __name__ == "__main__":
    scrape_pp_getiri()
