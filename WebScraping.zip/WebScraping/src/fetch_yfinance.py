"""
fetch_yfinance.py
-----------------
yfinance üzerinden haftalık piyasa verilerini çeker ve FIRAST.xlsx'e yazar.

Çekilen veriler:
  - Gram Altın (TRY)     : XAUTRY=X   → Close
  - VIX (Korku Endeksi)  : ^VIX       → Close
  - XBANK (Bankacılık)   : XBANK.IS   → Close
  - EUR/USD Paritesi     : EURUSD=X   → Close
  - USD/TRY Kapanış      : USDTRY=X   → Close  (volatilite hesabı için)
  - Bakır (USD/lb)       : HG=F       → Close
  - Gümüş (USD/oz)       : SI=F       → Close
  - TÜRKİYE DİBS 2Y/10Y : TRT2YT=RR / TRT10YT=RR → yfinance'de delisted, çekilmiyor
  - DİBS 10Y Getirisi    : TRT10YT=RR → Close  (Türkiye 10 Yıllık Devlet Tahvili %)

Türetilen:
  - Kur_Vol : USD/TRY 5 günlük rolling std (haftalık ortalama)
"""

import pandas as pd
import yfinance as yf
from src.utils import read_firast, save_firast, log_baslik


# ── Ticker → FIRAST kolon adı eşleştirmesi ──────────────────────────
TICKERS = {
    "GC=F":        "Altin_USD",     # Gold Futures (USD/oz) → TRY'ye çevrilecek
    "^VIX":        "VIX",
    "XBANK.IS":    "XBANK",
    "EURUSD=X":    "EUR_USD",
    "USDTRY=X":    "USD_TRY",
    "EURTRY=X":    "EUR_TRY",       # EUR/TRY doğrudan
    "HG=F":        "Bakir",
    "SI=F":        "Gumus",
    "BZ=F":        "Brent",
    "DX-Y.NYB":    "DXY",
}

# Sadece BIST_Vol türetmesi için indirilen, FIRAST'a kolon olarak yazılmayan ticker'lar
EXTRA_DOWNLOAD = ["XU100.IS"]

# Troy ons → gram çevirme katsayısı
TROY_OZ_TO_GRAM = 31.1035


def fetch_yfinance():
    log_baslik(
        "VIX, USD_TRY, EUR_USD, EUR_TRY, Altin_USD, Bakir, Gumus, Brent, DXY, XBANK, Gram_Altin_TRY, Kur_Vol, BIST_Vol",
        "https://finance.yahoo.com · yfinance günlük kapanış + haftalık volatilite",
    )
    df_excel = read_firast()
    if df_excel is None or df_excel.empty:
        print("FIRAST.xlsx bulunamadı veya boş.")
        return

    df_excel["Min_Tarih"] = pd.to_datetime(df_excel["Min_Tarih"], dayfirst=True, errors="coerce")
    df_excel["Max_Tarih"] = pd.to_datetime(df_excel["Max_Tarih"], dayfirst=True, errors="coerce")

    min_date = df_excel["Min_Tarih"].min()
    max_date = df_excel["Max_Tarih"].max()

    # Bir gün önce başla, bir gün sonra bitir (sınır gün verisi için)
    start_str = (min_date - pd.Timedelta(days=7)).strftime("%Y-%m-%d")
    end_str = (max_date + pd.Timedelta(days=1)).strftime("%Y-%m-%d")
    print(f"Tarih Aralığı: {start_str} → {end_str}")

    # ── 1. Günlük veri çek (tüm ticker'lar + BIST_Vol türetme için XU100.IS) ──
    ticker_list = list(TICKERS.keys()) + EXTRA_DOWNLOAD
    print(f"Ticker'lar indiriliyor: {ticker_list}")

    try:
        data = yf.download(
            ticker_list,
            start=start_str,
            end=end_str,
            interval="1d",
            auto_adjust=True,
            progress=False,
        )
    except Exception as e:
        print(f"yfinance indirme hatası: {e}")
        return

    # Çoklu ticker → MultiIndex columns: (Price, Ticker)
    # Tek ticker → normal columns
    if isinstance(data.columns, pd.MultiIndex):
        close_df = data["Close"]
    else:
        # Tek ticker durumu
        close_df = data[["Close"]].rename(columns={"Close": ticker_list[0]})

    print(f"Toplam günlük kayıt: {len(close_df)}")
    print(f"Mevcut ticker'lar: {list(close_df.columns)}")

    # ── 2. Kur Volatilitesi hesapla ───────────────────────────────
    kur_vol = None
    usdtry_col = "USDTRY=X"
    if usdtry_col in close_df.columns:
        kur_vol = close_df[usdtry_col].pct_change(fill_method=None).rolling(5).std()
        print(f"Kur volatilitesi hesaplandı ({kur_vol.dropna().shape[0]} değer)")

    # ── 2.5. Gram Altın TRY hesapla ──────────────────────────────
    gram_altin_try = None
    gc_col = "GC=F"
    if gc_col in close_df.columns and usdtry_col in close_df.columns:
        # Gold (USD/troy oz) × USD/TRY ÷ 31.1035 (g/oz) = TRY/gram
        gram_altin_try = (close_df[gc_col] * close_df[usdtry_col]) / TROY_OZ_TO_GRAM
        print(f"Gram Altın TRY hesaplandı ({gram_altin_try.dropna().shape[0]} değer)")

    # ── 2.6. BIST Volatilitesi hesapla ────────────────────────────
    bist_vol = None
    xu100_col = "XU100.IS"
    if xu100_col in close_df.columns:
        bist_vol = close_df[xu100_col].pct_change(fill_method=None).rolling(5).std()
        print(f"BIST volatilitesi hesaplandı ({bist_vol.dropna().shape[0]} değer)")

    # ── 3. Haftalık ortalamaları FIRAST satırlarına yaz ─────────────
    for col_name in TICKERS.values():
        if col_name not in df_excel.columns:
            df_excel[col_name] = None

    for extra_col in ["Kur_Vol", "Gram_Altin_TRY", "BIST_Vol"]:
        if extra_col not in df_excel.columns:
            df_excel[extra_col] = None

    updated_counts = {v: 0 for v in TICKERS.values()}
    updated_counts["Kur_Vol"] = 0
    updated_counts["Gram_Altin_TRY"] = 0
    updated_counts["BIST_Vol"] = 0

    all_yf_cols = list(TICKERS.values()) + ["Kur_Vol", "Gram_Altin_TRY", "BIST_Vol"]
    last_2_idx = set(df_excel.index[-2:])

    for idx, row in df_excel.iterrows():
        # Artımsal: tüm yfinance kolonları doluysa atla, son 2 hafta hariç
        if idx not in last_2_idx and all(
            pd.notna(row.get(c)) for c in all_yf_cols if c in df_excel.columns
        ):
            continue
        r_start = row["Min_Tarih"]
        r_end = row["Max_Tarih"]
        if pd.isna(r_start) or pd.isna(r_end):
            continue

        # Her ticker için haftalık ortalama
        for ticker, col_name in TICKERS.items():
            if ticker not in close_df.columns:
                continue
            mask = (close_df.index >= r_start) & (close_df.index <= r_end)
            subset = close_df.loc[mask, ticker].dropna()
            if not subset.empty:
                df_excel.at[idx, col_name] = round(subset.mean(), 4)
                updated_counts[col_name] += 1

        # Kur volatilitesi
        if kur_vol is not None:
            mask = (kur_vol.index >= r_start) & (kur_vol.index <= r_end)
            subset = kur_vol.loc[mask].dropna()
            if not subset.empty:
                df_excel.at[idx, "Kur_Vol"] = round(subset.mean(), 6)
                updated_counts["Kur_Vol"] += 1

        # Gram Altın TRY
        if gram_altin_try is not None:
            mask = (gram_altin_try.index >= r_start) & (gram_altin_try.index <= r_end)
            subset = gram_altin_try.loc[mask].dropna()
            if not subset.empty:
                df_excel.at[idx, "Gram_Altin_TRY"] = round(subset.mean(), 2)
                updated_counts["Gram_Altin_TRY"] += 1

        # BIST Volatilitesi
        if bist_vol is not None:
            mask = (bist_vol.index >= r_start) & (bist_vol.index <= r_end)
            subset = bist_vol.loc[mask].dropna()
            if not subset.empty:
                df_excel.at[idx, "BIST_Vol"] = round(subset.mean(), 6)
                updated_counts["BIST_Vol"] += 1

    # Sonuçları yazdır
    for col, cnt in updated_counts.items():
        print(f"  {col}: {cnt} satır güncellendi")

    # ── 4. Tarih formatını geri yükle ve kaydet ───────────────────
    for col in ["Min_Tarih", "Max_Tarih"]:
        if pd.api.types.is_datetime64_any_dtype(df_excel[col]):
            df_excel[col] = df_excel[col].dt.strftime("%d.%m.%Y")

    save_firast(df_excel)
if __name__ == "__main__":
    fetch_yfinance()
