import pandas as pd
from datetime import timedelta
from src.utils import read_firast, save_firast, log_baslik
from src.holidays import is_holiday

def update_workdays():
    log_baslik(
        "Full_Workday",
        "internal · holidays.Turkey iş günü sayımı (harici kaynak yok)",
    )
    df = read_firast()
    if df is None or df.empty:
        print("FIRAST.xlsx not found.")
        return

    updated_count = 0
    column_name = "Full_Workday"
    
    if column_name not in df.columns:
        df[column_name] = None
        
    for index, row in df.iterrows():
        min_t = pd.to_datetime(row['Min_Tarih'], dayfirst=True, errors='coerce')
        max_t = pd.to_datetime(row['Max_Tarih'], dayfirst=True, errors='coerce')
        
        if pd.isna(min_t) or pd.isna(max_t):
            continue
            
        # Iterate dates in range
        curr = min_t
        is_full = 1
        
        while curr <= max_t:
            # Check if Weekday (0=Mon, 4=Fri) is a holiday
            if curr.weekday() < 5: # Mon-Fri
                if is_holiday(curr):
                    is_full = 0
                    break
            curr += timedelta(days=1)
            
        # Optimization: Don't rewrite if same (to avoid dirtying file)
        # But we want to ensure it is set.
        current_val = df.at[index, column_name]
        if current_val != is_full:
            df.at[index, column_name] = is_full
            updated_count += 1
            
    save_firast(df)
    print(f"Updated {updated_count} rows for '{column_name}'.")

if __name__ == "__main__":
    update_workdays()
