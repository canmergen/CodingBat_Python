"""
fetch_bist100.py
----------------
EVDS3'ten BIST 100 Endeksi verisini çeker ve FIRAST.xlsx'e yazar.

Kaynak  : EVDS3 /igmevdsms-dis/fe endpoint (Playwright oturumu ile)
Seri    : TP.MK.F.BILESIK
Frekans : Haftalık (frequency=3)
"""

import pandas as pd
from src.utils import read_firast, save_firast, log_baslik
from src.evds3_client import fetch_evds3_series, items_to_series

SERIES_CODE = "TP.MK.F.BILESIK"
COLUMN_NAME = "BIST100"


def fetch_bist100():
    log_baslik(
        "BIST100",
        "https://evds3.tcmb.gov.tr · TP.MK.F.BILESIK · haftalık ort.",
    )
    df_excel = read_firast()
    if df_excel is None or df_excel.empty:
        print("FIRAST.xlsx bulunamadı veya boş.")
        return

    if COLUMN_NAME not in df_excel.columns:
        df_excel[COLUMN_NAME] = None

    df_excel["Min_Tarih"] = pd.to_datetime(df_excel["Min_Tarih"], dayfirst=True, errors="coerce")
    df_excel["Max_Tarih"] = pd.to_datetime(df_excel["Max_Tarih"], dayfirst=True, errors="coerce")

    # Tarih aralığı
    min_date = df_excel["Min_Tarih"].min()
    max_date = df_excel["Max_Tarih"].max()
    start_str = min_date.strftime("%d-%m-%Y")
    end_str   = max_date.strftime("%d-%m-%Y")
    print(f"Tarih Aralığı: {start_str} - {end_str}")

    # EVDS3'ten veri çek
    items = fetch_evds3_series([SERIES_CODE], start_date=start_str, end_date=end_str)
    if not items:
        print("Veri alınamadı.")
        return

    series_vals = items_to_series(items, SERIES_CODE)
    print(f"  Geçerli BIST100 değeri sayısı: {len(series_vals.dropna())}")

    # Haftalık ortalamayı Excel satırlarına yaz
    updated_count = 0
    last_2_idx = set(df_excel.index[-2:])
    for idx, row in df_excel.iterrows():
        # Artımsal: dolu satırları atla, son 2 hafta hariç
        if pd.notna(row.get(COLUMN_NAME)) and idx not in last_2_idx:
            continue
        r_start = row["Min_Tarih"]
        r_end   = row["Max_Tarih"]
        if pd.isna(r_start) or pd.isna(r_end):
            continue
        mask   = (series_vals.index >= r_start) & (series_vals.index <= r_end)
        subset = series_vals.loc[mask].dropna()
        if not subset.empty:
            df_excel.at[idx, COLUMN_NAME] = subset.mean()
            updated_count += 1

    print(f"BIST 100: {updated_count} satır güncellendi.")

    # Tarih formatını geri yükle
    for col in ["Min_Tarih", "Max_Tarih"]:
        if pd.api.types.is_datetime64_any_dtype(df_excel[col]):
            df_excel[col] = df_excel[col].dt.strftime("%d.%m.%Y")

    save_firast(df_excel)
if __name__ == "__main__":
    fetch_bist100()
