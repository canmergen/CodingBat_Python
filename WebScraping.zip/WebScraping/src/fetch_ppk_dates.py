"""
fetch_ppk_dates.py
------------------
PPK (Para Politikası Kurulu) toplantı tarihlerini otomatik olarak toplar.

Kaynaklar:
  1. TCMB Takvim sayfası (Playwright) — güncel yıl + gelecek yıllar.
     URL: https://www.tcmb.gov.tr/.../duyurular/takvim
     Format: ilk sütundaki Türkçe tarihler (örn. "22 Ocak 2026")
  2. HISTORICAL_PPK_DATES sabiti — TCMB arşivinde kayıtlı 2024-2025
     toplantı tarihleri (takvim sayfasında yalnızca güncel/gelecek yıllar
     listelendiği için geçmiş bu sabitten okunur).

İki kaynak birleştirilip benzersiz tarihler döndürülür. Takvim sayfası
her yıl yeni tarihleri yayımladığından yıllık güncelleme gerekmez.
"""

import time
import re
from datetime import date

from playwright.sync_api import sync_playwright

from src.utils import log_baslik

TAKVIM_URL = "https://www.tcmb.gov.tr/wps/wcm/connect/tr/tcmb+tr/main+menu/duyurular/takvim"

# ── TCMB arşivinde kayıtlı 2024-2025 toplantı tarihleri ──────────
HISTORICAL_PPK_DATES: list[date] = [
    # 2024
    date(2024, 10, 17), date(2024, 11, 21), date(2024, 12, 26),
    # 2025
    date(2025, 1, 23),  date(2025, 3, 6),   date(2025, 4, 17),
    date(2025, 6, 19),  date(2025, 7, 24),  date(2025, 9, 11),
    date(2025, 10, 23), date(2025, 12, 11),
]

TR_MONTHS = {
    "ocak": 1, "şubat": 2, "subat": 2, "mart": 3, "nisan": 4,
    "mayıs": 5, "mayis": 5, "haziran": 6, "temmuz": 7,
    "ağustos": 8, "agustos": 8, "eylül": 9, "eylul": 9,
    "ekim": 10, "kasım": 11, "kasim": 11, "aralık": 12, "aralik": 12,
}

DATE_RE = re.compile(r"(\d{1,2})\s+([A-Za-zÇĞİıŞşçğüÖöÜ]+)\s+(\d{4})")


def _parse_tr_date(txt: str) -> date | None:
    m = DATE_RE.search(txt.strip())
    if not m:
        return None
    day, mon_tr, year = m.groups()
    mon = TR_MONTHS.get(mon_tr.lower())
    if not mon:
        return None
    try:
        return date(int(year), mon, int(day))
    except ValueError:
        return None


def _scrape_takvim() -> set[date]:
    """TCMB Takvim tablosunun ilk sütunundaki PPK toplantı tarihlerini çeker."""
    dates: set[date] = set()
    try:
        with sync_playwright() as pw:
            browser = pw.chromium.launch(headless=True)
            page = browser.new_context().new_page()
            page.goto(TAKVIM_URL, wait_until="networkidle", timeout=60_000)
            time.sleep(2)
            rows = page.locator("table tr").all()
            for row in rows:
                cells = row.locator("td").all()
                if not cells:
                    continue
                d = _parse_tr_date(cells[0].inner_text())
                if d:
                    dates.add(d)
            browser.close()
    except Exception as e:
        print(f"  ⚠ Takvim scrape hatası: {e}")
    return dates


def fetch_ppk_dates() -> list[date]:
    """Tarihsel sabit liste + TCMB takvim scrape → benzersiz tarihler."""
    log_baslik(
        "PPK toplantı tarihleri (internal list)",
        "https://www.tcmb.gov.tr/wps/wcm/connect/tr/tcmb+tr/main+menu/duyurular/takvim · Playwright + HISTORICAL_PPK_DATES",
    )
    scraped = _scrape_takvim()
    print(f"  Takvim scrape (güncel/gelecek): {len(scraped)} tarih")

    all_dates = sorted(set(HISTORICAL_PPK_DATES) | scraped)
    print(f"  Sabit geçmiş: {len(HISTORICAL_PPK_DATES)} tarih")
    print(f"  Toplam: {len(all_dates)} benzersiz PPK tarihi")
    return all_dates


if __name__ == "__main__":
    for d in fetch_ppk_dates():
        print(d)
