"""
fetch_tcmb_mevduat.py
---------------------
TCMB 1M & 3M mevduat faizini çeker ve FIRAST.xlsx'e yazar.

Akış:
  1. EVDS3 TP.TRY.MT01 / TP.TRY.MT02 haftalık serileri → haftalık ortalama
     olarak TCMB_Mevduat_1M ve TCMB_Mevduat_3M kolonlarına yazılır.
  2. Ekim 2024 – Ağustos 2025 aralığı için SEED tablosundaki Cuma spot
     kapanış değerleri EVDS ortalamasını override eder.
  3. Her iki kolonun 1 hafta shift'lenmiş hali `_Onceki_Hafta` suffix'iyle
     eklenir — Pazartesi nowcast modeli için leakage-free feature.
  4. İlk hafta (30.09-04.10.2024) için önceki Cuma (23-27.09.2024) değeri
     EVDS3'ten çekilerek backfill edilir.
  5. Kolon sırası: TCMB_Mevduat_1M, TCMB_Mevduat_1M_Onceki_Hafta,
     TCMB_Mevduat_3M, TCMB_Mevduat_3M_Onceki_Hafta — bitişik.

Kaynak : EVDS3 /igmevdsms-dis/fe (Playwright oturumu)
Seriler: TP.TRY.MT01 (1 ay), TP.TRY.MT02 (3 ay)
"""

import pandas as pd

from src.evds3_client import fetch_evds3_series, items_to_series
from src.seed_tcmb_mevduat import SEED
from src.utils import read_firast, save_firast, log_baslik

SERIES_CONFIG = {
    "TP.TRY.MT01": "TCMB_Mevduat_1M",
    "TP.TRY.MT02": "TCMB_Mevduat_3M",
}

SHIFT_MAP = {
    "TCMB_Mevduat_1M": "TCMB_Mevduat_1M_Onceki_Hafta",
    "TCMB_Mevduat_3M": "TCMB_Mevduat_3M_Onceki_Hafta",
}

# Çıktı kolon sırası (FIRAST içinde bu sırayla yan yana)
OUTPUT_ORDER = [
    "TCMB_Mevduat_1M",
    "TCMB_Mevduat_1M_Onceki_Hafta",
    "TCMB_Mevduat_3M",
    "TCMB_Mevduat_3M_Onceki_Hafta",
]


def _write_evds_weekly_avg(df: pd.DataFrame) -> int:
    """EVDS3 TP.TRY.MT01/02 haftalık ortalamasını TCMB_Mevduat_1M/3M'e yazar."""
    start = df["Min_Tarih"].min().strftime("%d-%m-%Y")
    end = df["Max_Tarih"].max().strftime("%d-%m-%Y")
    items = fetch_evds3_series(list(SERIES_CONFIG.keys()),
                               start_date=start, end_date=end)
    if not items:
        print("  ⚠ EVDS3 veri dönmedi.")
        return 0

    series_map = {col: items_to_series(items, code)
                  for code, col in SERIES_CONFIG.items()}
    cols = list(SERIES_CONFIG.values())
    last_2 = set(df.index[-2:])
    updated = 0
    for idx, row in df.iterrows():
        if idx not in last_2 and all(pd.notna(row.get(c)) for c in cols):
            continue
        r_start, r_end = row["Min_Tarih"], row["Max_Tarih"]
        if pd.isna(r_start) or pd.isna(r_end):
            continue
        touched = False
        for col, series in series_map.items():
            mask = (series.index >= r_start) & (series.index <= r_end)
            subset = series.loc[mask].dropna()
            if not subset.empty:
                df.at[idx, col] = round(subset.mean(), 4)
                touched = True
        if touched:
            updated += 1
    return updated


def _apply_seed(df: pd.DataFrame) -> int:
    """SEED tablosundaki Cuma spot kapanış değerleriyle override."""
    written = 0
    for _, s in SEED.iterrows():
        d = s["Date"]
        mask = (df["Min_Tarih"] <= d) & (df["Max_Tarih"] >= d)
        if not mask.any():
            continue
        idx = df.index[mask][0]
        df.at[idx, "TCMB_Mevduat_1M"] = s["TCMB_Mevduat_1M"]
        df.at[idx, "TCMB_Mevduat_3M"] = s["TCMB_Mevduat_3M"]
        written += 1
    return written


def _compute_shifted(df: pd.DataFrame) -> None:
    """_Onceki_Hafta kolonlarını shift(1) ile doldurur + ilk satır backfill."""
    df.sort_values("Min_Tarih", inplace=True, ignore_index=True)
    for src, dst in SHIFT_MAP.items():
        df[dst] = pd.to_numeric(df[src], errors="coerce").shift(1)

    # İlk hafta için 23-27.09.2024 değerini EVDS'den çek
    items = fetch_evds3_series(
        list(SERIES_CONFIG.keys()),
        start_date="20-09-2024", end_date="30-09-2024",
        frequency="1",
    )
    if not items:
        print("  ⚠ İlk hafta backfill için EVDS veri alınamadı.")
        return

    target = pd.Timestamp("2024-09-27")
    for code, src in SERIES_CONFIG.items():
        series = items_to_series(items, code).dropna()
        if series.empty:
            continue
        val = float(series.asof(target))
        dst = SHIFT_MAP[src]
        df.at[0, dst] = round(val, 4)
    print("  İlk hafta backfill: 23-27.09.2024 Cuma (EVDS haftalık ort.)")


def _reorder_columns(df: pd.DataFrame) -> pd.DataFrame:
    """TCMB_Mevduat_1M ve 3M kolonlarını _Onceki_Hafta'larıyla yan yana yerleştirir."""
    cols = [c for c in df.columns if c not in OUTPUT_ORDER]
    # TCMB_Mevduat_1M FIRAST içinde nerede olması beklenirse oraya yerleştir
    # Anchor: week_generator'ın full_columns'unda TCMB_Mevduat_1M var →
    # onun bulunmadığı durumda PP_Getiri'den sonra ekle
    anchor_candidates = ("PP_Getiri", "AOFM", "TLREF")
    insert_pos = len(cols)
    for anchor in anchor_candidates:
        if anchor in cols:
            insert_pos = cols.index(anchor) + 1
            break
    new_order = cols[:insert_pos] + OUTPUT_ORDER + cols[insert_pos:]
    return df[new_order]


def fetch_tcmb_mevduat():
    log_baslik(
        "TCMB_Mevduat_1M/3M (+ _Onceki_Hafta)",
        "https://evds3.tcmb.gov.tr · TP.TRY.MT01/02 · haftalık ort. + SEED Cuma kapanış + shift(1)",
    )
    df = read_firast()
    if df is None or df.empty:
        print("Hata: FIRAST.xlsx bulunamadı veya boş.")
        return

    for col in OUTPUT_ORDER:
        if col not in df.columns:
            df[col] = None

    df["Min_Tarih"] = pd.to_datetime(df["Min_Tarih"], dayfirst=True, errors="coerce")
    df["Max_Tarih"] = pd.to_datetime(df["Max_Tarih"], dayfirst=True, errors="coerce")

    # 1) EVDS3 haftalık ortalama
    n_evds = _write_evds_weekly_avg(df)
    print(f"  EVDS3 haftalık ort.: {n_evds} satır yazıldı.")

    # 2) SEED override (Cuma spot kapanış)
    n_seed = _apply_seed(df)
    print(f"  SEED override: {n_seed}/{len(SEED)} hafta Cuma kapanış değeri.")

    # 3) Shift + ilk hafta backfill
    _compute_shifted(df)
    filled = df["TCMB_Mevduat_1M_Onceki_Hafta"].notna().sum()
    print(f"  _Onceki_Hafta (shift+backfill): {filled}/{len(df)} hafta dolu.")

    # 4) Kolon sırası: 1M, 1M_Onceki_Hafta, 3M, 3M_Onceki_Hafta
    df = _reorder_columns(df)

    for col in ("Min_Tarih", "Max_Tarih"):
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = df[col].dt.strftime("%d.%m.%Y")

    save_firast(df)


if __name__ == "__main__":
    fetch_tcmb_mevduat()
