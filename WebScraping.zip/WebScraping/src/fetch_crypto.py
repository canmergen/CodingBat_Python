"""
fetch_crypto.py
---------------
CoinGecko API'den USDT/TRY işlem hacmi çeker ve FIRAST.xlsx'e yazar.
Ücretsiz API — API key gerekmez.

Çekilen veriler:
  - USDT_TRY_Hacim : Tether'ın TRY karşılığı günlük işlem hacmi
"""

import pandas as pd
import requests
from src.utils import read_firast, save_firast, log_baslik

COLUMN_NAME = "USDT_TRY_Hacim"


def fetch_crypto():
    log_baslik(
        "USDT_TRY_Hacim",
        "https://api.coingecko.com/api/v3/coins/tether/market_chart · 24h hacim (son 365 gün)",
    )
    df_excel = read_firast()
    if df_excel is None or df_excel.empty:
        print("FIRAST.xlsx bulunamadı veya boş.")
        return

    df_excel["Min_Tarih"] = pd.to_datetime(df_excel["Min_Tarih"], dayfirst=True, errors="coerce")
    df_excel["Max_Tarih"] = pd.to_datetime(df_excel["Max_Tarih"], dayfirst=True, errors="coerce")

    min_date = df_excel["Min_Tarih"].min()
    max_date = df_excel["Max_Tarih"].max()

    # CoinGecko API: days parametresi ile veri çek (max ~365 gün)
    total_days = (max_date - min_date).days + 7
    if total_days > 365:
        total_days = 365
        print(f"  ⚠ CoinGecko ücretsiz API en fazla 365 gün destekler. Son {total_days} gün çekilecek.")

    url = "https://api.coingecko.com/api/v3/coins/tether/market_chart"
    params = {
        "vs_currency": "try",
        "days": total_days,
        "interval": "daily",
    }

    try:
        r = requests.get(url, params=params, timeout=30)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        print(f"  CoinGecko API hatası: {e}")
        return

    if "total_volumes" not in data:
        print("  ⚠ Yanıtta 'total_volumes' bulunamadı.")
        return

    # ── Günlük hacim verisini DataFrame'e dönüştür ────────────────
    volumes = data["total_volumes"]
    df_vol = pd.DataFrame(volumes, columns=["timestamp", "volume"])
    df_vol["Date"] = pd.to_datetime(df_vol["timestamp"], unit="ms").dt.normalize()
    df_vol.set_index("Date", inplace=True)
    df_vol = df_vol[["volume"]]
    print(f"  Günlük hacim kayıt sayısı: {len(df_vol)}")

    # ── FIRAST satırlarına haftalık toplam hacmi yaz ────────────────
    if COLUMN_NAME not in df_excel.columns:
        df_excel[COLUMN_NAME] = None

    updated = 0
    last_2_idx = set(df_excel.index[-2:])
    for idx, row in df_excel.iterrows():
        # Artımsal: dolu satırları atla, son 2 hafta hariç
        if pd.notna(row.get(COLUMN_NAME)) and idx not in last_2_idx:
            continue
        r_start = row["Min_Tarih"]
        r_end = row["Max_Tarih"]
        if pd.isna(r_start) or pd.isna(r_end):
            continue
        mask = (df_vol.index >= r_start) & (df_vol.index <= r_end)
        subset = df_vol.loc[mask, "volume"].dropna()
        if not subset.empty:
            # Haftalık TOPLAM hacim (ortalama değil)
            df_excel.at[idx, COLUMN_NAME] = round(subset.sum(), 2)
            updated += 1

    print(f"  USDT/TRY Hacim: {updated} satır güncellendi.")

    # ── Tarih formatını geri yükle ve kaydet ──────────────────────
    for col in ["Min_Tarih", "Max_Tarih"]:
        if pd.api.types.is_datetime64_any_dtype(df_excel[col]):
            df_excel[col] = df_excel[col].dt.strftime("%d.%m.%Y")

    save_firast(df_excel)
if __name__ == "__main__":
    fetch_crypto()
