# FORA — Fon İzleme, Referans Oran ve Sabit Tutarlı Analiz Tablosu

ING Türkiye Para Piyasası fon performansını makroekonomik referans verilerle haftalık olarak karşılaştıran otomatik veri tabanı.
`main.py` çalıştırıldığında tüm kaynaklar otomatik çekilir ve `FORA.xlsx` güncellenir.

---

## Hızlı Başlangıç

```bash
pip install -r requirements.txt
playwright install chromium
python main.py
```

- **İlk çalışma:** ~35 dk (2025/01/01'den itibaren tüm geçmiş veri)
- **Sonraki çalışmalar:** ~10 dk (sadece eksik/yeni satırlar — artımsal mantık)

---

## Proje Yapısı

```
FORA/
├── main.py                   # Ana orkestrasyon — tüm adımları sırayla çalıştırır
├── FORA.xlsx                 # Çıktı — haftalık veri tabanı
├── benchmark.xlsx            # Günlük benchmark faiz arşivi
├── requirements.txt
└── src/
    ├── utils.py              # read_fora / save_fora — Excel okuma/yazma
    ├── week_generator.py     # Haftalık iskelet oluşturma (2025-01-01'den bugüne)
    ├── scrape_pp_getiri.py   # TEFAS scraper (Selenium) — artımsal
    ├── scrape_webtufe.py     # webtufe.com Plotly scraper (Selenium + BeautifulSoup)
    ├── fetch_aoff.py         # EVDS3 TP.APIFON4 (Playwright POST intercept)
    ├── scrape_tlref.py       # BIST TLREF (Selenium) — artımsal
    ├── fetch_bist100.py      # EVDS3 TP.MK.F.BILESIK (Playwright POST intercept)
    ├── scrape_ppk.py         # TCMB PPK takvimi (Selenium) + 2025 hardcoded
    ├── fetch_tcmb_mevduat.py # EVDS3 TP.TRY.MT01 + MT02 (Playwright POST intercept)
    ├── fetch_tcmb_ticari.py  # EVDS3 TP_KTF17 ticari kredi (Playwright intercept)
    ├── fetch_sepet_kur.py    # TCMB XML döviz sepeti (requests + XML parse)
    ├── update_workdays.py    # Türkiye tatil takvimi — holidays kütüphanesi
    ├── scrape_benchmark.py   # hesapkurdu + hangikredi scraper + aggregate_benchmark()
    ├── evds3_client.py       # EVDS3 Playwright oturumu + POST isteği ortak istemci
    ├── add_details_sheet.py  # FORA.xlsx'e Details açıklama sayfası ekler
    └── holidays.py           # Türkiye resmi tatil yardımcı fonksiyonu
```

---

## Bölüm 1 — Veri Kaynakları ve Manuel Kontrol Rehberi

> **Bu bölüm koda bakmadan FORA.xlsx'teki her değerin nereden geldiğini ve nasıl elle doğrulanacağını açıklar.**
> Her bölümde önce "bu veri ne anlama gelir" bilgisi, ardından adım adım tarayıcıdan nasıl bulunur talimatı verilmiştir.

---

### 1. PP Getiri — TEFAS

| Alan                        | Değer                                                                                                                          |
| --------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| **Ne**                | Para Piyasası Şemsiye Fonu kategorisindeki**tüm fonların** haftalık ortalama günlük getirisi (sektör benchmarkı) |
| **Kaynak**            | [tefas.gov.tr/FonKarsilastirma.aspx](https://www.tefas.gov.tr/FonKarsilastirma.aspx)                                               |
| **Şemsiye Fon Kodu** | `107` — Para Piyasası Şemsiye Fonu                                                                                         |
| **Frekans**           | Haftalık (Min Tarih – Max Tarih aralığı başına 1 değer)                                                                 |
| **Kolon**             | `PP Getiri`                                                                                                                   |
| **Birim**             | Ondalık; örn.`0.00435` = günlük %0.435 getiri                                                                             |

> **Önemli:** Kod, TEFAS'taki Para Piyasası Şemsiye Fonu kategorisindeki **tüm fonların** günlük getirilerinin ortalamasını alır — bu ING'ye özgü değil, sektör geneli bir değerdir.
>
> ING'nin kendi fonu: **ING Portföy Para Piyasası Fonu**. Sadece bu fonu izlemek için `scrape_pp_getiri.py` güncellenmesi gerekir.

**TEFAS'ta elle doğrulama (adım adım):**

1. [tefas.gov.tr/FonKarsilastirma.aspx](https://www.tefas.gov.tr/FonKarsilastirma.aspx) adresini tarayıcınızda açın
2. Sayfanın üstündeki **Şemsiye Fon Türü** açılır menüsünden **Para Piyasası Şemsiye Fonu**'nu seçin
3. **Başlangıç Tarihi** kutusuna kontrol etmek istediğiniz haftanın ilk gününü girin (örn. `03.03.2025`)
4. **Bitiş Tarihi** kutusuna haftanın son gününü girin (örn. `09.03.2025`)
5. **Karşılaştır** butonuna tıklayın — tüm Para Piyasası fonları listelenir
6. Tablonun altındaki **Excel İndir** (.xlsx) butonuna basın
7. İndirilen dosyayı açın:
   - Tablonun **en sağdaki sütunu** o hafta günlük getiriyi (%) gösterir
   - Bu sütunun **ortalaması ÷ 100** = FORA.xlsx'teki `PP Getiri` değeri
8. Sadece ING'yi görmek için `Fon Adı` sütununda **"ING Portföy Para Piyasası Fonu"** satırına bakın

---

### 2. WebTüfe — webtufe.com

| Alan                              | Değer                                                                        |
| --------------------------------- | ----------------------------------------------------------------------------- |
| **Ne**                      | Türkiye zımni (piyasa bazlı) aylık enflasyon tahmini                      |
| **Kaynak**                  | [webtufe.com/tufe](https://webtufe.com/tufe)                                     |
| **Frekans**                 | Aylık — her ay için bir değer                                             |
| **Eşleştirme Mantığı** | Bir ayın son günü o hafta aralığına denk geliyorsa o ay değeri atanır |
| **Kolon**                   | `WebTufe`                                                                   |
| **Birim**                   | % (örn.`53.7` = %53.7 yıllık tahmini enflasyon)                          |

> **Teknik not:** Kod sayfadaki Plotly bar grafiğinde **kırmızı iz** (`rgb(239, 71, 111)` rengi) Web TÜFE'yi temsil eder — bu değeri HTML kaynak kodundan çeker.

**Elle doğrulama:**

1. [webtufe.com/tufe](https://webtufe.com/tufe) adresini açın
2. Ana sayfadaki **kırmızı çubuk grafiği** Web TÜFE tahminini gösterir
3. Grafiğin altındaki listede istediğiniz ay ve değer bulunur: `Mart 2026: X.X%`
4. FORA.xlsx'te o ayın son günü hangi haftaya denk geliyorsa o haftanın `WebTufe` sütunuyla karşılaştırın
   - Örn. Mart 2026 → son gün 31 Mart → 31 Mart hangi haftanın Min–Max aralığındaysa o haftaya atanır

---

### 3. AOFF — EVDS3 / TCMB

| Alan                | Değer                                                                                       |
| ------------------- | -------------------------------------------------------------------------------------------- |
| **Ne**        | TCMB'nin piyasaya sağladığı fonlamanın ağırlıklı ortalama faiz oranı (yıllık, %) |
| **Kaynak**    | [evds3.tcmb.gov.tr](https://evds3.tcmb.gov.tr)                                                  |
| **Seri Kodu** | `TP.APIFON4`                                                                               |
| **Frekans**   | Günlük yayın → haftalık ortalama                                                        |
| **Kolon**     | `AOFF`                                                                                     |
| **Birim**     | % yıllık (örn.`42.50` = %42.50)                                                         |

**Elle doğrulama:**

1. [evds3.tcmb.gov.tr](https://evds3.tcmb.gov.tr) adresini açın
2. Arama kutusuna **`TP.APIFON4`** yazın ve seri sayfasına girin
3. İlgili haftanın başlangıç ve bitiş tarihini seçin, verileri indirin
4. O haftanın günlük AOFF değerlerinin **aritmetik ortalaması** = FORA'daki değer

---

### 4. TLREF — Borsa İstanbul

| Alan                        | Değer                                                                                                     |
| --------------------------- | ---------------------------------------------------------------------------------------------------------- |
| **Ne**                | Türk lirası gecelik referans faiz oranı (yıllık basit, %)                                             |
| **Kaynak**            | [borsaistanbul.com/endeksler/tlref](https://www.borsaistanbul.com/endeksler/tlref)                            |
| **Frekans**           | Günlük yayın → haftalık ortalama                                                                      |
| **Artımsal Mantık** | FORA.xlsx'te mevcut TLREF değeri olan son haftanın Max Tarihi'nden itibaren sadece yeni günler çekilir |
| **Kolon**             | `TLREF`                                                                                                  |
| **Birim**             | % yıllık (örn.`43.75` = %43.75)                                                                       |

**Elle doğrulama:**

1. [borsaistanbul.com/endeksler/tlref](https://www.borsaistanbul.com/endeksler/tlref) adresini açın
2. Sayfadaki tabloda her iş günü için TLREF değeri listelenir
3. İlgili haftanın (Pazartesi–Cuma) iş günleri değerlerinin **aritmetik ortalaması** = FORA'daki değer

---

### 5. BIST 100 — EVDS3 / TCMB

| Alan                | Değer                                                    |
| ------------------- | --------------------------------------------------------- |
| **Ne**        | Borsa İstanbul BIST 100 bileşik endeks değeri          |
| **Kaynak**    | [evds3.tcmb.gov.tr](https://evds3.tcmb.gov.tr)               |
| **Seri Kodu** | `TP.MK.F.BILESIK`                                       |
| **Frekans**   | Haftalık (haftanın son işlem günü kapanış değeri) |
| **Kolon**     | `BIST 100`                                              |
| **Birim**     | Endeks puanı                                             |

**Elle doğrulama:**

1. [evds3.tcmb.gov.tr](https://evds3.tcmb.gov.tr) adresini açın
2. `TP.MK.F.BILESIK` serisini arayın
3. İlgili haftanın **son iş günü** kapanış değeri = FORA'daki değer

---

### 6. PPK Tarihleri — TCMB

| Alan                      | Değer                                                                                                                                       |
| ------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------- |
| **Ne**              | Para Politikası Kurulu toplantı tarihleri ve bir sonraki toplantıya kalan gün                                                            |
| **2025 Tarihleri**  | Kod içine sabit yazılmış: 20/01, 03/03, 17/03, 14/04, 16/07, 21/07, 08/09, 20/10, 01/12                                                  |
| **2026+ Tarihleri** | [tcmb.gov.tr — Duyurular/Takvim](https://www.tcmb.gov.tr/wps/wcm/connect/tr/tcmb+tr/main+menu/duyurular/takvim) sayfasından otomatik çekilir |
| **Mantık**         | Haftanın Min–Max tarihi aralığında bir PPK toplantı günü varsa `PPK = 1`, yoksa `0`                                              |
| **Kolon**           | `PPK`, `Sonraki PPK'ya Gün`                                                                                                             |

**Elle doğrulama:**

1. TCMB takvim sayfasını açın (yukarıdaki bağlantı)
2. Kontrol etmek istediğiniz haftanın Min–Max aralığında bir PPK tarihi varsa → `PPK = 1`, yoksa `0`
3. O haftanın herhangi bir gününden bir sonraki PPK tarihine kaç gün → `Sonraki PPK'ya Gün`

> 2025 tarihleri kod içinde sabit tanımlıdır. 2026 ve sonrası her çalışmada otomatik çekilir.

---

### 7. TCMB Mevduat Faizi — EVDS3

| Alan              | Değer                                                                    |
| ----------------- | ------------------------------------------------------------------------- |
| **Ne**      | Bankacılık sektörü ağırlıklı ortalama TL mevduat faiz oranı      |
| **Kaynak**  | [evds3.tcmb.gov.tr](https://evds3.tcmb.gov.tr)                               |
| **Seriler** | `TP.TRY.MT01` → 1 aylık mevduat / `TP.TRY.MT02` → 3 aylık mevduat |
| **Frekans** | Haftalık                                                                 |
| **Kolon**   | `TCMB 1M`, `TCMB 3M`                                                  |
| **Birim**   | % yıllık                                                                |

**Elle doğrulama:**

1. [evds3.tcmb.gov.tr](https://evds3.tcmb.gov.tr) adresini açın
2. `TP.TRY.MT01` (1 aylık) veya `TP.TRY.MT02` (3 aylık) serisini arayın
3. İlgili haftanın değerini FORA.xlsx'tekiyle karşılaştırın

---

### 8. Spot Kredi Faizi — EVDS3

| Alan                | Değer                                                                             |
| ------------------- | ---------------------------------------------------------------------------------- |
| **Ne**        | Türk bankalarının TL cinsinden ticari spot kredi faiz oranı (yıllık basit %) |
| **Kaynak**    | [evds3.tcmb.gov.tr](https://evds3.tcmb.gov.tr)                                        |
| **Seri Kodu** | `TP_KTF17` — "Ticari Krediler (TL, Akım, %)"                                   |
| **Frekans**   | Haftalık                                                                          |
| **Kolon**     | `Spot Kredi`                                                                     |
| **Birim**     | % yıllık basit (örn.`49.0` = %49.0)                                           |

**Elle doğrulama:**

1. [evds3.tcmb.gov.tr](https://evds3.tcmb.gov.tr) adresini açın
2. `TP_KTF17` serisini arayın (Ticari Krediler > Yurtiçi Kredi Faiz Oranları)
3. İlgili haftanın değerini FORA.xlsx'tekiyle karşılaştırın

---

### 9. Sepet Kur — TCMB XML

| Alan               | Değer                                                                       |
| ------------------ | ---------------------------------------------------------------------------- |
| **Ne**       | Eşit ağırlıklı USD/TRY + EUR/TRY döviz alış kuru sepeti              |
| **Formül**  | `Sepet Kur = 0.5 × ForexBuying(USD) + 0.5 × ForexBuying(EUR)`            |
| **Kaynak**   | TCMB günlük XML:`https://www.tcmb.gov.tr/kurlar/YYYYMM/DDMMYYYY.xml`     |
| **Kur Tipi** | `ForexBuying` — Döviz Alış                                             |
| **Frekans**  | Haftanın**son geçerli iş günü** (Cuma'dan geriye doğru taranır) |
| **Kolon**    | `Sepet Kur`                                                                |
| **Birim**    | TRY (örn.`38.25` = 38.25 TL)                                              |

**Elle doğrulama:**

1. Haftanın son iş gününü bulun (genellikle Cuma; resmi tatilse Perşembe vb.)
2. Tarayıcınızda şu URL'yi açın — tarih kısmını ilgili güne göre doldurun:
   `https://www.tcmb.gov.tr/kurlar/YYYYMM/DDMMYYYY.xml`
   - Örn. 7 Mart 2025 Cuma → `https://www.tcmb.gov.tr/kurlar/202503/07032025.xml`
3. Açılan XML sayfasında `<Currency CurrencyCode="USD">` altındaki `<ForexBuying>` değerini alın
4. `<Currency CurrencyCode="EUR">` altındaki `<ForexBuying>` değerini alın
5. `(USD + EUR) / 2` = FORA.xlsx `Sepet Kur` sütunundaki değer

---

### 10. Full Workday

| Alan             | Değer                                                                                     |
| ---------------- | ------------------------------------------------------------------------------------------ |
| **Ne**     | O hafta Pazartesi–Cuma arasında Türkiye'de resmi tatil olmayan tam 5 iş günü var mı |
| **Kaynak** | Python `holidays` kütüphanesi — Türkiye tatil takvimi                                |
| **Kolon**  | `Full Workday`                                                                           |
| **Birim**  | `1` = tam hafta (tatilsiz), `0` = tatil var                                            |

**Elle doğrulama:**

- Haftanın Pazartesi–Cuma arasında hiç resmi tatil yoksa `1`, herhangi bir gün tatilse `0`
- Güncel Türkiye tatil takvimi için: [resmitatiller.com](https://www.resmitatiller.com)

---

### 11. Benchmark Faiz Oranları

`Benchmark` ve `Benchmark_All` kolonları iki farklı karşılaştırma sitesinden derlenir; günlük `benchmark.xlsx` arşivinde saklanır.

---

#### Kaynak 1: hesapkurdu.com

| Alan                | Değer                                                                                                                        |
| ------------------- | ----------------------------------------------------------------------------------------------------------------------------- |
| **URL**       | [hesapkurdu.com/mevduat-teklifleri/1-gun-100000-tl?type=1](https://www.hesapkurdu.com/mevduat-teklifleri/1-gun-100000-tl?type=1) |
| **Parametre** | 1 günlük vade, 100.000 TL, tüm bankalar                                                                                    |
| **Filtre**    | ING hariç tutulur                                                                                                            |

Alınan bankalar (~19): TEB, DenizBank, Akbank, QNB, Alternatif Bank, Türkiye Finans, Yapı Kredi, Enpara, Hayat Finans, ON Dijital, AktifBank, Vakıf Katılım, Şekerbank, Ziraat Bankası, Halkbank, ICBC, HSBC, Odeabank

---

#### Kaynak 2: hangikredi.com

| Alan          | Değer                                                                                                                  |
| ------------- | ----------------------------------------------------------------------------------------------------------------------- |
| **URL** | [hangikredi.com/yatirim-araclari/mevduat-faiz-oranlari](https://www.hangikredi.com/yatirim-araclari/mevduat-faiz-oranlari) |

Buradan eklenen bankalar: **Anadolubank**, **Fibabanka**

---

#### Otomatize edilemeyen bankalar

| Banka                      | Neden?                                                                                        |
| -------------------------- | --------------------------------------------------------------------------------------------- |
| Burgan Bank                | Her iki karşılaştırma sitesinde de listelenmemiş                                         |
| Vakıfbank (konvansiyonel) | Her iki sitede de listelenmemiş; Vakıf Katılım ayrı bir kurumdur ve zaten çekilmektedir |

---

#### FORA'ya yazılan ortalamalar

| Kolon             | Formül                                        | Notlar                                       |
| ----------------- | ---------------------------------------------- | -------------------------------------------- |
| `Benchmark`     | `(TEB + DenizBank + Fibabanka + Akbank) / 4` | Sadece 4 hedef banka; biri yoksa hesaplanmaz |
| `Benchmark_All` | Tüm elde edilen bankaların ortalaması       | ~21 banka                                    |

**Günlük arşiv:** `benchmark.xlsx` (FORA.xlsx ile aynı klasörde)

Her `main.py` çalışmasında:

1. `scrape_benchmark()` → o günün verisi `benchmark.xlsx`'e eklenir; o gün zaten varsa üzerine yazılır
2. `aggregate_benchmark()` → `benchmark.xlsx`'ten haftaya denk gelen tüm günler ortalanır → FORA güncellenir

**Elle doğrulama:**

1. [hesapkurdu.com/mevduat-teklifleri/1-gun-100000-tl?type=1](https://www.hesapkurdu.com/mevduat-teklifleri/1-gun-100000-tl?type=1) adresini açın
2. Listedeki faiz oranlarını kontrol edin (ING hariç)
3. TEB + DenizBank + Fibabanka + Akbank oranlarını toplayıp 4'e bölün → `Benchmark`
4. Tüm görünen bankaların (ING hariç) ortalaması → `Benchmark_All`

---

## Bölüm 2 — FORA.xlsx Kolon Sözlüğü

| Kolon                   | Tür     | Kaynak                  | Açıklama                                                       |
| ----------------------- | -------- | ----------------------- | ---------------------------------------------------------------- |
| `Min Tarih`           | Tarih    | generate_weeks          | Haftanın başı (Pazartesi)                                     |
| `Max Tarih`           | Tarih    | generate_weeks          | Haftanın sonu (Pazar)                                           |
| `PP Getiri`           | Ondalık | TEFAS                   | Para Piyasası Şemsiye Fonu sektör günlük getiri ortalaması |
| `WebTufe`             | %        | webtufe.com             | Piyasa bazlı zımni aylık enflasyon tahmini                    |
| `AOFF`                | %        | EVDS3 TP.APIFON4        | TCMB ağırlıklı ortalama fonlama faizi (haftalık ort.)       |
| `TLREF`               | %        | Borsa İstanbul         | TL gecelik referans faizi (haftalık ort.)                       |
| `BIST 100`            | Endeks   | EVDS3 TP.MK.F.BILESIK   | BIST 100 bileşik endeks haftalık değeri                       |
| `PPK`                 | 0/1      | TCMB takvim             | O haftada PPK toplantısı var mı                               |
| `Sonraki PPK'ya Gün` | Gün     | TCMB takvim             | Haftanın herhangi bir gününden sonraki PPK'ya kalan gün      |
| `TCMB 1M`             | %        | EVDS3 TP.TRY.MT01       | Sektör 1 aylık TL mevduat ref. faizi                           |
| `TCMB 3M`             | %        | EVDS3 TP.TRY.MT02       | Sektör 3 aylık TL mevduat ref. faizi                           |
| `Spot Kredi`          | %        | EVDS3 TP_KTF17          | Ticari spot kredi faizi (yıllık basit)                         |
| `Sepet Kur`           | TRY      | TCMB XML                | 0.5×USD + 0.5×EUR ForexBuying (son iş günü)                 |
| `Full Workday`        | 0/1      | holidays lib            | 5 tam iş günü (tatilsiz) hafta mı                            |
| `Benchmark`           | %        | hesapkurdu + hangikredi | TEB+DenizBank+Fibabanka+Akbank haftalık ort.                    |
| `Benchmark_All`       | %        | hesapkurdu + hangikredi | Tüm bankalar (~21) haftalık ortalaması                        |

---

## Bölüm 3 — Teknik Mimari

### main.py Akış Tablosu

| Adım | Fonksiyon                 | Açıklama                                                                     |
| ----- | ------------------------- | ------------------------------------------------------------------------------ |
| 1     | `generate_weeks()`      | FORA.xlsx yoksa sıfırdan oluşturur; yeni haftalar varsa ekler               |
| 2     | `scrape_pp_getiri()`    | TEFAS Para Piyasası kategorisi — artımsal                                   |
| 3     | `scrape_webtufe()`      | webtufe.com Plotly kırmızı iz — aylık eşleştirme                        |
| 4     | `fetch_aoff()`          | EVDS3 `TP.APIFON4` — haftalık ortalama                                     |
| 5     | `scrape_tlref()`        | BIST TLREF — artımsal (son dolu Max Tarih'ten itibaren)                      |
| 6     | `fetch_bist100()`       | EVDS3 `TP.MK.F.BILESIK` — haftalık kapanış                               |
| 7     | `scrape_benchmark()`    | hesapkurdu (~19) + hangikredi (Anadolubank, Fiba) →`benchmark.xlsx`         |
| 8     | `aggregate_benchmark()` | `benchmark.xlsx` → haftalık ort. → FORA `Benchmark` + `Benchmark_All` |
| 9     | `scrape_ppk()`          | TCMB takvim + 2025 hardcoded →`PPK` / `Sonraki PPK'ya Gün`               |
| 10    | `fetch_tcmb_mevduat()`  | EVDS3 `TP.TRY.MT01` + `TP.TRY.MT02` — tek POST isteği                    |
| 11    | `fetch_tcmb_ticari()`   | EVDS3 `TP_KTF17` portlet — network intercept                                |
| 12    | `fetch_sepet_kur()`     | TCMB XML — son iş günü ForexBuying `(USD+EUR)/2`                         |
| 13    | `update_workdays()`     | `holidays` kütüphanesi — Pzt–Cum tatil kontrolü                         |
| 14    | `add_details_sheet()`   | FORA.xlsx'e açıklama sayfası ekler                                          |

---

### Artımsal Çalışma Mantığı

| Modül               | Artımsal Mantık                                                                                                                           |
| -------------------- | ------------------------------------------------------------------------------------------------------------------------------------------- |
| `scrape_pp_getiri` | `pd.notna(row[target_column])` — dolu satırları atlar, eksik olanları çeker                                                          |
| `scrape_tlref`     | FORA'daki `TLREF` kolonunda değeri olan son satırın `Max Tarih`'i → `stop_date`; sadece bu tarihten sonraki günler scrape edilir |
| `scrape_benchmark` | Aynı günün kaydı varsa üzerine yazar;`aggregate_benchmark` her çalışmada haftalık ortalamayı yeniden hesaplar                   |

---

### Teknoloji Yığını

| Kütüphane               | Kullanım                                                                              |
| ------------------------- | -------------------------------------------------------------------------------------- |
| `Playwright`            | EVDS3 headless oturumu + network intercept (AOFF, BIST100, Mevduat, Ticari, Benchmark) |
| `Selenium`              | TEFAS, TLREF, webtufe.com, PPK takvimi scraping                                        |
| `requests`              | TCMB XML döviz kuru API                                                               |
| `pandas`                | Veri işleme, tarih aralığı eşleştirme, Excel okuma/yazma                         |
| `openpyxl`              | Excel formatlama (satır renkleri, kolon genişlikleri, Details sayfası)              |
| `beautifulsoup4`        | webtufe.com Plotly HTML parse                                                          |
| `holidays`              | Türkiye resmi tatil takvimi                                                           |
| `xml.etree.ElementTree` | TCMB döviz XML parse                                                                  |

---

## Bölüm 4 — Neden Bazı Hücreler Boş?

FORA.xlsx'te belirli bir haftanın bazı kolonlarının boş görünmesi her zaman bir hata değildir. Her kolonun boşluk nedeni farklıdır:

| Boş Kolon                               | Neden?                                                                                                                                                                                                                                                                           | Dolduğu Zaman                                                                             |
| ---------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------ |
| `TCMB 1M`, `TCMB 3M`, `Spot Kredi` | TCMB/EVDS3 bu verileri**1–2 hafta gecikmeyle** yayınlar. Haftanın verisi genellikle sonraki haftanın ortasında EVDS3'te yayınlanır.                                                                                                                                 | `main.py` tekrar çalıştırıldığında veri yayınlanmışsa otomatik dolar          |
| `Benchmark`, `Benchmark_All`         | `benchmark.xlsx` arşivi yalnızca `main.py`'nin **o gün çalıştırıldığı** günlerin verisini içerir. Bir hafta içinde hiç çalıştırılmamışsa o hafta için arşivde kayıt yoktur; geriye dönük doldurulamaz (hesapkurdu.com anlık veri sağlar). | Bundan sonra**her hafta en az bir kez** `main.py` çalıştırılırsa boş kalmaz |
| `WebTufe`                              | Bu **doğru ve beklenen davranıştır.** WebTüfe aylık veri; her ayın **son günü** hangi haftanın tarih aralığına denk geliyorsa yalnızca o haftaya atanır. Diğer haftalar her zaman boş kalır.                                                      | Değişiklik gerekmez                                                                      |
| `PPK`, `Sonraki PPK'ya Gün`         | 2025 tarihleri kod içinde sabit. 2026 ve sonrası için TCMB takvim sayfasına erişim gerekir; sayfaya ulaşılamazsa boş kalabilir.                                                                                                                                          | Sonraki `main.py` çalıştırmasında otomatik güncellenebilir                         |

> **Genel kural:** Hücre boşsa paniklemeden önce `main.py`'yi tekrar çalıştırmayı deneyin. Veri kaynağı yayınlamışsa otomatik dolar. Dolmazsa yukarıdaki tablodan nedenini kontrol edin.
