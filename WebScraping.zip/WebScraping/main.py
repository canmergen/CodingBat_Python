# FIRAST Projesi — Ana Orkestrasyon Scripti
# Her modül kendi log_baslik() header'ını ve ilerleme satırlarını doğrudan basar.

from datetime import datetime

from src.utils import log_set_total
from src.week_generator import generate_weeks
from src.scrape_pp_getiri import scrape_pp_getiri
from src.fetch_aofm import fetch_aofm
from src.scrape_tlref import scrape_tlref
from src.fetch_bist100 import fetch_bist100
from src.fetch_tcmb_mevduat import fetch_tcmb_mevduat
from src.fetch_tcmb_ticari import fetch_tcmb_ticari
from src.fetch_sepet_kur import fetch_sepet_kur
from src.update_workdays import update_workdays
from src.add_details_sheet import add_details_sheet
from src.scrape_benchmark import scrape_benchmark, aggregate_benchmark
from src.seed_benchmark import seed_benchmark
from src.fetch_yfinance import fetch_yfinance
from src.fetch_evds3_macro import fetch_evds3_macro
from src.fetch_crypto import fetch_crypto
from src.update_calendar_features import update_calendar_features
from src.fetch_google_trends import fetch_google_trends
from src.fetch_cds import fetch_cds
from src.fetch_webtufe_tufe import fetch_webtufe_tufe
from src.fetch_webtufe_gruplar import fetch_webtufe_gruplar
from src.fetch_bkm_sektorel import fetch_bkm_sektorel
from src.fetch_ppk_dates import fetch_ppk_dates
from src.derive_firast_features import derive_firast_features
from src.build_firast_model import build_firast_model


CONFIG = {
    # İlk hafta: 30.09.2024 – 04.10.2024
    "START_DATE": datetime(2024, 9, 30),
    # EVDS API anahtarı — Beklenti Anketi ve işsizlik serileri için gerekli
    # Kaynak: https://evds2.tcmb.gov.tr → Üye Ol → API Anahtarı
    "EVDS_API_KEY": "A33UzQ44wO",
}

# Pipeline'da toplam adım sayısı — log_baslik() [X/N] göstergesini besler
TOTAL_STEPS = 25


def main():
    log_set_total(TOTAL_STEPS)

    # [1] Haftalık zaman çizelgesi (Pzt-Cum) → Yıl / Hafta / Min_Tarih / Max_Tarih
    generate_weeks(start_date=CONFIG["START_DATE"])

    # [2] AOFM — TCMB Ağırlıklı Ortalama Fonlama Maliyeti (EVDS3 TP.APIFON4)
    # PP_Getiri fallback'i olarak önce çekilir
    fetch_aofm()

    # [3] PP_Getiri — TEFAS para piyasası fonu getirisi; boşsa AOFM'a düşer
    scrape_pp_getiri()

    # [4] TLREF — Türk Lirası Referans Faizi (Borsa İstanbul günlük fixing)
    scrape_tlref(start_date=CONFIG["START_DATE"])

    # [5] BIST100 — Borsa İstanbul 100 endeksi (EVDS3 TP.MK.F.BILESIK)
    fetch_bist100()

    # [6] PPK toplantı tarihleri — TCMB takvim scrape + HISTORICAL_PPK_DATES sabiti
    # (PPK_Haftasi bayrağı update_calendar_features içinde otomatik hesaplanır)
    ppk_dates = fetch_ppk_dates()

    # [7] Benchmark — hesapkurdu.com + hangikredi.com canlı banka 1-gün TL mevduat faizleri (günlük arşiv)
    scrape_benchmark()
    # [8] Benchmark / Benchmark_All — arşivdeki günlükleri haftalık ortalamaya çevir
    aggregate_benchmark()
    # [9] Benchmark — geçmişte hesapkurdu arşivinde boş kalan haftaları
    # iş birimi arşivinden (2025 Hafta 1 – 2026 Hafta 1) tamamla
    seed_benchmark()

    # [10] TCMB_Mevduat_1M, TCMB_Mevduat_3M (EVDS3 TP.TRY.MT01/02 haftalık ortalama
    # + Ekim 2024 – Ağustos 2025 arası SEED Cuma spot kapanış override) ve
    # bunların +1 shift halleri TCMB_Mevduat_1M_Onceki_Hafta / _3M_Onceki_Hafta
    # (Pazartesi nowcast modeli için leakage-free feature)
    fetch_tcmb_mevduat()

    # [11] Spot_Kredi — Ticari kredi (TL akım) faizi (EVDS3 TP_KTF17)
    fetch_tcmb_ticari()

    # [12] Sepet_Kur — TCMB günlük forex bülteninden sepet kur (%50 USD + %50 EUR)
    fetch_sepet_kur()

    # [13] Full_Workday — haftadaki tam iş günü sayısı (holidays.Turkey dahil)
    update_workdays()

    # [14] Piyasa verileri (yfinance Yahoo Finance):
    # VIX, USD_TRY, EUR_USD, EUR_TRY, Altin_USD, Bakir, Gumus, Brent, DXY,
    # XBANK, Kur_Vol, BIST_Vol, Gram_Altin_TRY
    # (XU100.IS sadece BIST_Vol hesabı için indirilir, kolon olarak yazılmaz)
    fetch_yfinance()

    # [15] EVDS3 çoklu makro serileri:
    # KKO, Tuketici_Guven, Sanayi_Uretim, Ihtiyac_Kredi_Faizi,
    # TCMB_Net_Fonlama_TL, Fin_Guven (+ S02-S16),
    # Cekirdek_Enflasyon, Enflasyon_Beklenti_12ay, GSYH_Buyume_Beklenti, Issizlik
    fetch_evds3_macro(api_key=CONFIG["EVDS_API_KEY"])

    # [16] USDT_TRY_Hacim — CoinGecko günlük tether/try işlem hacmi (24 saatlik)
    fetch_crypto()

    # [17] GT_Mevduat_Faizi, GT_En_Yuksek — Google Trends haftalık arama hacimleri
    fetch_google_trends()

    # [18] CDS_5Y — Türkiye 5 yıllık CDS primi (worldgovernmentbonds, fallback: investing.com)
    fetch_cds()

    # [19] WebTufe_TUFE_Aylik/Yillik, TUIK_TUFE_Aylik/Yillik — aylık TÜFE değişim %
    fetch_webtufe_tufe()

    # [20] WebTufe ana grup endeksleri (günlük):
    # Gida, Enerji, Ulastirma, Hizmet, Giyim, KisiselBakim_Endeks + Aclik_Siniri
    fetch_webtufe_gruplar()

    # [21] BKM_Giyim_TL, BKM_Yemek_TL, BKM_Saglik_Kozmetik_TL — aylık sektörel kart harcama tutarları
    fetch_bkm_sektorel()

    # [22] Takvim & mevsimsellik bayrakları (deterministik, holidays.Turkey + hijridate):
    # Payday, Emekli_Maas_Donemi, Tax_Season, Ay_Sonu_Haftasi,
    # Bayram_Haftasi/Arefesi/Sonrasi, Milli_Bayram_Haftasi,
    # Season, Month, YearEnd, Okul_Tatili, Somestr_Tatili, Ara_Tatil,
    # Quarter_End, Ramazan, Black_Friday, Yaz_Turizm, Kis_Turizm,
    # Temetu_Donemi, PPK_Haftasi/Oncesi/Sonrasi, Enflasyon_Aciklama_Haftasi,
    # Market_Anomaly, Faiz_Anomaly
    update_calendar_features(ppk_dates=ppk_dates)

    # [23] Türetilmiş feature'lar (FIRAST ham kolonlarından hesap):
    # Faiz_Spread, Reel_Faiz,
    # BIST100_Getiri, Altin_Getiri, Kur_Degisim, Sepet_Kur_Degisim,
    # Reel_Giyim/Yemek/Kozmetik, Lipstick_Ratio,
    # Gida_Spread, Enerji_Spread, Hizmet_vs_Gida, Zorunlu_Harcama_Baskisi,
    # Market_Stress, Kur_Spike, Altin_Rush, CDS_Spike, Enflasyon_Sok, Likidite_Sikisma
    derive_firast_features()

    # [24] FIRAST.xlsx "Details" sayfası — feature kataloğu ve meta-bilgi
    add_details_sheet()

    # [25] FIRAST_MODEL.xlsx — feature-ilişki bazlı boşluk doldurma
    # (son satır / cari hafta asla dokunulmaz; geçmiş için ratio/spread/
    # extrapolation/seasonal-delta/ffill karışık policy; türetilmişler recompute)
    build_firast_model()


if __name__ == "__main__":
    main()
